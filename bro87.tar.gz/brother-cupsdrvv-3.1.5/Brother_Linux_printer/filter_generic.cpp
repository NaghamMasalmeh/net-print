#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <cstdlib>
#include <cstdio>
#include <unistd.h> // For realpath, getpid, mkstemp
#include <limits.h> // For PATH_MAX
#include <libgen.h> // For dirname
#include <regex>
#include <sstream>
#include <stdexcept> // For std::runtime_error

// Global variables translated from Perl
std::string FLAG = "";
std::string offset = "";

std::string HWMARGINS = "yes";

std::string PRINTER; // Initialized later from argv[0]
std::string INPUT_TEMP = "";
std::string FILE_TYPE = "PostScript";
std::string LOGFILE = "/tmp/br_lpdfilter_ink.log";

int LOG_FIRSTTIME = 1;
int LOGLEVEL = 7;
std::string DEBUG = "0"; // Initialized later from ENV
std::string PRTAREA; // Initialized later from ENV

std::string BR_PRT_PATH;
std::string RCFILE;
std::string FUNCFILE;
std::string PAPERINF;
std::string IMAGABLE;
std::string BRCONV;
std::string BRCONV_OP = "-P  -pi  -rc  -out cat"; // Placeholder, will be formatted later

std::string papertype;
int width = 0;
int height = 0;
std::string size_br = "";
std::string size_gs = "unknown";

std::string left_margin, top_margin, right_margin, bottom_margin; // Use string to match Perl split output initially

std::string GHOST_SCRIPT;
std::string OUTPUT_TYPE = "ppmraw";
std::string GHOST_OPT = "-q -dNOPROMPT -dNOPAUSE -dSAFER -sDEVICE=ppmraw -sstdout=%stderr -sOutputFile=- - -c quit"; // Placeholder, sDEVICE will be formatted

std::string gscommand = "";
std::string brcommand = "";

std::string TMP_PS = ""; // Used in DEBUG=2 and default branches
std::string TMP_PS1 = ""; // Used in default branch

// Helper function to get environment variable, returning empty string if not set or empty
std::string get_env_or_empty(const char* name) {
	const char* value = std::getenv(name);
	if (value == nullptr) return "";
	std::string result;
	try {
    	    result = std::string(value);
	} catch (...) {
            return "";
	}
	return result;
}

// Helper function to execute a shell command and capture its output
std::string exec_command(const std::string& cmd) {
    FILE* pipe = popen(cmd.c_str(), "r");
    if (!pipe) {
        // Handle error, maybe log or throw
        // For now, return empty string like Perl backticks might on failure
        return "";
    }
    char buffer[128];
    std::string result = "";
    while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
        result += buffer;
    }
    pclose(pipe);
    return result;
}

// Helper function to remove trailing newline/carriage return
std::string chomp(std::string s) {
    s.erase(s.find_last_not_of("\r\n") + 1);
    return s;
}

std::string escape_regex(const std::string& s) {
    static const std::regex esc(R"([.^$|()\\[*+?{\]])");
    return std::regex_replace(s, esc, R"(\$&)");
}

// Helper function to split a string by whitespace
std::vector<std::string> split(const std::string& s) {
    std::vector<std::string> tokens;
    std::stringstream ss(s);
    std::string token;
    while (ss >> token) {
        tokens.push_back(token);
    }
    return tokens;
}

// Helper function to copy a file
bool copy_file(const std::string& source, const std::string& destination) {
    std::ifstream src(source, std::ios::binary);
    std::ofstream dest(destination, std::ios::binary);
    if (!src || !dest) {
        return false; // Failed to open files
    }
    dest << src.rdbuf();
    return true; // Copy successful
}


// logprint function translated from Perl
void logprint(int level, const std::string& data) {
    if (DEBUG != "0") {
        std::ofstream log_file;
        if (LOG_FIRSTTIME) {
            log_file.open(LOGFILE, std::ios::out);
            LOG_FIRSTTIME = false;
        } else {
            log_file.open(LOGFILE, std::ios::app);
        }
        if (log_file.is_open() && level < LOGLEVEL) {
            log_file << data << std::endl;
        }
    }
}


int main(int argc, char* argv[]) {
 try {
 logprint(1, "start");
    // Initialize PRINTER from argv[0]
    if (argc > 0 && argv[0] != nullptr) {
        PRINTER = argv[0];
    } else {
        PRINTER = "unknown_filter"; // Default if argv[0] is not available
    }

    // Initialize DEBUG and PRTAREA from environment
    DEBUG = get_env_or_empty("LPD_DEBUG");
    PRTAREA = get_env_or_empty("PRTAREA1");
    if (PRTAREA == "") {
    	PRTAREA = "0";
    }
    logprint(1, "PRTAREA1" + PRTAREA);

    // $PRINTER =~ s/^.*filter_//;
    PRINTER = std::regex_replace(PRINTER, std::regex("^.*filter_"), "");
    // $PRINTER =~ s/\.pl$//;
    PRINTER = std::regex_replace(PRINTER, std::regex("\\.pl$"), "");

    // my $BR_PRT_PATH = Cwd::realpath ($0);
    char resolved_path[PATH_MAX];
    if (realpath(argv[0], resolved_path) != nullptr) {
        BR_PRT_PATH = resolved_path;
    } else {
        // Handle error, realpath failed
        std::cerr << "Error: realpath failed for " << argv[0] << std::endl;
        // Attempt to use dirname as a fallback, though less robust
        char* path_copy = strdup(argv[0]); // Need a mutable copy
        if (path_copy) {
             BR_PRT_PATH = dirname(path_copy);
             free(path_copy);
        } else {
             BR_PRT_PATH = "."; // Fallback to current directory
        }
    }

    // $BR_PRT_PATH =~ s/$PRINTER\/lpd\/.*$/$PRINTER\//g;
    // Need to escape special characters in PRINTER for regex if it contains any
    std::string printer_escaped = PRINTER;
    printer_escaped = escape_regex(printer_escaped); // Escape dot
    // Add other necessary escapes if PRINTER can contain them (e.g., /, *, +, ?)
    // For simplicity, assuming PRINTER is mostly alphanumeric here.
    // A more robust solution would escape all regex metacharacters.

    BR_PRT_PATH = std::regex_replace(BR_PRT_PATH, std::regex("/filter_" + printer_escaped + "$"), "");


    logprint(1, " BR_PRT_PATH=" + BR_PRT_PATH + "    PRINTER=" + PRINTER + " \n");

    // my $RCFILE=$ENV{BRPRINTERRCFILE};
    RCFILE = get_env_or_empty("BRPRINTERRCFILE");
    if (RCFILE.empty()) {
        // $RCFILE=sprintf ("$BR_PRT_PATH/inf/br%src",$PRINTER);
        RCFILE = BR_PRT_PATH + "/inf/br" + PRINTER + "rc";
    }
    // $FUNCFILE=sprintf ("$BR_PRT_PATH/inf/br%sfunc",$PRINTER);
    FUNCFILE = BR_PRT_PATH + "/inf/br" + PRINTER + "func";
    // $PAPERINF=sprintf ("$BR_PRT_PATH/inf/paperinf%s",$PRINTER);
    PAPERINF = BR_PRT_PATH + "/inf/paperinf" + PRINTER;
    // $IMAGABLE="$BR_PRT_PATH/inf/ImagingArea";
    IMAGABLE = BR_PRT_PATH + "/inf/ImagingArea";
    
    logprint(1, "RCFILE=" + RCFILE);
        logprint(1, "FUNCFILE=" + FUNCFILE);
        logprint(1, "PAPERINF=" + PAPERINF);
        logprint(1, "IMAGABLE=" + IMAGABLE);
        
    // $FLAG = `grep 'flags1='  $FUNCFILE | sed s/'flags1='//g`;
    FLAG = exec_command("grep 'flags1='  \"" + FUNCFILE + "\" | sed s/'flags1='//g");
    FLAG = chomp(FLAG);
    if (FLAG.empty()) {
        FLAG = "0000000000000002";
    }
    logprint(1, "FLAG=" + FLAG);
    // $offset = `grep 'offset='  $FUNCFILE | sed s/'offset='//g`;
    offset = exec_command("grep 'offset='  \"" + FUNCFILE + "\" | sed s/'offset='//g");
    offset = chomp(offset);
     logprint(1, "OFFSET=" + offset);
    // my $BRCONV="$BR_PRT_PATH/lpd/rastertobrpt1";
    BRCONV = BR_PRT_PATH + "/lpd/rastertobrpt1";
    // my $BRCONV_OP="-P $PRINTER -pi $PAPERINF -rc $RCFILE -out cat";
    BRCONV_OP = "-P " + PRINTER + " -pi " + PAPERINF + " -rc " + RCFILE + " -out cat";

    logprint(1, " BRCONV=" + BRCONV + "    PRINTER=" + PRINTER + " \n");

    //if (DEBUG.empty()) {
    //    DEBUG = "0";
    //}

    std::string ps_env = get_env_or_empty("PS");
    logprint(1, "PS env var: [" + ps_env + "]");

    // Input Handling
    if (ps_env != "1") {
    	logprint(1, "PS");
        // $INPUT_TEMP=`mktemp /tmp/br_input.XXXXXX`;
        std::string temp_template = "/tmp/br_input.XXXXXX";
        // mkstemp modifies the string template
        char* temp_name_cstr = strdup(temp_template.c_str());
        if (!temp_name_cstr) {
             std::cerr << "Error: strdup failed for mktemp template" << std::endl;
             logprint(1, "Error: mkstemp failed");
             exit(EXIT_FAILURE);
        }
        else {
             logprint(1, "temp_name_cstr");
        }
        int fd = mkstemp(temp_name_cstr);
        if (fd == -1) {
            std::cerr << "Error: mkstemp failed" << std::endl;
            logprint(1, "INPUT_TEMP=" + INPUT_TEMP);
            free(temp_name_cstr);
            exit(EXIT_FAILURE);
        } else {
            logprint(1, "mkstemp");
        }
        close(fd); // Close the file descriptor, we only need the name
        INPUT_TEMP = temp_name_cstr;
        free(temp_name_cstr);

        // `cat > $INPUT_TEMP`; // Read stdin to temp file
        std::ofstream temp_file(INPUT_TEMP);
        if (!temp_file.is_open()) {
             std::cerr << "Error: Failed to open temp file for writing: " << INPUT_TEMP << std::endl;
             logprint(1, "Error: Failed to open temp file for writing: " + INPUT_TEMP);
             exit(EXIT_FAILURE);
        } else {
             logprint(1, "INPUT_TEMP " + INPUT_TEMP);
        }
        if (std::cin.peek() == std::istream::traits_type::eof()) {
    		logprint(0, "ERROR: No input data received on stdin.\n");
    		return 1;
	} else {
		logprint(1, "std::istream::traits_type::eof");
	}
        temp_file << std::cin.rdbuf();
        std::ifstream in_size(INPUT_TEMP, std::ios::binary | std::ios::ate);
	if (in_size.is_open()) {
    		logprint(1, "DEBUG: Input temp file size: " + std::to_string(in_size.tellg()) + " bytes\n");
    		in_size.close();
	} else {
    		logprint(0, "ERROR: Failed to open INPUT_TEMP to check file size\n");
	}
        temp_file.close();

        // $FILE_TYPE=`file $INPUT_TEMP`;
        FILE_TYPE = exec_command("file \"" + INPUT_TEMP + "\"");
        // $FILE_TYPE=~ s/^.*:[ ]*//;
        FILE_TYPE = std::regex_replace(FILE_TYPE, std::regex("^.*:[ ]*"), "");
        // $FILE_TYPE=~ s/[ ].*//;
        FILE_TYPE = std::regex_replace(FILE_TYPE, std::regex("[ ].*"), "");
        FILE_TYPE = chomp(FILE_TYPE); // Remove trailing newline from file command output
        logprint(1, "FILE_TYPE: " + FILE_TYPE);

        if (DEBUG != "0") {
            // copy "$INPUT_TEMP"      ,   "/tmp/br_lpdfilter_ink_input.ps";
            if (!copy_file(INPUT_TEMP, "/tmp/br_lpdfilter_ink_input.ps")) {
                 logprint(1, "Warning: Failed to copy input temp file for debug.");
            }
        }
    } else {
        INPUT_TEMP = ""; // This is immediately overwritten below in the original Perl
        FILE_TYPE = "PostScript";
        logprint(1, "PostScript");

        // The commented out block in Perl is followed by active code that
        // creates a temp file and cats stdin into it, even if PS=1.
        // Replicating this exact behavior.

        // $INPUT_TEMP=`mktemp /tmp/br_input.XXXXXX`;
        std::string temp_template = "/tmp/br_input.XXXXXX";
        char* temp_name_cstr = strdup(temp_template.c_str());
         if (!temp_name_cstr) {
             std::cerr << "Error: strdup failed for mktemp template" << std::endl;
             logprint(1, "Error: strdup failed for mktemp template");
             exit(EXIT_FAILURE);
        }
        int fd = mkstemp(temp_name_cstr);
        if (fd == -1) {
            std::cerr << "Error: mkstemp failed" << std::endl;
            logprint(1, "Error: mkstemp failed");
            free(temp_name_cstr);
            exit(EXIT_FAILURE);
        }
        close(fd); // Close the file descriptor, we only need the name
        INPUT_TEMP = temp_name_cstr;
        free(temp_name_cstr);

        // `cat > $INPUT_TEMP`; // Read stdin to temp file
        std::ofstream temp_file(INPUT_TEMP);
         if (!temp_file.is_open()) {
             std::cerr << "Error: Failed to open temp file for writing: " << INPUT_TEMP << std::endl;
             logprint(1, "Error: Failed to open temp file for writing");
             exit(EXIT_FAILURE);
        }
        if (std::cin.peek() == std::istream::traits_type::eof()) {
    		logprint(0, "ERROR: No input data received on stdin.\n");
    		return 1;
	}
        temp_file << std::cin.rdbuf();
        std::ifstream in_size(INPUT_TEMP, std::ios::binary | std::ios::ate);
	if (in_size.is_open()) {
    		logprint(1, "DEBUG: Input temp file size: " + std::to_string(in_size.tellg()) + " bytes\n");
    		in_size.close();
	} else {
    		logprint(0, "ERROR: Failed to open INPUT_TEMP to check file size\n");
	}
        temp_file.close();

        // The copy line is commented out in the original Perl, so we don't translate it.
        // copy "$INPUT_TEMP"     ,    "/tmp/br_lpdfilter_ink_input.ps";
    }

    logprint(1, "PRINTER=" + PRINTER);
    logprint(1, "$ENV{PS} =  " + get_env_or_empty("PS"));
    logprint(1, "$ENV{BRPRINTERRCFILE} = " + get_env_or_empty("BRPRINTERRCFILE"));

    // my $paper = "29x90"; // This variable is immediately overwritten
    std::string paper_dummy = "29x90"; // Keep variable name for clarity, though unused
    std::string resolution = "300"; // Keep variable name, though value seems fixed

    // open (FPRCFILE , $RCFILE);
    std::ifstream fprcfile(RCFILE);
    if (!fprcfile.is_open()) {
        // die "can't open $RCFILE !";
        std::cerr << "Error: can't open " << RCFILE << " !" << std::endl;
        logprint(1, "Error: can't open " + RCFILE);
        exit(EXIT_FAILURE);
    }

    std::string rcline;
    while (std::getline(fprcfile, rcline)) {
        // if ( $rcline =~ /MediaSize/){
        if (rcline.find("MediaSize") != std::string::npos) {
            // $papertype =  $rcline;
            papertype = rcline;
            // $papertype =~ s/MediaSize=//;
            papertype = std::regex_replace(papertype, std::regex("MediaSize="), "");
            papertype = chomp(papertype);
            logprint(1, "papertype " + papertype);
            // Found it, no need to break, Perl continues reading the file
        }
    }
    fprcfile.close();

    // $width =  $ENV{BRPAPERWIDTH};
    // $height = $ENV{BRPAPERHEIGHT};
    // Note: The Perl code reads width/height from ENV *after* reading papertype from RCFILE,
    // but then later reads width/height *again* from PAPERINF based on $papertype.
    // The values from PAPERINF are the ones actually used for $size_gs and $size_br.
    // Replicating this exact flow.
    std::string env_width_str = get_env_or_empty("BRPAPERWIDTH");
    std::string env_height_str = get_env_or_empty("BRPAPERHEIGHT");

    logprint(1, "$ENV{BRPAPERWIDTH} = " + env_width_str);
    logprint(1, "$ENV{BRPAPERHEIGHT} = " + env_height_str);
    size_br = ""; // Reset size_br, it's built later

    logprint(1, " PAPERINF=" + PAPERINF + " \n");

    // open (my $fh,"<" , $PAPERINF) or die "can't open $PAPERINF !";
 //   std::ifstream fh(PAPERINF);
//    if (!fh.is_open()) {
//        std::cerr << "Error: can't open " << PAPERINF << " !" << std::endl;
 //       exit(EXIT_FAILURE);
 //   }

    std::ifstream fh(PAPERINF);
    std::string line;
if (!fh.is_open()) {
    logprint(0, "Failed to open PAPERINF file: " + PAPERINF + "\n");
} else {
    std::string paper_from_inf;
    while (std::getline(fh, line)) {
        chomp(line);

        // Skip header line
        if (line.find("paper type") != std::string::npos) continue;
        if (line.empty()) continue;

        // Split line by whitespace
        std::vector<std::string> tokens = split(line);
        if (tokens.size() < 3) {
            logprint(0, "Skipping malformed line: " + line + "\n");
            continue;
        }

        std::string paper = tokens[0];
        // Remove trailing colon if present
        if (!paper.empty() && paper.back() == ':') {
            paper.pop_back();
        }

        try {
            if (tokens.size() < 3) {
        	logprint(0, "ERROR: Skipping malformed line in PAPERINF: " + line + "\n");
        	continue;
    		}
    	    width = std::stoi(tokens[1]);
            height = std::stoi(tokens[2]);
        } catch (const std::exception& e) {
            logprint(0, "Invalid width/height in line: " + line + " — " + e.what() + "\n");
            continue;
        }

        logprint(1, "Parsed: paper=" + paper + " width=" + std::to_string(width) + " height=" + std::to_string(height) + "\n");

        // Match against desired papertype
        if (paper == papertype) {
            break;
        }
    }
    fh.close();
}
  //  std::string line;
  //  std::string paper_from_inf; // Variable to hold the paper type read from PAPERINF
  //  while (std::getline(fh, line)) {
  //      chomp(line);
        // ($paper,$width,$height)=split(/\s+/,$line);
 //       std::vector<std::string> tokens = split(line);
  //      if (tokens.size() >= 3) {
  //          paper_from_inf = tokens[0];
  //          width = std::stoi(tokens[1]); // Convert to int
  //          height = std::stoi(tokens[2]); // Convert to int
  //      } else {
             // Handle lines that don't have enough columns? Perl split might behave differently.
             // Assuming valid format based on original code structure.
    //         continue; // Skip lines that don't split correctly
    //    }

        // last if($line =~/^$papertype/);
    //    if (line.rfind(papertype, 0) == 0) { // Check if line starts with $papertype
    //        break; // Found the matching paper type line
    //    }
  //  //    // logprint(1, " TYPE=$paper w=$width h=$height size_br=$size_br \n"); // Commented out in Perl
  //  }
  //  fh.close();

    // $width=$width+0; // Already converted to int during split
    // $height=$height+0; // Already converted to int during split

    logprint(1, " TYPE=" + papertype + "  w=" + std::to_string(width) + " h=" + std::to_string(height) + " size_br=" + size_br + " \n");

    // $size_br = " -ps ${width}x${height}";
    size_br = " -ps " + std::to_string(width) + "x" + std::to_string(height);
    // $BRCONV_OP .= $size_br; // Commented out in Perl

    size_gs = "unknown"; // Reset size_gs, it's built later
    // The commented out resolution block means only the 300dpi case is active
    // $size_gs = sprintf( "%dx%d", $width , $height);
    size_gs = std::to_string(width) + "x" + std::to_string(height);

    logprint(1, "size_gs = " + size_gs + " ,size_br = " + size_br + " \n");

    // my $GHOST_SCRIPT=`which gs`;
    GHOST_SCRIPT = exec_command("which gs");
    GHOST_SCRIPT = chomp(GHOST_SCRIPT);
    if (GHOST_SCRIPT.empty()) {
        std::cerr << "Error: 'gs' (Ghostscript) not found in PATH." << std::endl;
        logprint(1, "Error: 'gs' (Ghostscript) not found in PATH.");
        exit(EXIT_FAILURE); // Exit if gs is not found
    }

    // my $OUTPUT_TYPE="ppmraw"; // Already initialized globally
    // my $GHOST_OPT="-q -dNOPROMPT -dNOPAUSE -dSAFER -sDEVICE=$OUTPUT_TYPE -sstdout=%stderr -sOutputFile=- - -c quit";
    GHOST_OPT = "-q -dNOPROMPT -dNOPAUSE -dSAFER -sDEVICE=" + OUTPUT_TYPE + " -sstdout=%stderr -sOutputFile=- - -c quit";


    // open (FPRCFILE , $IMAGABLE); // Reusing fprcfile variable name from RCFILE read
    std::ifstream imagable_file(IMAGABLE);
    if (!imagable_file.is_open()) {
        std::cerr << "Error: can't open " << IMAGABLE << " !" << std::endl;
        logprint(1, "Error: can't open" + IMAGABLE);
        exit(EXIT_FAILURE);
    }

    std::string paper_from_imagable; // Variable to hold paper type from Imagable file
    // my ($left,$top,$right,$bottom)=split(/\s+/,$line); // Declared globally now
    while (std::getline(imagable_file, line)) {
        chomp(line);
        std::vector<std::string> tokens = split(line);
        if (tokens.size() >= 5) {
            paper_from_imagable = tokens[0];
            left_margin = tokens[1];
            top_margin = tokens[2];
            right_margin = tokens[3];
            bottom_margin = tokens[4];
            logprint(1, "bottom_margin" + bottom_margin);
        } else {
             // Skip lines that don't split correctly
             logprint(1, "Skip lines that don't split correctly");
             continue;
        }

        // last if($line =~/^$papertype/);
        if (line.rfind(papertype, 0) == 0) { // Check if line starts with $papertype
            break; // Found the matching paper type line
        }
    }
    imagable_file.close();

    logprint(1, "[" + left_margin + " " + top_margin + " " + right_margin + " " + bottom_margin + "] \n");
    // logprint(1,"<</ImagingBBox [$left $top $right $bottom] /PageOffset [-$left $top]>> setpagedevice\n"); // Log the PS command string

    // Construct Ghostscript command string
    if (HWMARGINS == "yes") {
        gscommand =
            "(echo  '<</ImagingBBox [" + left_margin + " " + top_margin + " " + right_margin + " " + bottom_margin + "] /PageOffset [-" + left_margin + " " + top_margin + "]>> setpagedevice';" +
            "cat \"" + INPUT_TEMP + "\")" +
            " | \"" + GHOST_SCRIPT + "\" -r" + resolution + " -g" + size_gs + " " + GHOST_OPT;
    } else {
        gscommand =
            "cat \"" + INPUT_TEMP + "\" | \"" + GHOST_SCRIPT + "\" -r" + resolution + " -g" + size_gs + " " + GHOST_OPT;
        logprint(1, "test 2\n"); // This logprint seems misplaced in the original logic
    }

    // Construct Brother converter command string
    brcommand = "\"" + BRCONV + "\" " + BRCONV_OP;

    logprint(1, "**** " + gscommand + "  ****\n");
    logprint(1, "**** " + INPUT_TEMP + "  ****\n");
    logprint(1, "**** debug=" + DEBUG + "  ****\n");

    // Execution Logic based on DEBUG level
    if (DEBUG == "1") {
        // system("$gscommand | $brcommand");
        std::string full_command = gscommand + " | " + brcommand;
        system(full_command.c_str());
        logprint(0, full_command);
    } else if (DEBUG == "2") {
        // `echo '<</ImagingBBox ...>> setpagedevice' > /tmp/br_lpdfilter_ink_gsout.dat`;
        std::ofstream gsout_file("/tmp/br_lpdfilter_ink_gsout.dat");
        if (!gsout_file.is_open()) {
             std::cerr << "Error: Failed to open /tmp/br_lpdfilter_ink_gsout.dat for writing." << std::endl;
             exit(EXIT_FAILURE);
        }
        gsout_file << "<</ImagingBBox [" << left_margin << " " << top_margin << " " << right_margin << " " << bottom_margin << "] /PageOffset [-" << left_margin << " " << top_margin << "]>> setpagedevice" << std::endl;
        gsout_file.close();

        // $FILE_TYPE=`file $INPUT_TEMP | sed -e 's/^.*:[ ]*//' -e 's/[ ].*//'`; // Re-determine file type
        FILE_TYPE = exec_command("file \"" + INPUT_TEMP + "\" | sed -e 's/^.*:[ ]*//' -e 's/[ ].*//'");
        FILE_TYPE = chomp(FILE_TYPE);

        logprint(1, "file type = <" + FILE_TYPE + ">\n");

        if (FILE_TYPE == "PDF") { // Perl compares to "PDF\n", chomp removes \n
            // logprint(1, "/usr/bin/pdf2ps  $INPUT_TEMP $TMP_PS\n"); // $TMP_PS not defined yet in Perl
            // `cp $INPUT_TEMP /tmp/tmp.pdf`; // Redundant copy in Perl
            TMP_PS = "/tmp/tmp.ps"; // Define TMP_PS
            // `/usr/bin/pdf2ps  $INPUT_TEMP $TMP_PS`;
            std::string pdf2ps_cmd = "/usr/bin/pdf2ps \"" + INPUT_TEMP + "\" \"" + TMP_PS + "\"";
            system(pdf2ps_cmd.c_str());
            logprint(1, pdf2ps_cmd + "\n");

            // `cat $TMP_PS| sed s/'%%HiResBoundingBox:'/'%HiResBoundingBox:'/g >> /tmp/br_lpdfilter_ink_gsout.dat`;
            std::string sed_cmd = "cat \"" + TMP_PS + "\" | sed s/'%%HiResBoundingBox:'/'%HiResBoundingBox:'/g >> /tmp/br_lpdfilter_ink_gsout.dat";
            system(sed_cmd.c_str());

            // Redundant logprints in Perl
            // logprint(1, " echo  '<</ImagingBBox ...>> setpagedevice' > /tmp/br_lpdfilter_ink_gsout.dat\n");
            // logprint(1, " /usr/bin/pdf2ps ... > /tmp/br_lpdfilter_ink_gsout.dat\n");

        } else {
            // `cat $INPUT_TEMP      >> /tmp/br_lpdfilter_ink_gsout.dat`;
            std::string cat_cmd = "cat \"" + INPUT_TEMP + "\" >> /tmp/br_lpdfilter_ink_gsout.dat";
            system(cat_cmd.c_str());
            // logprint(1, " $gscommand > /tmp/br_lpdfilter_ink_gsout.dat\n"); // Misleading log in Perl
        }

        // `cp  $RCFILE /tmp/br_lpdfilter_ink.rc`;
        if (!copy_file(RCFILE, "/tmp/br_lpdfilter_ink.rc")) {
             logprint(1, "Warning: Failed to copy RCFILE for debug.");
        }

        // $brcommand="$BRCONV -P $PRINTER -pi $PAPERINF -rc /tmp/br_lpdfilter_ink.rc -out cat";
        brcommand = "\"" + BRCONV + "\" -P " + PRINTER + " -pi " + PAPERINF + " -rc /tmp/br_lpdfilter_ink.rc -out cat";

        // `cat /tmp/br_lpdfilter_ink_gsout.dat| $GHOST_SCRIPT -r$resolution -g$size_gs $GHOST_OPT | $brcommand >/tmp/br_lpdfilter_ink_out.prn`;
        std::string pipeline_cmd = "cat /tmp/br_lpdfilter_ink_gsout.dat | \"" + GHOST_SCRIPT + "\" -r" + resolution + " -g" + size_gs + " " + GHOST_OPT + " | " + brcommand + " >/tmp/br_lpdfilter_ink_out.prn";
        system(pipeline_cmd.c_str());

        // system("cat /tmp/br_lpdfilter_ink_out.prn"); // Output the final result
        system("cat /tmp/br_lpdfilter_ink_out.prn");

        // logprint(1, "cat /tmp/br_lpdfilter_ink_gsout.dat | $brcommand >/tmp/br_lpdfilter_ink_out.prn\n"); // Log the command that was run
        logprint(1, pipeline_cmd + "\n");
        // logprint(1, "cat /tmp/br_lpdfilter_ink_out.prn "); // Log the command that was run
        logprint(1, "cat /tmp/br_lpdfilter_ink_out.prn\n"); // Add newline for clarity in log
        logprint(1, "file type = " + FILE_TYPE + "\n");

    } else { // DEBUG is not '1' or '2' (implicitly '0' based on initialization)
        // system("$gscommand | $brcommand"); // Commented out in Perl

        // $TMP_PS1="/tmp/br_lpdfilter_ink_gsout_".$$.".dat";
        TMP_PS1 = "/tmp/br_lpdfilter_ink_gsout_" + std::to_string(getpid()) + ".dat";

        logprint(1, "PRTAREA = " + PRTAREA + "\n");

        std::ofstream tmp_ps1_file(TMP_PS1);
        if (!tmp_ps1_file.is_open()) {
             std::cerr << "Error: Failed to open " << TMP_PS1 << " for writing." << std::endl;
             exit(EXIT_FAILURE);
        }

        if (PRTAREA == "0") { // Perl compares string "0"
            logprint(1, "1PRTAREA = " + PRTAREA + "\n");
            // `echo '<</ImagingBBox ...>> setpagedevice' >$TMP_PS1 `;
            tmp_ps1_file << "<</ImagingBBox [0 0 " << width << " " << height << "] "
             << "/PageOffset [0 0]>> setpagedevice"
             << std::endl;
        } else if (PRTAREA == "1") { // Perl compares string "1"
            // `echo '<</PageOffset [0 17]>> setpagedevice' >$TMP_PS1 `;
            tmp_ps1_file << "<</PageOffset [0 17]>> setpagedevice" << std::endl;
        }
        tmp_ps1_file.close(); // Close after writing the initial part

        // $FILE_TYPE=`file $INPUT_TEMP | sed -e 's/^.*:[ ]*//' -e 's/[ ].*//'`; // Re-determine file type?
        FILE_TYPE = exec_command("file \"" + INPUT_TEMP + "\" | sed -e 's/^.*:[ ]*//' -e 's/[ ].*//'");
        FILE_TYPE = chomp(FILE_TYPE);

        if (FILE_TYPE == "PDF") { // Perl compares to "PDF\n", chomp removes \n
            // $TMP_PS="/tmp/tmp_".$$.".ps";
            logprint(1, "PDF");
            TMP_PS = "/tmp/tmp_" + std::to_string(getpid()) + ".ps";
            // `/usr/bin/pdf2ps  $INPUT_TEMP $TMP_PS`;
            std::string pdf2ps_cmd = "/usr/bin/pdf2ps \"" + INPUT_TEMP + "\" \"" + TMP_PS + "\"";
            system(pdf2ps_cmd.c_str());

            // `cat $TMP_PS| sed s/'%%HiResBoundingBox:'/'%HiResBoundingBox:'/g >>$TMP_PS1`;
            std::string sed_cmd = "cat \"" + TMP_PS + "\" | sed s/'%%HiResBoundingBox:'/'%HiResBoundingBox:'/g >> \"" + TMP_PS1 + "\"";
            system(sed_cmd.c_str());
        } else {
        logprint(1, "not PDF");
            // `cat $INPUT_TEMP      >> $TMP_PS1`;
            std::string cat_cmd = "cat \"" + INPUT_TEMP + "\" >> \"" + TMP_PS1 + "\"";
            system(cat_cmd.c_str());
        }

        // $brcommand="$BRCONV -P $PRINTER -pi $PAPERINF -rc $RCFILE"; // Use original RC file
        brcommand = "\"" + BRCONV + "\" -P " + PRINTER + " -pi " + PAPERINF + " -rc " + RCFILE;
        logprint(1, "brcommand: " + brcommand);

        // system("cat $TMP_PS1| $GHOST_SCRIPT -r$resolution -g$size_gs $GHOST_OPT | $brcommand");
        std::string pipeline_cmd = "cat \"" + TMP_PS1 + "\" | \"" + GHOST_SCRIPT + "\" -r" + resolution + " -g" + size_gs + " " + GHOST_OPT + " | " + brcommand;
        logprint(1, "pipeline_cmd: " + pipeline_cmd);
        system(pipeline_cmd.c_str());
    }

    // Cleanup temporary files
    if (!INPUT_TEMP.empty()) {
        //remove(INPUT_TEMP.c_str());
    }
    // Only unlink TMP_PS and TMP_PS1 if they were actually assigned a filename
    if (!TMP_PS.empty()) {
       // remove(TMP_PS.c_str());
    }
    if (!TMP_PS1.empty()) {
       // remove(TMP_PS1.c_str());
    }

   } catch (const std::exception& e) {
        logprint(1, "Exception caught: " + std::string(e.what()));
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }
        // exit 0;
    return 0;
}

