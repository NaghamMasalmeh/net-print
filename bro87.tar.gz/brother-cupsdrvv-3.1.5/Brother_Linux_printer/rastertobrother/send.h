/*=================================================================================*
*FileName:     	send.h
*Description:	declarations for processing send buffer functions
*Revision:     	1.0									
*Date:         	2003.08.28							
*Author:       	Chenxujin , SteadyBJ 									
*Histroy:      	1.Chenxujin , Create
*==================================================================================*/
#ifndef _SEND_H_
#define _SEND_H_

#include"pd.h"

/*Send Buffer module*/

#ifdef _cplusplus
extern "C" {
#endif/*_cplusplus*/

extern	send_buffer		send_buf ;

extern	short	CreateSendBuf( pt_model model ) ;
extern	void	DestroySendBuf() ;
extern	void	ResetSendBuf() ;
extern	short	SaveDumb( long * pLen , unsigned char * pBuf ) ;
extern	short	FlushBuf() ;


#ifdef _cplusplus
}
#endif/*_cplusplus*/

#endif	/*_SEND_H_*/

