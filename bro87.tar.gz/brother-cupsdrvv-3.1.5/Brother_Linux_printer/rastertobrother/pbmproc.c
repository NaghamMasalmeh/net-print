#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>

/* Return codes */
#define PPM_OK            0
#define PPM_EOF_NODATA    1
#define PPM_FORMAT_ERROR -1
#define PPM_IO_ERROR     -2

/* Phase identifiers */
#define PHASE_MG_NUMBER   0
#define PHASE_WIDTH       1
#define PHASE_LENGTH      2
#define PHASE_MAX_COLOR   3

/* Constants */
#define MAX_LINE_LENGTH   16384
#define MAX_SANE_DIMENSION 10000
#define MAX_SANE_COLOR    16384
#define PPMB_MAGIC_NUMBER "P6"

typedef struct {
    long width;
    long length;
    long maxCol;
} PPM_HEAD;

/* Safe string to long conversion */
static long safe_atol(const char *str) {
    char *endptr;
    errno = 0;
    long val = strtol(str, &endptr, 10);
    
    if (errno != 0 || *endptr != '\0' || val <= 0) {
        return -1;
    }
    return val;
}

int ReadPpmFileHeader(FILE *fp, int iPageCount) {
    /* Stack protection */
    volatile long stack_canary = 0xDEADBEEF;
    
    PPM_HEAD head = {0, 0, 0};
    char szLine[MAX_LINE_LENGTH + 1] = {0};
    int nCnt = 0;
    int cVal;
    int fSpace;
    int fComment = 0;
    int fFlash = 1;
    int fLoop = 1;
    int iPhase = PHASE_MG_NUMBER;
    int fPageExist = 0;

    while (fLoop) {
        if (fFlash) {
            memset(szLine, 0, sizeof(szLine));
            nCnt = 0;
            fFlash = 0;
        }

        cVal = fgetc(fp);
        if (cVal == EOF) {
            if (ferror(fp)) {
                perror("File read error");
                return PPM_IO_ERROR;
            }
            return fPageExist ? PPM_IO_ERROR : PPM_EOF_NODATA;
        }
        fPageExist = 1;

        /* Handle comments */
        if (fComment) {
            if (cVal == '\n' || cVal == '\r') {
                fComment = 0;
            }
            continue;
        }

        /* Detect comment start */
        if (nCnt == 0 && cVal == '#') {
            fComment = 1;
            continue;
        }

        fSpace = (cVal == ' ' || cVal == '\t' || 
                 cVal == '\n' || cVal == '\r');

        if (!fSpace) {
            /* Strict bounds checking */
            if (nCnt >= MAX_LINE_LENGTH) {
                fprintf(stderr, "ERROR: Header token exceeds %d bytes\n", 
                        MAX_LINE_LENGTH);
                return PPM_FORMAT_ERROR;
            }
            szLine[nCnt++] = (char)cVal;
        } 
        else if (nCnt > 0) {
            /* Complete token - process it */
            szLine[nCnt] = '\0';

            switch (iPhase) {
                case PHASE_MG_NUMBER:
                    if (strcmp(szLine, PPMB_MAGIC_NUMBER) != 0) {
                        if (strcmp(szLine, "P3") == 0) {
                            fprintf(stderr, "ERROR: ASCII PPM (P3) not supported\n");
                        }
                        return (iPageCount > 0) ? PPM_EOF_NODATA : PPM_FORMAT_ERROR;
                    }
                    iPhase++;
                    fFlash = 1;
                    break;

                case PHASE_WIDTH: {
                    long width = safe_atol(szLine);
                    if (width <= 0 || width > MAX_SANE_DIMENSION) {
                        fprintf(stderr, "ERROR: Invalid width: %ld (Max: %d)\n",
                                width, MAX_SANE_DIMENSION);
                        return PPM_FORMAT_ERROR;
                    }
                    head.width = width;
                    iPhase++;
                    fFlash = 1;
                    break;
                }

                case PHASE_LENGTH: {
                    long length = safe_atol(szLine);
                    if (length <= 0 || length > MAX_SANE_DIMENSION) {
                        fprintf(stderr, "ERROR: Invalid length: %ld (Max: %d)\n",
                                length, MAX_SANE_DIMENSION);
                        return PPM_FORMAT_ERROR;
                    }
                    head.length = length;
                    iPhase++;
                    fFlash = 1;
                    break;
                }

                case PHASE_MAX_COLOR: {
                    long maxCol = safe_atol(szLine);
                    if (maxCol <= 0 || maxCol > MAX_SANE_COLOR) {
                        fprintf(stderr, "ERROR: Invalid max color: %ld (Max: %d)\n",
                                maxCol, MAX_SANE_COLOR);
                        return PPM_FORMAT_ERROR;
                    }
                    head.maxCol = maxCol;
                    fLoop = 0;
                    break;
                }

                default:
                    fprintf(stderr, "ERROR: Invalid parsing phase: %d\n", iPhase);
                    return PPM_FORMAT_ERROR;
            }
        }
    }

    /* Stack integrity check */
    if (stack_canary != 0xDEADBEEF) {
        fprintf(stderr, "CRITICAL: Stack corruption detected\n");
        abort();
    }

    /* Debug output (optional) */
    fprintf(stderr, "PPM Header: %ldx%ld, max color: %ld\n",
            head.width, head.length, head.maxCol);

    return PPM_OK;
}
