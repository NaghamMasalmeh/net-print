/* $Id: compress.h,v 1.3 2005/06/21 11:49:59 cvs Exp $ */

/* 
* Copyright (C) 2003-2013 Brother. Industries, Ltd.
*
* This program is free software; you can redistribute it and/or modify it
* under the terms of the GNU General Public License as published by the Free
* Software Foundation; either version 2 of the License, or (at your option)
* any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
* more details.
*
* You should have received a copy of the GNU General Public License along with
* this program; if not, write to the Free Software Foundation, Inc., 59 Temple
* Place, Suite 330, Boston, MA  02111-1307  USA
*/
/*=================================================================================*
*FileName:     	compress.h
*Description:	variable and function declarations for source line data and compression
*Revision:     	1.0									
*Date:         	2003.08.28							
*Author:       	Chenxujin , SteadyBJ 									
*Histroy:      	1.Chenxujin , Create
*==================================================================================*/
#ifndef _COMPRESS_H_
#define	_COMPRESS_H_

#include "pd.h"

#ifdef _cplusplus
extern "C" {
#endif/*_cplusplus*/

extern	MODE9		compData ;
extern	unsigned char *	Planes[ ]  ;

extern	short	CreateCompressBuf(unsigned long lSourceLen , unsigned long lSourceHeight ) ;
extern	void	DestroyCompressBuf() ;

#ifdef _STDBJ_LINUX_        // modified by liubin 2005.6.18
extern	unsigned char*	CreateBandBuf( unsigned long lBytesPerLine , short line) ;
#else
extern	short	CreateBandBuf( unsigned long lBytesPerLine , short line ) ;
#endif
extern	void	DestroyBandBuf() ;

#ifdef _cplusplus
}
#endif/*_cplusplus*/

#endif	/*_COMPRESS_H_*/
