#ifndef	_STATUS_H_
#define	_STATUS_H_

/*
 * Ptouch status definitions-------begin-----
 * Copied from PrinterDef.h in Ptouch Tioga driver
 */

//PrinterStatus::errCode[0]
#define PrinterErr_NoMedia      (0x01)		/* No media when printing */
#define PrinterErr_MediaEnd     (0x02)		/* End of media (die-cut size only) */
#define PrinterErr_Cutter       0x04

// on Linux it is unnecessary
#define PrinterErr_LowPower     0x08


#define PrinterErr_Busy         0x10
#define PrinterErr_PowerOff     0x20
#define PrinterErr_AC           0x40

//PrinterStatus::errCode[1]
// on Linux both are unnecessary
#define PrinterErr_MediaChg     0x01
#define PrinterErr_PrBufFul     0x02

#define PrinterErr_IOErr        0x04

// on Linux it is unnecessary
#define PrinterErr_RsvBufFul    0x08


#define PrinterErr_CoverOpen    0x10

// on Linux it is unnecessary
#define PrinterErr_Cancel       0x20


#define PrinterErr_Feed         0x40
#define PrinterErr_System       0x80

//PrinterStatus::mediaType
#define mediaType_Unknown       0
#define mediaType_Laminated     1
#define mediaType_Lettering     2
#define mediaType_NonLaminated  3
#define mediaType_Fabric        4
#define mediaType_Stamp         5
#define mediaType_AV            8
#define mediaType_HG            9
#define mediaType_Roll          (10)		/* Continuous length tape */
#define mediaType_Dicut         (11)			/* Die-cut labels */

//PrinterStatus::statType
#define PrinterStatType_Return      (0)		/* Reply to status request */
#define PrinterStatType_PrintEnd    (1)		/* Printing completed */
#define PrinterStatType_Error       (2)		/* Error occurred */
#define PrinterStatType_IFEnd       (3)
#define PrinterStatType_PowerOff    (4)
#define PrinterStatType_Info        (5)		/* Notifications from Ptouch */
#define PrinterStatType_FaseChange  (6)		/* Phase change */

//
//PrinterStatus::faseType
#define PrinterFaseType_Edit        (0x00)	/* Receiving state */
#define PrinterFaseType_Print       (0x01)	/* Printing state */
//PrinterStatus::faseNum1(U),faseNum2(L) for PrinterFaseType_Edit
#define PrinterFaseNum_EditU        0x00
#define PrinterFaseNum_EditL        0x14
#define PrinterFaseNum_FeedU        0x00
#define PrinterFaseNum_FeedL        0x01
//PrinterStatus::faseNum1(U),faseNum2(L) for PrinterFaseType_Print
#define PrinterFaseNum_PrintU       0x00
#define PrinterFaseNum_PrintL       0x00
#define PrinterFaseNum_CutPauseU    0x00
#define PrinterFaseNum_CutPauseL    0x0A
#define PrinterFaseNum_CoverOpenU   0x00
#define PrinterFaseNum_CoverOpenL   0x14
#define PrinterFaseNum_CoverCloseU  0x00
#define PrinterFaseNum_CoverCloseL  0x19

//PrinterStatus::infoNum
#define PrinterInfoNum_Void         (0x00)	/* Not available */
#define PrinterInfoNum_CoverOpen    (0x01)	/* Cover opened */
#define PrinterInfoNum_CoverClose   (0x02)	/* Cover closed */
#define PrinterInfoNum_CoolingStart (0x03)	/* Cooling starting */
#define PrinterInfoNum_CoolingEnd   (0x04)	/* Cooling finished */

typedef struct {
    char mark;
    char size;
    char brother;
    char series;
    char model;
    char country;
} PrinterStatusHeader;

typedef struct {
    char header[6];
    char unused1;
    char unused2;
    char errCode[2];
	char mediaWidth;
    char mediaType;
    char color;
    char font;
    char fontJ;
    char mode; 
    char density;
    char mediaLength;
    char statType;
    char faseType;
    char faseNum1;
    char faseNum2;
    char infoNum;
    char extLen;
    char hard[8];
} PrinterStatus;

/*
 * Ptouch status definitions--------end------
 */






#endif
