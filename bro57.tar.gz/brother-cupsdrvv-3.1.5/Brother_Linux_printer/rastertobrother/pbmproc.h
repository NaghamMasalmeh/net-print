/* $Id: pbmproc.h,v 1.3 2005/07/27 03:52:21 cvs Exp $ */
/*
* Copyright (C) 2004-2013 Brother. Industries, Ltd.
*
* This program is free software; you can redistribute it and/or modify it
* under the terms of the GNU General Public License as published by the Free
* Software Foundation; either version 2 of the License, or (at your option)
* any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
* more details.
*
* You should have received a copy of the GNU General Public License along with
* this program; if not, write to the Free Software Foundation, Inc., 59 Temple
* Place, Suite 330, Boston, MA  02111-1307  USA
*
* In addition, as a special exception, Brother Industries, Ltd. gives
* permission to link the code of this program with certain libraries covered
* by BROTHER PRINTER DRIVER SOFTWARE PUBLIC LICENSE AGREEMENT, and distribute
* linked combinations including the two.  You must obey the GNU General Public
* License in all respects for all of the code used other than the libraries as
* stipulated in the above.  If you modify this file, you may extend this
* exception to your version of the file, but you are not obligated to do so.
* If you do not wish to do so, delete this exception statement from your
* version.
*/

#ifndef __PBM_PROC_H__
#define __PBM_PROC_H__

#define	PBM_MAX_COMMENT		(70)	

#define	PPMB_MAGIC_NUMBER	"P6"	


enum{
	PHASE_MG_NUMBER	= 0,	
	PHASE_WIDTH,			
	PHASE_LENGTH,			
	PHASE_MAX_COLOR,		

	PHASE_NUM
};

typedef struct{
	long	width;			
	long	length;			
	long	maxCol;			
} PPM_HEAD;


extern	int		ReadPpmFileHeader( FILE *fp , int iPageCount );


#endif
