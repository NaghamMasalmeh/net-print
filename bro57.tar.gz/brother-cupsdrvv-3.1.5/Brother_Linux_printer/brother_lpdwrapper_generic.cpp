#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <cstdlib>
#include <cstdio>
#include <sys/file.h> // For flock
#include <unistd.h>   // For close, getpid
#include <regex>      // For regex operations
#include <functional> // For std::function
#include <utility>    // For std::pair

// Global variables translated from Perl
std::string ppdcust = "";

// log functions
std::string LOGFILE = "/tmp/br_cupswrapper_ink.log";
int LOGLEVEL = 7;
int LOG_LATESTONLY = 1;
int DEVICEURILOCK = 1;
int LPD_DEBUG = 0;
int LOG_FIRSTTIME = 1;
int DEBUG = 0;

int width = -1;
int height = -1;

std::string basedir = "";

// Unit conversion functions
std::pair<int, int> pt2dot(double xi, double yi) {
    double xo = xi * 600.0 / 72.0;
    double yo = yi * 600.0 / 72.0;
    return {static_cast<int>(xo), static_cast<int>(yo)};
}
std::pair<int, int> mm2dot(double xi, double yi) {
    double xo = xi * 6000.0 / 254.0;
    double yo = yi * 6000.0 / 254.0;
    return {static_cast<int>(xo), static_cast<int>(yo)};
}
std::pair<int, int> inch2dot(double xi, double yi) {
    double xo = xi * 600.0;
    double yo = yi * 600.0;
    return {static_cast<int>(xo), static_cast<int>(yo)};
}
std::pair<int, int> cm2dot(double xi, double yi) {
    double xo = xi * 60000.0 / 254.0;
    double yo = yi * 60000.0 / 254.0;
    return {static_cast<int>(xo), static_cast<int>(yo)};
}
std::pair<int, int> m2dot(double xi, double yi) {
    double xo = xi * 6000000.0 / 254.0;
    double yo = yi * 6000000.0 / 254.0;
    return {static_cast<int>(xo), static_cast<int>(yo)};
}
std::pair<int, int> ft2dot(double xi, double yi) {
    double xo = xi * 600.0 * 12.0;
    double yo = yi * 600.0 * 12.0;
    return {static_cast<int>(xo), static_cast<int>(yo)};
}

// Map for unit conversion functions
std::map<std::string, std::function<std::pair<int, int>(double, double)>> units = {
    {"pt",   &pt2dot},
    {"mm",   &mm2dot},
    {"inch", &inch2dot},
    {"in",   &inch2dot},
    {"cm",   &cm2dot},
    {"m",    &m2dot},
    {"ft",   &ft2dot}
};

std::string LPDCONFIGEXE = "brprintconfpt1_";

std::string INPUT_PS = "/tmp/br_cupswrapper_ink_input.ps";
std::string OUTPUT_PRN = "/tmp/br_cupswrapper_ink_output.prn";

// Configuration data translated from Perl hashes
std::map<std::string, std::map<std::string, std::string>> vendor_commandline = {
    {"BrPriority=BrSpeed",                  {{"opt", "-quality"}, {"val", "SPEED"}}},
    {"BrPriority=BrQuality",                {{"opt", "-quality"}, {"val", "QUALITY"}}},
    {"BrCompress=OFF",                      {{"opt", "-compress"}, {"val", "OFF"}}},
    {"BrCompress=ON",                       {{"opt", "-compress"}, {"val", "ON"}}},
    {"BrCutAtEnd=OFF",                      {{"opt", "-cutend"}, {"val", "OFF"}}},
    {"BrCutAtEnd=ON",                       {{"opt", "-cutend"}, {"val", "ON"}}},
    {"BrTrimtape=OFF",                      {{"opt", "-trimtape"}, {"val", "OFF"}}},
    {"BrTrimtape=ON",                       {{"opt", "-trimtape"}, {"val", "ON"}}},
    {"BrMirror=OFF",                        {{"opt", "-mirro"}, {"val", "OFF"}}},
    {"BrMirror=ON",                         {{"opt", "-mirro"}, {"val", "ON"}}},
    {"BrHalftonePattern=BrBinary",          {{"opt", "-half"}, {"val", "BINARY"}}},
    {"BrHalftonePattern=BrDither",          {{"opt", "-half"}, {"val", "DITHER"}}},
    {"BrHalftonePattern=BrErrorDiffusion",  {{"opt", "-half"}, {"val", "ERROR"}}},

    {"PageSize=17x54",                  {{"opt", "-media"}, {"val", "17x54"}}},
    {"PageSize=17x87",                  {{"opt", "-media"}, {"val", "17x87"}}},
    {"PageSize=23x23",                  {{"opt", "-media"}, {"val", "23x23"}}},
    {"PageSize=29x42",                  {{"opt", "-media"}, {"val", "29x42"}}},
    {"PageSize=29x90",                  {{"opt", "-media"}, {"val", "29x90"}}},
    {"PageSize=38x90",                  {{"opt", "-media"}, {"val", "38x90"}}},
    {"PageSize=39x48",                  {{"opt", "-media"}, {"val", "39x48"}}},
    {"PageSize=52x29",                  {{"opt", "-media"}, {"val", "52x29"}}},
    {"PageSize=62x29",                  {{"opt", "-media"}, {"val", "62x29"}}},
    {"PageSize=62x100",                 {{"opt", "-media"}, {"val", "62x100"}}},
    {"PageSize=60x86",                  {{"opt", "-media"}, {"val", "60x86"}}},
    {"PageSize=12Dia",                  {{"opt", "-media"}, {"val", "12Dia"}}},
    {"PageSize=24Dia",                  {{"opt", "-media"}, {"val", "24Dia"}}},
    {"PageSize=58Dia",                  {{"opt", "-media"}, {"val", "58Dia"}}},
    {"PageSize=12X1",                   {{"opt", "-media"}, {"val", "12X1"}}},
    {"PageSize=29X1",                   {{"opt", "-media"}, {"val", "29X1"}}},
    {"PageSize=38X1",                   {{"opt", "-media"}, {"val", "38X1"}}},
    {"PageSize=50X1",                   {{"opt", "-media"}, {"val", "50X1"}}},
    {"PageSize=54X1",                   {{"opt", "-media"}, {"val", "54X1"}}},
    {"PageSize=62X1",                   {{"opt", "-media"}, {"val", "62X1"}}},
    {"PageSize=12X2",                   {{"opt", "-media"}, {"val", "12X2"}}},
    {"PageSize=29X2",                   {{"opt", "-media"}, {"val", "29X2"}}},
    {"PageSize=38X2",                   {{"opt", "-media"}, {"val", "38X2"}}},
    {"PageSize=50X2",                   {{"opt", "-media"}, {"val", "50X2"}}},
    {"PageSize=54X2",                   {{"opt", "-media"}, {"val", "54X2"}}},
    {"PageSize=62X2",                   {{"opt", "-media"}, {"val", "62X2"}}},
    {"PageSize=12X3",                   {{"opt", "-media"}, {"val", "12X3"}}},
    {"PageSize=29X3",                   {{"opt", "-media"}, {"val", "29X3"}}},
    {"PageSize=38X3",                   {{"opt", "-media"}, {"val", "38X3"}}},
    {"PageSize=50X3",                   {{"opt", "-media"}, {"val", "50X3"}}},
    {"PageSize=54X3",                   {{"opt", "-media"}, {"val", "54X3"}}},
    {"PageSize=62X3",                   {{"opt", "-media"}, {"val", "62X3"}}},
    {"PageSize=12X4",                   {{"opt", "-media"}, {"val", "12X4"}}},
    {"PageSize=29X4",                   {{"opt", "-media"}, {"val", "29X4"}}},
    {"PageSize=38X4",                   {{"opt", "-media"}, {"val", "38X4"}}},
    {"PageSize=50X4",                   {{"opt", "-media"}, {"val", "50X4"}}},
    {"PageSize=54X4",                   {{"opt", "-media"}, {"val", "54X4"}}},
    {"PageSize=62X4",                   {{"opt", "-media"}, {"val", "62X4"}}},
    {"PageSize=BrL",                   {{"opt", "-media"}, {"val", "*"}}},
};

std::map<std::string, std::map<std::string, std::string>> DefaultPageSize = {
    {"17x54",                  {{"opt", "-media"}, {"val", "17x54"}}},
    {"17x87",                  {{"opt", "-media"}, {"val", "17x87"}}},
    {"23x23",                  {{"opt", "-media"}, {"val", "23x23"}}},
    {"29x42",                  {{"opt", "-media"}, {"val", "29x42"}}},
    {"29x90",                  {{"opt", "-media"}, {"val", "29x90"}}},
    {"38x90",                  {{"opt", "-media"}, {"val", "38x90"}}},
    {"39x48",                  {{"opt", "-media"}, {"val", "39x48"}}},
    {"52x29",                  {{"opt", "-media"}, {"val", "52x29"}}},
    {"62x29",                  {{"opt", "-media"}, {"val", "62x29"}}},
    {"62x100",                 {{"opt", "-media"}, {"val", "62x100"}}},
    {"60x86",                  {{"opt", "-media"}, {"val", "60x86"}}},
    {"12Dia",                  {{"opt", "-media"}, {"val", "12Dia"}}},
    {"24Dia",                  {{"opt", "-media"}, {"val", "24Dia"}}},
    {"58Dia",                  {{"opt", "-media"}, {"val", "58Dia"}}},
    {"12X1",                   {{"opt", "-media"}, {"val", "12X1"}}},
    {"29X1",                   {{"opt", "-media"}, {"val", "29X1"}}},
    {"38X1",                   {{"opt", "-media"}, {"val", "38X1"}}},
    {"50X1",                   {{"opt", "-media"}, {"val", "50X1"}}},
    {"54X1",                   {{"opt", "-media"}, {"val", "54X1"}}},
    {"62X1",                   {{"opt", "-media"}, {"val", "62X1"}}},
    {"12X2",                   {{"opt", "-media"}, {"val", "12X2"}}},
    {"29X2",                   {{"opt", "-media"}, {"val", "29X2"}}},
    {"38X2",                   {{"opt", "-media"}, {"val", "38X2"}}},
    {"50X2",                   {{"opt", "-media"}, {"val", "50X2"}}},
    {"54X2",                   {{"opt", "-media"}, {"val", "54X2"}}},
    {"62X2",                   {{"opt", "-media"}, {"val", "62X2"}}},
    {"12X3",                   {{"opt", "-media"}, {"val", "12X3"}}},
    {"29X3",                   {{"opt", "-media"}, {"val", "29X3"}}},
    {"38X3",                   {{"opt", "-media"}, {"val", "38X3"}}},
    {"50X3",                   {{"opt", "-media"}, {"val", "50X3"}}},
    {"54X3",                   {{"opt", "-media"}, {"val", "54X3"}}},
    {"62X3",                   {{"opt", "-media"}, {"val", "62X3"}}},
    {"12X4",                   {{"opt", "-media"}, {"val", "12X4"}}},
    {"29X4",                   {{"opt", "-media"}, {"val", "29X4"}}},
    {"38X4",                   {{"opt", "-media"}, {"val", "38X4"}}},
    {"50X4",                   {{"opt", "-media"}, {"val", "50X4"}}},
    {"54X4",                   {{"opt", "-media"}, {"val", "54X4"}}},
    {"62X4",                   {{"opt", "-media"}, {"val", "62X4"}}},
    {"BrL",                   {{"opt", "-media"}, {"val", "*"}}},
};
std::map<std::string, std::map<std::string, std::string>> DefaultBrPriority = {
    {"BrSpeed",                  {{"opt", "-quality"}, {"val", "SPEED"}}},
    {"BrQuality",                {{"opt", "-quality"}, {"val", "QUALITY"}}},
};
std::map<std::string, std::map<std::string, std::string>> DefaultBrCompress = {
    {"OFF",                      {{"opt", "-compress"}, {"val", "OFF"}}},
    {"ON",                       {{"opt", "-compress"}, {"val", "ON"}}},
};
std::map<std::string, std::map<std::string, std::string>> DefaultBrCutAtEnd = {
    {"OFF",                      {{"opt", "-cutend"}, {"val", "OFF"}}},
    {"ON",                       {{"opt", "-cutend"}, {"val", "ON"}}},
};
std::map<std::string, std::map<std::string, std::string>> DefaultBrTrimtape = {
    {"OFF",                      {{"opt", "-trimtape"}, {"val", "OFF"}}},
    {"ON",                       {{"opt", "-trimtape"}, {"val", "ON"}}},
};
std::map<std::string, std::map<std::string, std::string>> DefaultBrMirror = {
    {"OFF",                     {{"opt", "-mirro"}, {"val", "OFF"}}},
    {"ON",                      {{"opt", "-mirro"}, {"val", "ON"}}},
};
std::map<std::string, std::map<std::string, std::string>> DefaultBrHalftonePattern = {
    {"BrErrorDiffusion",     {{"opt", "-half"}, {"val", "ERROR"}}},
    {"BrDither",             {{"opt", "-half"}, {"val", "DITHER"}}},
    {"BrBinary",             {{"opt", "-half"}, {"val", "BINARY"}}},
};
std::map<std::string, std::map<std::string, std::string>> DefaultBrBrightness = {
    {"*",               {{"opt", "-brit"}, {"val", "*"}}},
};
std::map<std::string, std::map<std::string, std::string>> DefaultBRContrast = {
    {"*",               {{"opt", "-cont"}, {"val", "*"}}},
};
std::map<std::string, std::map<std::string, std::string>> DefaultBrMargin = {
    {"*",               {{"opt", "-feed"}, {"val", "*"}}},
};
std::map<std::string, std::map<std::string, std::string>> DefaultBrCutLabel = {
    {"*",               {{"opt", "-cutlabel"}, {"val", "*"}}},
};

std::map<std::string, std::map<std::string, std::string>> numeric_option = {
    {"BRBrightness",                {{"opt", "-brit"}, {"val", "*"}}},
    {"BRContrast",                  {{"opt", "-cont"}, {"val", "*"}}},
    {"BrMargin",                    {{"opt", "-feed"}, {"val", "*"}}},
    {"BrCutLabel",                  {{"opt", "-cutlabel"}, {"val", "*"}}},
};



std::map<std::string, std::string> initial_configuration = {
    {"-quality",      "SPEED"},
    {"-compress",     "OFF"},
    {"-cutend",       "OFF"},
    {"-media",        "29x90"},
    {"-trimtape",     "ON"},
    {"-mirro",        "OFF"},
    {"-half",         "ERROR"},
    {"-feed",         "3"},
    {"-brit",         "0"},
    {"-cont",         "0"},
    {"-cutlabel",     "1"},
};
// Map of pointers to the default option maps
std::map<std::string, const std::map<std::string, std::map<std::string, std::string>>*> ppddefaultslist = {
    {"DefaultPageSize",                         &DefaultPageSize},
    {"DefaultBrPriority",                       &DefaultBrPriority},
    {"DefaultBrCompress",                       &DefaultBrCompress},
    {"DefaultBrCutAtEnd",                       &DefaultBrCutAtEnd},
    {"DefaultBrTrimtape",                       &DefaultBrTrimtape},
    {"DefaultBrMirror",                         &DefaultBrMirror},
    {"DefaultBrHalftonePattern",                &DefaultBrHalftonePattern},
    {"DefaultBrBrightness",                     &DefaultBrBrightness},
    {"DefaultBRContrast",                       &DefaultBRContrast},
    {"DefaultBrMargin",                         &DefaultBrMargin},
    {"DefaultBrCutLabel",                       &DefaultBrCutLabel},
};

std::map<std::string, const std::map<std::string, std::map<std::string, std::string>>*> mediaoptlist = {
    {"DefaultPageSize",      &DefaultPageSize},
};

std::string TEMPRC = "";
std::string LATESTINFO = "";
std::string LOCKFILE = "";
int lock_fd = -1; // File descriptor for flock

// logprint function translated from Perl
void logprint(int level, const std::string& data) {
    if (DEBUG != 0) {
        std::ofstream log_file;
        if (LOG_FIRSTTIME) {
            log_file.open(LOGFILE, std::ios::out);
            LOG_FIRSTTIME = false;
        } else {
            log_file.open(LOGFILE, std::ios::app);
        }
        if (log_file.is_open() && level < LOGLEVEL) {
            log_file << data << std::endl;
        }
    }
}

// set_option_table function translated from Perl
void set_option_table(const std::map<std::string, std::map<std::string, std::string>>& table,
                      const std::string& key,
                      const std::string& value,
                      std::map<std::string, std::string>& lpr_options) {
    auto it = table.find(key);
    if (it != table.end()) {
        const auto& cmdref = it->second;
        auto opt_it = cmdref.find("opt");
        auto val_it = cmdref.find("val");

        if (opt_it != cmdref.end() && val_it != cmdref.end()) {
            const std::string& opt = opt_it->second;
            const std::string& val = val_it->second;

            logprint(2, opt + "  <=  " + (lpr_options.count(opt) ? lpr_options[opt] : "N/A") + "  : (" + value + ")\n");

            if (lpr_options.count(opt)) {
                lpr_options[opt] = val;
                logprint(2, opt + "  <=  " + lpr_options[opt] + "  : (" + value + ")\n");

                if (opt == "-media" && value.rfind("BrL", 0) == 0) { // value starts with BrL
                    std::string PAPERINF = basedir + "/inf/paperinf" + getenv("PRINTER"); // Use getenv for PRINTER

                    std::ifstream fprcfile(PAPERINF);
                    std::string line;
                    std::string paper_name = "";
                    while (std::getline(fprcfile, line)) {
                        // chomp line
                        if (!line.empty() && line.back() == '\r') line.pop_back();
                        if (!line.empty() && line.back() == '\n') line.pop_back();

                        size_t colon_pos = line.find(':');
                        if (colon_pos != std::string::npos) {
                            std::string paper_part = line.substr(0, colon_pos);
                            std::string name_part = line.substr(colon_pos + 1);

                            size_t slash_pos = paper_part.find('/');
                            std::string paper_val = (slash_pos != std::string::npos) ? paper_part.substr(0, slash_pos) : paper_part;
                            paper_name = (slash_pos != std::string::npos) ? paper_part.substr(slash_pos + 1) : "";

                            // Check if the line starts with the value (e.g., "BrL/...")
                            if (line.rfind(value, 0) == 0) {
                                break; // Found the matching line
                            }
                        }
                    }
                    fprcfile.close();

                    if (!paper_name.empty()) {
                         lpr_options[opt] = paper_name;
                    } else {
                         // Fallback or error handling if name not found? Original Perl doesn't explicitly handle not found.
                         // Keep the '*' value set earlier or the original value? Perl sets $lpr_options_ref->{$opt} = $name;
                         // If $name is empty, it sets it to empty. Let's set it to empty if not found.
                         lpr_options[opt] = "";
                    }
                }
                if (opt == "-brit" || opt == "-cont" || opt == "-feed" || opt == "-cutlabel") {
                    lpr_options[opt] = value;
                }
            }
        }

        auto opt2_it = cmdref.find("opt2");
        auto val2_it = cmdref.find("val2");
        if (opt2_it != cmdref.end() && val2_it != cmdref.end()) {
            const std::string& opt2 = opt2_it->second;
            const std::string& val2 = val2_it->second;
            if (lpr_options.count(opt2)) {
                lpr_options[opt2] = val2;
                logprint(2, opt2 + "  <=  " + lpr_options[opt2] + "  : (" + value + ")\n");

                if (opt2 == "-pt" && val2 == "BrL") {
                    ppdcust = value;
                }
            }
        }
    }
}

// set_option_table_n function translated from Perl
// Note: This function appears unused in the original Perl main logic.
// It's translated here for completeness but might not be necessary for functionality.
void set_option_table_n(std::map<std::string, std::map<std::string, std::string>>& table,
                        const std::string& key,
                        const std::string& value,
                        std::map<std::string, std::string>& lpr_options) {
    auto it = table.find(key);
    if (it != table.end()) {
        it->second["val"] = value; // Modify the value in the table
        // Call set_option_table with the modified table entry
        // This part is tricky as set_option_table expects a const ref to the table.
        // The Perl code modifies the hash entry *in place* before calling set_option_table.
        // A direct C++ translation would require passing a non-const reference or re-finding the entry.
        // Given the original code's structure, it seems it intended to update the 'val' in the *global* numeric_option map
        // and then use that updated map entry. However, the main logic doesn't call this function.
        // If it were called, it would need to pass the global numeric_option map.
        // Let's simulate the intended behavior if it *were* called, by finding the entry again.
        // This function's utility is questionable based on the provided Perl.
        // We will translate it literally, assuming it *might* be called elsewhere or was experimental.
        // It modifies the global `numeric_option` map.
        set_option_table(numeric_option, key, "", lpr_options); // Pass the global map
    }
}


// check_custom_paper function translated from Perl
// Note: This function is commented out in the original Perl main logic.
// It's translated here for completeness but might not be necessary for functionality.
std::pair<std::string, std::string> check_custom_paper(const std::string& PPD,
                                                      const std::map<std::string, std::string>& lpr_options) {
    double x = 0;
    double y = 0;
    std::function<std::pair<int, int>(double, double)> unitfunc;
    std::string unit = "";
    std::string ssize = "";

    auto pt_it = lpr_options.find("-pt");
    if (pt_it != lpr_options.end()) {
        const std::string& pt_val = pt_it->second;

        if (pt_val == "CUSTOM0") {
            ssize = ppdcust;
            // s/^Custom\.//g
            ssize = std::regex_replace(ssize, std::regex("^Custom\\."), "");

            // Find unit suffix
            for (const auto& pair : units) {
                const std::string& u = pair.first;
                if (ssize.size() >= u.size() && ssize.substr(ssize.size() - u.size()) == u) {
                    logprint(2, "HIT " + u + "\n");
                    unit = u;
                    unitfunc = units[u];
                    break;
                }
            }

            // s/$unit$//g
            if (!unit.empty()) {
                 ssize = std::regex_replace(ssize, std::regex(unit + "$"), "");
            }

            size_t x_pos = ssize.find('x');
            if (x_pos != std::string::npos) {
                std::string sx = ssize.substr(0, x_pos);
                std::string sy = ssize.substr(x_pos + 1);
                try {
                    double dx = std::stod(sx);
                    double dy = std::stod(sy);
                    if (unitfunc) {
                        std::pair<int, int> dots = unitfunc(dx, dy);
                        x = dots.first;
                        y = dots.second;
                        return {std::to_string(static_cast<int>(x)), std::to_string(static_cast<int>(y))};
                    }
                } catch (const std::exception& e) {
                    // Handle conversion error if necessary
                }
            }

        } else if (pt_val.rfind("CUSTOM", 0) == 0) { // Starts with CUSTOM
            std::string tmp = "*PaperDimension " + pt_val;
            std::string command = "grep \"" + tmp + "\" " + PPD;
            FILE* pipe = popen(command.c_str(), "r");
            if (!pipe) {
                logprint(0, "Error executing grep for PaperDimension\n");
                return {"{Undefined}", "{Undefined}"};
            }
            char buffer[128];
            ssize = "";
            while (fgets(buffer, sizeof(buffer), pipe) != NULL) {
                ssize += buffer;
            }
            pclose(pipe);

            // chomp
            if (!ssize.empty() && ssize.back() == '\n') ssize.pop_back();

            // s/\"$//
            if (!ssize.empty() && ssize.back() == '"') ssize.pop_back();
            // s/^.*\"//
            size_t quote_pos = ssize.find('"');
            if (quote_pos != std::string::npos) {
                ssize = ssize.substr(quote_pos + 1);
            }

            std::string sx, sy;
            size_t space_pos = ssize.find(' ');
            if (space_pos != std::string::npos) {
                sx = ssize.substr(0, space_pos);
                sy = ssize.substr(space_pos + 1);
                try {
                    double dx = std::stod(sx);
                    double dy = std::stod(sy);
                    std::pair<int, int> dots = pt2dot(dx, dy);
                    x = dots.first;
                    y = dots.second;
                    return {std::to_string(static_cast<int>(x)), std::to_string(static_cast<int>(y))};
                } catch (const std::exception& e) {
                    // Handle conversion error
                }
            }
        }
    }

    return {"{Undefined}", "{Undefined}"};
}


// set_options function translated from Perl
std::map<std::string, std::string> set_options(const std::string& PPD, const std::string& cmdoptions) {
    std::map<std::string, std::string> cmdopt;

    // get command line options
    std::string current_cmdoptions = cmdoptions;
    size_t pos = 0;
    std::string token;
    while ((pos = current_cmdoptions.find(' ')) != std::string::npos) {
        token = current_cmdoptions.substr(0, pos);
        size_t eq_pos = token.find('=');
        if (eq_pos != std::string::npos) {
            cmdopt[token.substr(0, eq_pos)] = token.substr(eq_pos + 1);
        }
        current_cmdoptions.erase(0, pos + 1);
    }
    // Process the last token
    if (!current_cmdoptions.empty()) {
        size_t eq_pos = current_cmdoptions.find('=');
        if (eq_pos != std::string::npos) {
            cmdopt[current_cmdoptions.substr(0, eq_pos)] = current_cmdoptions.substr(eq_pos + 1);
        }
    }

    // get PPD options
    std::vector<std::string> ppddefaults;
    std::string grep_command = "grep '^*Default' " + PPD;
    FILE* pipe = popen(grep_command.c_str(), "r");
    if (!pipe) {
        logprint(0, "Error executing grep for PPD defaults\n");
        // Return initial config or handle error? Original Perl continues.
    } else {
        char buffer[256];
        while (fgets(buffer, sizeof(buffer), pipe) != NULL) {
            std::string line = buffer;
            // chomp
            if (!line.empty() && line.back() == '\n') line.pop_back();
            ppddefaults.push_back(line);
        }
        pclose(pipe);
    }

    std::map<std::string, std::string> ppdopt;
    for (const auto& line : ppddefaults) {
        std::string label = line;
        // s/^\*//g
        label = std::regex_replace(label, std::regex("^\\*"), "");
        // s/: .*$//g
        label = std::regex_replace(label, std::regex(": .*$"), "");

        std::string value = line;
        // s/^.*: //g
        value = std::regex_replace(value, std::regex("^.*: "), "");
        ppdopt[label] = value;
    }

    std::map<std::string, std::string> lpr_options = initial_configuration;

    // set ppd options
    logprint(2, "\nSET PPD OPTIONS\n");
    for (const auto& pair : ppdopt) {
        const std::string& option_name = pair.first;
        const std::string& option_value = pair.second;

        auto ppdoptdb_it = ppddefaultslist.find(option_name);
        if (ppdoptdb_it != ppddefaultslist.end()) {
            const auto* list_ptr = ppdoptdb_it->second; // Pointer to the nested map
            if (list_ptr) {
                const auto& list = *list_ptr; // Dereference the pointer

                for (const auto& list_pair : list) {
                    const std::string& key = list_pair.first;
                    std::regex tmp("^" + key + "$");
                    if (std::regex_search(option_value, tmp)) {
                        set_option_table(list, key, option_value, lpr_options);
                    }

                    // Special case from Perl: DefaultPageSize BrL
                    if (option_name == "DefaultPageSize") {
                        if (option_value.rfind("BrL", 0) == 0 && key == "BrL") { // starts with BrL
                            logprint(2, "\nSet PPD OPTIONS 6   " + key + " " + option_value + "\n");
                            set_option_table(list, key, option_value, lpr_options);
                        }
                    }
                }
            }
        }
    }

    // set Vendor options (string)
    logprint(2, "\nSET VENDOR COMMAND OPTIONS\n");
    for (const auto& pair : cmdopt) {
        const std::string& option_name = pair.first;
        const std::string& option_value = pair.second;
        std::string option_name_value = option_name + "=" + option_value;

        for (const auto& vendor_pair : vendor_commandline) {
            const std::string& key = vendor_pair.first;
            std::regex tmp("^" + key + "$");

            // Special case from Perl: PageSize=BrL
            if (option_value.rfind("BrL", 0) == 0 && key == "PageSize=BrL") { // starts with BrL
                 set_option_table(vendor_commandline, key, option_value, lpr_options);
            }

            if (std::regex_search(option_name_value, tmp)) {
                set_option_table(vendor_commandline, key, option_value, lpr_options);
            }
        }
    }

    logprint(2, "\nSET PPD CMD OPTIONS\n");
    for (const auto& pair : cmdopt) {
        const std::string& option_name = "Default" + pair.first;
        const std::string& option_value = pair.second;

        auto ppdoptdb_it = ppddefaultslist.find(option_name);
        if (ppdoptdb_it != ppddefaultslist.end()) {
            const auto* list_ptr = ppdoptdb_it->second; // Pointer to the nested map
            if (list_ptr) {
                const auto& list = *list_ptr; // Dereference the pointer

                for (const auto& list_pair : list) {
                    const std::string& key = list_pair.first;
                    std::regex tmp("^" + key + "$");
                    if (std::regex_search(option_value, tmp)) {
                        set_option_table(list, key, option_value, lpr_options);
                    }
                }
            }
        }
    }

    // set Vendor options (numeric) - This block is commented out in Perl
    // logprint( 2 ,   "\nSET VENDOR NUMERIC COMMAND OPTIONS\n");
    // foreach(keys %cmdopt){
    //     my $option_name  =  $_ ;
    //     my $n_value      =  $cmdopt{$_} ;
    //     &set_option_table_n( \%numeric_option ,
    //                          $option_name  ,
    //                          $n_value,
    //                          \%lpr_options);
    // }

    // set MEDIA extension options
    logprint(2, "\nSET MEDIA (STANDARD) COMMAND OPTIONS\n");
    auto media_it = cmdopt.find("media");
    if (media_it != cmdopt.end()) {
        std::string media_options_str = media_it->second;
        size_t media_pos = 0;
        std::string media_token;
        while ((media_pos = media_options_str.find(',')) != std::string::npos) {
            media_token = media_options_str.substr(0, media_pos);
            for (const auto& optlist_pair : mediaoptlist) {
                const auto* cur_opttbl_ptr = optlist_pair.second;
                 if (cur_opttbl_ptr) {
                    const auto& cur_opttbl = *cur_opttbl_ptr;
                    for (const auto& cur_opt_pair : cur_opttbl) {
                        const std::string& key = cur_opt_pair.first;
                        std::regex tmp("^" + key + "$");
                        if (std::regex_search(media_token, tmp)) {
                            set_option_table(cur_opttbl, key, media_token, lpr_options);
                        }
                    }
                }
            }
            media_options_str.erase(0, media_pos + 1);
        }
        // Process the last token
        if (!media_options_str.empty()) {
            for (const auto& optlist_pair : mediaoptlist) {
                const auto* cur_opttbl_ptr = optlist_pair.second;
                 if (cur_opttbl_ptr) {
                    const auto& cur_opttbl = *cur_opttbl_ptr;
                    for (const auto& cur_opt_pair : cur_opttbl) {
                        const std::string& key = cur_opt_pair.first;
                        std::regex tmp("^" + key + "$");
                        if (std::regex_search(media_options_str, tmp)) {
                            set_option_table(cur_opttbl, key, media_options_str, lpr_options);
                        }
                    }
                }
            }
        }
    }

    // Custom paper check - This block is commented out in Perl
    // std::pair<std::string, std::string> custom_dims = check_custom_paper(PPD, lpr_options);
    // if (custom_dims.first != "{Undefined}" && custom_dims.second != "{Undefined}") {
    //     setenv("BRPAPERWIDTH", custom_dims.first.c_str(), 1);
    //     setenv("BRPAPERHEIGHT", custom_dims.second.c_str(), 1);
    //     logprint(0, "\nCUSTOM PAPER x=" + custom_dims.first + " y=" + custom_dims.second + "\n\n");
    // }

    return lpr_options;
}

// exec_lpdconfig function translated from Perl
void exec_lpdconfig(const std::string& basedir, const std::string& PRINTER, const std::map<std::string, std::string>& lpr_options) {
    std::string lpddir = basedir + "/lpd/";
    std::string lpdconf = "/usr/libexec/cups/filter/brother/filter/ql820nwb/lpd/" + LPDCONFIGEXE + "ql820nwb";

    for (const auto& pair : lpr_options) {
        const std::string& op = pair.first;
        const std::string& val = pair.second;
        std::string lpdconf_command = lpdconf + " -P " + PRINTER + " " + op + " " + val + " -rcfile " + TEMPRC;
        logprint(0, lpdconf_command + "\n");
        system(lpdconf_command.c_str());
    }
}

int main(int argc, char* argv[]) {
    // Check minimum arguments (Perl checks @ARGV >= 6, which means 7 args including script name)
    if (argc < 7) {
        // Perl doesn't explicitly handle insufficient args, it just accesses ARGV[0]..ARGV[6]
        // and ARGV[7] if @ARGV >= 8. Let's match the access pattern.
        // The script accesses ARGV[1]..ARGV[6] and ARGV[7].
        // So it needs at least 8 arguments (script name + 7 args).
        // The original code checks @ARGV >= 6, which is confusing given the access pattern.
        // Let's assume it needs at least 7 arguments (ARGV[0] to ARGV[6]).
        // If argc < 7, accessing argv[7] would be out of bounds.
        // Let's match the Perl check @ARGV >= 6, meaning argc >= 7.
        // If argc is exactly 7, ARGV[7] access will be out of bounds in Perl.
        // The Perl code accesses ARGV[7] only if @ARGV >= 8.
        // Let's replicate the Perl logic: access ARGV[7] only if argc >= 8.
    }

    if (DEBUG > 0) {
        LPD_DEBUG = 2;
    }

    // Determine basedir
    // my $basedir = `readlink $0`;
    std::string command_readlink = "readlink " + std::string(argv[0]);
    FILE* pipe_readlink = popen(command_readlink.c_str(), "r");
    if (pipe_readlink) {
        char buffer[256];
        if (fgets(buffer, sizeof(buffer), pipe_readlink) != NULL) {
            basedir = buffer;
        }
        pclose(pipe_readlink);
    }

    // if ( $basedir eq '' ){ $basedir = `realpath $0`; }
    if (basedir.empty()) {
        std::string command_realpath = "realpath " + std::string(argv[0]);
        FILE* pipe_realpath = popen(command_realpath.c_str(), "r");
        if (pipe_realpath) {
            char buffer[256];
            if (fgets(buffer, sizeof(buffer), pipe_realpath) != NULL) {
                basedir = buffer;
            }
            pclose(pipe_realpath);
        }
    }

    // chomp($basedir);
    if (!basedir.empty() && basedir.back() == '\n') basedir.pop_back();

    // $basedir =~ s/$PRINTER\/cupswrapper\/.*$/$PRINTER\//g;
    // Need PRINTER value first. PRINTER is derived from basedir later. This is a circular dependency in the Perl logic.
    // Let's follow the Perl execution order: basedir is calculated first, then PRINTER is derived from basedir.
    // The regex uses the *derived* PRINTER value to modify the *original* basedir. This seems wrong or implies PRINTER is known beforehand or derived differently.
    // Looking at the derivation: $PRINTER=$basedir; ... $PRINTER =~ s/^\/opt\/.*\/PTouch\///g; $PRINTER =~ s/\/cupswrapper//g; $PRINTER =~ s/\///g;
    // This means PRINTER is a cleaned-up version of basedir.
    // The regex `s/$PRINTER\/cupswrapper\/.*$/$PRINTER\//g` on `$basedir` seems to replace the part *after* the derived PRINTER name with just the derived PRINTER name followed by a slash.
    // Example: basedir = /opt/brother/PTouch/pt123/cupswrapper/filter
    // Derived PRINTER = pt123
    // Regex becomes s/pt123\/cupswrapper\/.*$/pt123\//g
    // Resulting basedir = /opt/brother/PTouch/pt123/
    // This seems to set basedir to the printer's root directory.
    // Let's calculate the derived PRINTER first, then apply the regex to basedir.

    std::string derived_PRINTER = basedir;
    
if (std::regex_search(basedir, std::regex("brother_lpdwrapper_\\w+$"))) {
    std::smatch match;
    if (std::regex_search(basedir, match, std::regex("brother_lpdwrapper_(\\w+)$")) && match.size() > 1) {
        derived_PRINTER = match[1];
    }
} else {
    // Fallback to old Perl-style cleanup
    derived_PRINTER = std::regex_replace(derived_PRINTER, std::regex("^/opt/.*?/PTouch/"), "");
    derived_PRINTER = std::regex_replace(derived_PRINTER, std::regex("/cupswrapper"), "");
    derived_PRINTER = std::regex_replace(derived_PRINTER, std::regex("/"), "");
}

    // Now apply the regex to the original basedir using the derived PRINTER
    basedir = "/usr/libexec/cups/filter/brother/filter/" + derived_PRINTER;

    // main
    logprint(0, "START\n");

    std::string cmdoptions = (argc > 4) ? argv[4] : "";
    std::string PPD = getenv("PPD") ? getenv("PPD") : "";
    std::string PRINTER = derived_PRINTER; // Use the derived PRINTER
    std::string CUPSINPUT = "";
    if (argc >= 8) { // Perl @ARGV >= 6 means 7 elements (0..6). Accessing ARGV[7] needs @ARGV >= 8.
        CUPSINPUT = argv[7];
    } else {
        // If ARGV[7] is not provided, CUPSINPUT remains empty.
        // The Perl script reads from STDIN if ARGV[7] is not present.
        // We need to handle reading from STDIN if CUPSINPUT is empty.
        // The Perl code `cat $CUPSINPUT` will read from STDIN if $CUPSINPUT is empty or "-".
        // CUPS typically passes "-" for STDIN. Let's check for empty or "-".
        if (argc >= 7 && std::string(argv[6]) == "-") { // CUPS filter convention
             CUPSINPUT = "-"; // Indicate STDIN
        } else {
             // If ARGV[7] is not present and ARGV[6] is not "-", CUPSINPUT is empty.
             // The original Perl code would still try to `cat ""` which might read STDIN or fail.
             // Let's assume CUPS passes "-" for STDIN when no file is specified.
             // If argc < 7, ARGV[6] is not available. The Perl code would access ARGV[7] only if argc >= 8.
             // If argc is 7, ARGV[7] is not accessed. CUPSINPUT remains empty.
             // The `cat $CUPSINPUT` command in Perl would then be `cat ""`, which typically reads from STDIN.
             // So, if argc < 8, CUPSINPUT should effectively be STDIN. Let's represent STDIN as "-".
             if (argc >= 7) { // Check if ARGV[6] exists
                 // If ARGV[6] exists, it's the input file name or "-".
                 CUPSINPUT = argv[6];
             } else {
                 // If argc < 7, ARGV[6] doesn't exist. CUPSINPUT should be STDIN.
                 CUPSINPUT = "-";
             }
        }
    }


    for (int i = 0; i < argc; ++i) {
        logprint(0, "ARG" + std::to_string(i) + "      = " + argv[i] + "\n");
    }

    logprint(0, "PRINTER   = " + PRINTER + " \n");
    logprint(0, "PPD       = " + PPD + "\n");
    logprint(0, "BASEPATH  = " + basedir + "\n");

    logprint(0, "export PPD=" + PPD + "\n");
    std::string args_str = "";
    for(int i=1; i<argc; ++i) {
        args_str += "\"" + std::string(argv[i]) + "\" ";
    }
    logprint(0, std::string(argv[0]) + " " + args_str + "\n");
std::string printer_data_path = "/usr/libexec/cups/filter/brother/filter/ql820nwb";
setenv("BR_PRT_PATH", printer_data_path.c_str(), 1);  // force path override

// Set path to the actual filter binary
std::string LPDFILTER = printer_data_path + "/filter_" + "ql820nwb";

    logprint(0, "\n");

    // Temporary RC file handling
    TEMPRC = "/tmp/br" + PRINTER + "rc_" + std::to_string(getpid());
   std::string src_rc = "usr/libexec/cups/filter/brother/filter/ql820nwb/inf/brql820nwbrc";


    // Simulate `cp src dest`
    std::ifstream src(src_rc, std::ios::binary);
    std::ofstream dest(TEMPRC, std::ios::binary);
    if (src && dest) {
        dest << src.rdbuf();
    } else {
        logprint(0, "Error copying " + src_rc + " to " + TEMPRC + "\n");
        // Original Perl doesn't die here, just logs. Continue.
    }
    src.close();
    dest.close();

    setenv("BRPRINTERRCFILE", TEMPRC.c_str(), 1); // Overwrite if exists
    logprint(0, "TEMPRC    = " + TEMPRC + "\n");

    // File locking
    std::string device_uri = getenv("DEVICE_URI") ? getenv("DEVICE_URI") : "";
    LOCKFILE = "/tmp/" + PRINTER + "_lf_" + device_uri;

    if (DEVICEURILOCK == 1) {
        lock_fd = open(LOCKFILE.c_str(), O_WRONLY | O_CREAT, 0666);
        if (lock_fd != -1) {
            if (flock(lock_fd, LOCK_EX) != 0) {
                logprint(0, "Error acquiring flock on " + LOCKFILE + "\n");
                // Original Perl doesn't die, just logs. Continue.
            }
        } else {
             logprint(0, "Error opening lock file " + LOCKFILE + "\n");
             // Original Perl doesn't die, just logs. Continue.
        }
    }

    setenv("LPD_DEBUG", std::to_string(LPD_DEBUG).c_str(), 1);
    setenv("PS", "1", 1);

    setenv("BRPAPERWIDTH", std::to_string(width).c_str(), 1);
    setenv("BRPAPERHEIGHT", std::to_string(height).c_str(), 1);

    // Parse *DefaultBrPrintArea
    std::string ppddefaults1_line;
    std::string grep_cmd_area = "grep '^*DefaultBrPrintArea' " + PPD;
    FILE* pipe_area = popen(grep_cmd_area.c_str(), "r");
    if (pipe_area) {
        char buffer[256];
        if (fgets(buffer, sizeof(buffer), pipe_area) != NULL) {
            ppddefaults1_line = buffer;
        }
        pclose(pipe_area);
    } else {
        logprint(0, "Error executing grep for DefaultBrPrintArea\n");
    }

    // chomp
    if (!ppddefaults1_line.empty() && ppddefaults1_line.back() == '\n') ppddefaults1_line.pop_back();

    std::string label1 = ppddefaults1_line;
    // s/^\*//g
    label1 = std::regex_replace(label1, std::regex("^\\*"), "");
    // s/: .*$//g
    label1 = std::regex_replace(label1, std::regex(": .*$"), "");

    std::string value1_str = ppddefaults1_line;
    // s/^.*: //g
    value1_str = std::regex_replace(value1_str, std::regex("^.*: "), "");

    // ($label1,$value1) = split(/\s+/,$ppddefaults1); - This split overrides the previous regex parsing
    // Let's re-parse using split on whitespace
    size_t first_space = ppddefaults1_line.find(' ');
    if (first_space != std::string::npos) {
        label1 = ppddefaults1_line.substr(0, first_space);
        value1_str = ppddefaults1_line.substr(first_space + 1);
        // Remove leading '*' from label1
        if (!label1.empty() && label1[0] == '*') {
            label1 = label1.substr(1);
        }
    } else {
         // Handle case where no space is found? Original Perl split handles this.
         // If no space, label1 is the whole line (minus *), value1 is empty.
         label1 = ppddefaults1_line;
         if (!label1.empty() && label1[0] == '*') {
            label1 = label1.substr(1);
         }
         value1_str = "";
    }


    logprint(0, "label1    = " + label1 + "\n");
    logprint(0, "value1    = " + value1_str + "\n");

   // int value1 = 0;
   // try {
    //    value1 = std::stoi(value1_str); // Perl's $value1+0 forces numeric context
    //} catch (const std::exception& e) {
    //    logprint(0, "Warning: Could not convert DefaultBrPrintArea value '" + value1_str + "' to integer.\n");
        // value1 remains 0
   // }
    //setenv("PRTAREA1", std::to_string(value1).c_str(), 1);
    // Use value1_str (e.g. "BrPage29x90") to look up PaperDimension
std::string media_keyword = value1_str;
std::string dimension_line;
std::string grep_paperdim = "grep '^*PaperDimension " + media_keyword + ":' " + PPD;
FILE* pipe_paperdim = popen(grep_paperdim.c_str(), "r");
if (pipe_paperdim) {
    char buffer[256];
    if (fgets(buffer, sizeof(buffer), pipe_paperdim) != NULL) {
        dimension_line = buffer;
    }
    pclose(pipe_paperdim);
}

// Extract dimensions from: *PaperDimension BrPage29x90: "827 2339"
int width = 0, height = 0;
if (!dimension_line.empty()) {
    std::size_t quote1 = dimension_line.find('"');
    std::size_t quote2 = dimension_line.find('"', quote1 + 1);
    if (quote1 != std::string::npos && quote2 != std::string::npos) {
        std::string dims = dimension_line.substr(quote1 + 1, quote2 - quote1 - 1);
        std::istringstream iss(dims);
        iss >> width >> height;
    }
}

setenv("BRPAPERWIDTH", std::to_string(width).c_str(), 1);
setenv("BRPAPERHEIGHT", std::to_string(height).c_str(), 1);

    std::map<std::string, std::string> lpr_options = set_options(PPD, cmdoptions);

    exec_lpdconfig(basedir, PRINTER, lpr_options);

    logprint(2, "\n");

    std::string command;
    std::string cat_input_cmd = (CUPSINPUT == "-" || CUPSINPUT.empty()) ? "cat -" : "cat \"" + CUPSINPUT + "\""; // Use "cat -" for STDIN

    if (DEBUG == 0) {
        command = cat_input_cmd + " |  \"" + LPDFILTER + "\"";
        logprint(2, command + "\n");
        system(command.c_str());
    } else if (DEBUG == 1) {
        command = cat_input_cmd + " > \"" + INPUT_PS + "\" && cat \"" + INPUT_PS + "\" | \"" + LPDFILTER + "\" > \"" + OUTPUT_PRN + "\"";

        logprint(2, "export BRPAPERWIDTH=" + std::string(getenv("BRPAPERWIDTH") ? getenv("BRPAPERWIDTH") : "") + "\n");
        logprint(2, "export BRPAPERHEIGHT=" + std::string(getenv("BRPAPERHEIGHT") ? getenv("BRPAPERHEIGHT") : "") + "\n");
        logprint(2, "export PPD=" + std::string(getenv("PPD") ? getenv("PPD") : "") + "\n");
        logprint(2, "export BRPRINTERRCFILE=" + LATESTINFO + "\n"); // Use LATESTINFO path here as it will be moved there
        logprint(2, "export LPD_DEBUG=" + std::string(getenv("LPD_DEBUG") ? getenv("LPD_DEBUG") : "") + "\n");
        logprint(2, "export PS=" + std::string(getenv("PS") ? getenv("PS") : "") + "\n");

        logprint(2, "cat \"" + INPUT_PS + "\" | \"" + LPDFILTER + "\" > \"" + OUTPUT_PRN + "\" \n");
        std::string full_command = command + " 2> /tmp/br_cupswrapper_ink_lpderr";
        system(full_command.c_str());
        system(("cat \"" + OUTPUT_PRN + "\"").c_str());

        logprint(2, command + "\n");

    } else if (DEBUG > 1) {
        command = cat_input_cmd + " > \"" + INPUT_PS + "\" && cat \"" + INPUT_PS + "\" | \"" + LPDFILTER + "\" > \"" + OUTPUT_PRN + "\"";

        logprint(2, "export BRPAPERWIDTH=" + std::string(getenv("BRPAPERWIDTH") ? getenv("BRPAPERWIDTH") : "") + "\n");
        logprint(2, "export BRPAPERHEIGHT=" + std::string(getenv("BRPAPERHEIGHT") ? getenv("BRPAPERHEIGHT") : "") + "\n");
        logprint(2, "export PPD=" + std::string(getenv("PPD") ? getenv("PPD") : "") + "\n");
        logprint(2, "export BRPRINTERRCFILE=" + LATESTINFO + "\n"); // Use LATESTINFO path here
        logprint(2, "export LPD_DEBUG=" + std::string(getenv("LPD_DEBUG") ? getenv("LPD_DEBUG") : "") + "\n");
        logprint(2, "export PS=" + std::string(getenv("PS") ? getenv("PS") : "") + "\n");

        logprint(2, "cat \"" + INPUT_PS + "\" | \"" + LPDFILTER + "\" > \"" + OUTPUT_PRN + "\" \n");
        std::string full_command = command + " 2> /tmp/br_cupswrapper_ink_lpderr";
        system(full_command.c_str());
        std::cout << '\0'; // print "\0"
        system(("cat \"" + OUTPUT_PRN + "\"").c_str());

        logprint(2, command + "\n");
    }

    // Move TEMPRC to LATESTINFO
    LATESTINFO = "/tmp/" + PRINTER + "_latest_print_info";
    // Simulate `unlink $LATESTINFO; touch $LATESTINFO;`
    remove(LATESTINFO.c_str());
    std::ofstream touch_file(LATESTINFO, std::ios::out | std::ios::app); // Creates file if it doesn't exist
    if (touch_file.is_open()) {
        touch_file.close();
    } else {
        logprint(0, "Error touching " + LATESTINFO + "\n");
    }

    // Simulate `mv "$TEMPRC" "$LATESTINFO"`
    if (rename(TEMPRC.c_str(), LATESTINFO.c_str()) != 0) {
        logprint(0, "Error moving " + TEMPRC + " to " + LATESTINFO + "\n");
        // Fallback to system mv if rename fails? Original Perl uses backticks, which is system call.
        // Let's use system call as a direct translation.
        std::string mv_command = "mv \"" + TEMPRC + "\" \"" + LATESTINFO + "\"";
        system(mv_command.c_str());
    }

    // `echo "\n\nCUSTOM PAGE SIZE ${width}x${height}" >> $LATESTINFO`; // Commented out in Perl
    // `unlink $TEMPRC;` // Commented out in Perl

    if (DEVICEURILOCK == 1) {
        if (lock_fd != -1) {
            flock(lock_fd, LOCK_UN); // Release lock
            close(lock_fd);
        }
    }

    return 0;
}
