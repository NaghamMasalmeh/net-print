
//#include <cups/cups.h>
//#include <cups/raster.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>

#include "statusmodel.h"
//#include "readstatus.h"
//#include "command.h"
//#include "define.h"
#if 0
static STATUSMODEL	smodel ;



void clear_status_model()
{
	memset((void *)&smodel , 0, sizeof(smodel)) ;
	smodel.action_to_continue = ACTION_CONTINUE ;
}


/* init the status model. */
/* 
 1.send a request command
 2.read requested status
 3.analysis the status
 4.return action to continue
*/
short	init_status_model()
{
	clear_status_model() ;
	
	return check_status() ;
}
#endif
/* ----Check the status after an error is fixed and the user decided to continue 
 * 1. send a request command
 * 2. read requested status
 * 3. analysis the status
 * 4. return action to continue
 */
 #if 0
short	check_status()
{
	short	err = 0 ;
	short	action = ACTION_CONTINUE ;
	char *	msg = NULL ;
	
	/* send a status request and get the status for this request */
	err = request_status( kQLCmdStatusRequest, sizeof(kQLCmdStatusRequest) , 5000 , &(smodel.reqest_status) ) ;

	/* if a status is read , analysis the status */
	if( NoErr == err ){
		err = analysis_status( &(smodel.reqest_status) ) ;
	}else{
		err = Err_TimeOut ;
	}
	
	/* get error message according to error code */
	if( NoErr != err ){
		msg = get_error_message( err ) ;
	}
	
	action = smodel.action_to_continue ;
	/* deal with the error and message */
	if( NoErr != err && NULL != msg ){
		DEBUGMSG(stderr , "DEBUG: err=%d , msg=%s\n" , err , msg) ;
		action = deal_with_error(err , msg);
	}
	
	return action ;

}

/* ----Read the status after an error is fixed and the user decided to continue 
 * 1. read requested status
 * 2. analysis the status
 * 3. return action to continue
 */
extern	short	get_status(short index ){
	short	err = 0 ;
	short	action = ACTION_CONTINUE ;
	char *	msg = NULL ;
	
	/* send a status request and get the status for this request */
	err = read_status( 5000 , &(smodel.page_status[index]) ) ;

	/* if a status is read , analysis the status */
	if( NoErr == err ){
		err = analysis_status( &(smodel.page_status[index]) ) ;
	}else{
		err = Err_TimeOut ;
	}
	
	/* get error message according to error code */
	if( NoErr != err ){
		msg = get_error_message( err ) ;
		action = get_action_to_continue( err , index ) ;
		smodel.action_to_continue = action ;
	}

	/* deal with the error and message */
	if( NoErr != err && NULL != msg ){
		DEBUGMSG(stderr , "DEBUG: err=%d , msg=%s\n" , err , msg) ;
		action = deal_with_error(err , msg);
	}
	
	return action ;
}

/* ----Check the status after the filter finishs sending a page
 * 1. Get Printing started status
 * 2. Get Printing completed status
 * 3. Get Receiving status
 * 4. analysis above status
 * 5. return action to continue
 */
short	check_page_completion()
{
	short err = NoErr ;
	short action = ACTION_CONTINUE ;
	short i ;
	
	for( i = 0 ; i < 3 ; i++ ){
		action = get_status( i ) ;
		
		if( ACTION_CONTINUE != action ){
			break ;
		}
	}
	
	return action ;
}
#endif
/* ----analysis a status----
 * 1. return error code
 */
short	analysis_status( PrinterStatus * stat )
{
	if ( stat->faseType == PrinterFaseType_Print && 
		stat->faseNum1 == PrinterFaseNum_CoverOpenU && 
		stat->faseNum2 == PrinterFaseNum_CoverOpenL ) {
		return Err_CoverOpen;
	}
	if ( stat->infoNum == PrinterInfoNum_CoverOpen ) {
		return Err_CoverOpen;
	}
	if ( stat->statType == PrinterStatType_PowerOff ) { // PowerOff
		return Err_IOErr;
	}
	if ( stat->statType == PrinterStatType_Info &&
		stat->infoNum == PrinterInfoNum_CoverClose ) {
		return 0;
	}
    
	if ( stat->statType == PrinterStatType_Info && stat->infoNum == PrinterInfoNum_CoolingStart ) {
		return Err_CoolingStart ;
	}
	if ( stat->statType == PrinterStatType_Info && stat->infoNum == PrinterInfoNum_CoolingEnd ) {
		return Err_CoolingEnd ;
	}

	if ( stat->errCode[0] != 0 || stat->errCode[1] != 0 ) {
		if ( stat->errCode[0] & PrinterErr_NoMedia ) {
			return Err_NoMedia;
		}
		if ( stat->errCode[0] & PrinterErr_MediaEnd ) {
			return Err_MediaEnd;
		}
		if ( stat->errCode[0] & PrinterErr_Cutter ) {
			return Err_Cutter;
		}

		if ( stat->errCode[0] & PrinterErr_LowPower ) {
			return Err_LowPower;
		}

		if ( stat->errCode[0] & PrinterErr_Busy ) {
			return Err_PrinterBusy;
		}
		if ( stat->errCode[0] & PrinterErr_PowerOff ) {
			return Err_IOErr;
		}
		if ( stat->errCode[0] & PrinterErr_AC ) {
			return Err_ACAdaptor;
		}

		if ( stat->errCode[1] & PrinterErr_MediaChg ) {
			return Err_MediaChg;
		}

		if ( stat->errCode[1] & PrinterErr_PrBufFul ) {
			return Err_BufFull;
		}

		if ( stat->errCode[1] & PrinterErr_IOErr ) {
			return Err_IOErr;
		}

		if ( stat->errCode[1] & PrinterErr_RsvBufFul ) {
			return Err_BufFull;
		}

		if ( stat->errCode[1] & PrinterErr_CoverOpen ) {
			return Err_CoverOpen;
		}

		if ( stat->errCode[1] & PrinterErr_Cancel ) {
			return -1;
		}

		if ( stat->errCode[1] & PrinterErr_Feed ) {
			return Err_Feed;
		}

		return Err_Unknown;
	}

	return NoErr ;

}

char *(ERRMSG[]) = {
/*00 Err_NoMedia		*/        "Cassette not installed.", 
/*01 Err_MediaEnd		*/        "No paper.", //2005.04.25
/*02 Err_BufFull		*/        "Buffer full error in the P-touch.", 
/*03 Err_Cutter			*/        "The P-touch tape cutter is not operating.",
/*04 Err_MediaChg		*/        "Do not replace the cassette during printing.", 
/*05 Err_MediaSize		*/        "The cassette size is incorrect.", 
/*06 Err_MediaType		*/        "The cassette type is incorrect.", 
/*07 Err_DataRemain		*/        "The P-touch may still have invalid data in memory.",
/*08 Err_LowPower		*/        "The batteries are running low.", 
/*09 Err_CoverOpen		*/        "The cover is open.", 
/*09*///        "%%[ Error:The cover is open..]%%", 
/*10 Err_PrinterType	*/        "The connected P-touch is not a XXXXXX.", 
/*11 Err_Feed			*/        "The end of the tape cannot be found.",
/*12 Err_ACAdaptor		*/        "The wrong AC adapter is being used.", 
/*13 Err_TimeOut		*/        "Communication error between PC and P-touch.", 
/*14 Err_NoMemory		*/        "Not enough memory to print the document.", 
/*15 Err_NoDisk			*/        "Not enough disk space to spool the document.",
/*16 Err_InvalPort		*/        "An invalid port was specified.", 
/*17 Err_PortBusy		*/        "The port is being used for another application.", 
/*18 Err_SysVer			*/        "This printer driver must be used with version 10.0 or later versions of the system software.", 
/*19 Err_ResFail		*/        "Failed to read the resource file.",
/*20 Err_NoHeap			*/        "Since there is not enough free space in the memory, printing could not be carried out.", 
/*21 Err_NoBps			*/        "This Macintosh does not support transmission at 115200 bps.", 
/*22 Err_TapeLen		*/        "The tape length specification is wrong.", 
/*23 Err_Margin			*/        "The left/right margin specification exceeds the tape length.",
/*24 Err_Unknown		*/        "An error occurred.",
/*25 Err_PrinterBusy	*/        "Printer is Busy.",
/*26 Err_CopiesMaxOver	*/        "Copies Max Over.",
/*27 Err_CoolingStart	*/        "Cooling down. Wait a while.",
/*28 Err_CoolingEnd		*/        "Cooling End.",
/*29 Err_HGTape			*/        "HG Tape Error"
};



/* get message according to error code */
char * get_error_message(short err)
{
	char * msg = NULL ;
	
	if(NoErr != err ){
		if(err < NoErr || err > Err_MAX ){
			msg = UnknownErr ;
		}else{
			msg = ERRMSG[err-1] ;
		}	
	}
	
	return msg ;
}
#if 0
/* get action to continue */
short  get_action_to_continue(short err , short i )
{
	short action = ACTION_CONTINUE ;
	
	if( NoErr == err ){
		return action ;
	}
	
	if(err == Err_TimeOut ){
		action = ACTION_TIMEOUT ;
	}
	
	switch( i ){
	case 0 :		/* Printing started */
		action = ACTION_REPRINTPRE ;
		break ;
	case 1 :		/* Printing completed */
		action = ACTION_REPRINTCUR ;
		break ;
	case 2 :		/* Receiving state , edit */
		action = ACTION_CONTINUE ;
		break ;
	default :
		action = ACTION_CONTINUE ;
		break ;
	}
	
	if( err == Err_CoolingStart || err == Err_CoolingEnd){
		action = ACTION_CONTINUE ;
	}
	
	return action ;
}


/* send error message to the statusUI and return an action user decide */
short	deal_with_error(short err , char * errmsg )
{
	short user_action = ACTION_CONTINUE , action ;
	short err = NoErr ;
	char * msg = NULL ;
	
	while(1){
	
		/* add codes for calling StatusUI here */
		//user_action = ...
		sleep( 5 ) ;
		DEBUGMSG(stderr , "DEBUG: deal_with_error() , sleep(5) here.\n");
		
		if( user_action == ACTION_CONTINUE ){
		
			/* send a status request and get the status for this request */
			err = request_status( kQLCmdStatusRequest, sizeof(kQLCmdStatusRequest) , 5000 , &(smodel.reqest_status) ) ;

			/* if a status is read , analysis the status */
			if( NoErr == err ){
				err = analysis_status( &(smodel.reqest_status) ) ;
			}
			
			/* get error message according to error code */
			if( NoErr != err ){
				msg = get_error_message( err ) ;
			}
			
			if( NoErr == err ){
				action = smodel.action_to_continue ;
				break ;
			}

		}else if( user_action == ACTION_CANCEL ){	/* Cancel and Remove the job */
			/* Cancel the job  */
			action = ACTION_CANCEL ;
			break ;
		}
	
	}

	return action ;
}
#endif
