# ! /usr/bin

#1. Ready to make LPRng RPM Packages...
echo "1. Ready to make LPRng RPM Packages......"
cd lprng/release/english/rpm/
rm -fr linux-2.4-intel/
./makePackageMFC
BACKUP=RPM_`date '+%y%m%d_%H%M%S'`
mkdir ../../../../installer/rpm/$BACKUP
mv -f ../../../../installer/rpm/*lpr*.rpm ../../../../installer/rpm/$BACKUP
cp -f linux-2.4-intel/*.rpm ../../../../installer/rpm/
echo "*****************************"

#1. Ready to make CUPSWrapper RPM Packages...
echo "2. Ready to make CUPSWrapper RPM Packages......"
cd ../../../../cupswrapperfilter/release/rpm/
rm -fr linux-2.4-intel/
./makePackageMFC_redhat

mv -f ../../../installer/rpm/*cupswrapper*.rpm ../../../installer/rpm/$BACKUP
mv -f linux-2.4-intel/english/*.rpm ../../../installer/rpm/
echo "*****************************"

cd ../../../installer/rpm
echo Please get the RPM Packages in the folder \"installer/rpm\"
ls -l *.rpm
