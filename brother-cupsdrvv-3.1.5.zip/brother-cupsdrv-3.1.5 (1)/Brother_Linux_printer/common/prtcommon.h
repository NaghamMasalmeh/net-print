/* $Id: prtcommon.h,v 1.4 2005/06/29 07:16:22 cvs Exp $ */

/* 
* Copyright (C) 2003 Brother. Industries, Ltd.
*
* This program is free software; you can redistribute it and/or modify it
* under the terms of the GNU General Public License as published by the Free
* Software Foundation; either version 2 of the License, or (at your option)
* any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
* more details.
*
* You should have received a copy of the GNU General Public License along with
* this program; if not, write to the Free Software Foundation, Inc., 59 Temple
* Place, Suite 330, Boston, MA  02111-1307  USA
*/
/*=================================================================================*
*FileName:		prtcommon.h
*Description:	�������̽������
*Revision:		0.0
*Date:			2004.03.17
*Author:		
*Histroy:		
*==================================================================================*/
#ifndef _PRTCOMMON_H_
#define _PRTCOMMON_H_

#include "pd.h"

#include "prtstruct.h"

extern	short	PrepareSendParam( SENDPARAM *psParam );
extern	void	SetSendParam( SENDPARAM *psParam, PRTJOB_PARAM *ppjParam, int nType );
extern	short	InitJob( prn_model model, send_buffer *send_buf, SENDPARAM *psParam );
extern	short	BeginPageData( SENDPARAM *psParam );
extern	short	SendBandData( int width, int height, send_buffer *send_buf, SENDPARAM *psParam, unsigned char *pBandBuf );
extern	short	EndPageData( void );
extern	short	EndPrintJob( void );
extern	short	ExitJob( send_buffer *send_buf );

extern	void	EntryMemoryCtrl( void *ptr );
extern	void	FreeCtrlMemory( void *ptr );
extern	void	FreeAllMemory( void );

#ifdef _STDBJ_LINUX_
extern SENDPARAM *g_psParam;        // added by liubin 2005.6.21
#endif
#endif /* _PRTCOMMON_H_ */

