/* $Id: prtstruct.h,v 1.5 2005/07/04 12:32:17 cvs Exp $ */

/* 
* Copyright (C) 2003 Brother. Industries, Ltd.
*
* This program is free software; you can redistribute it and/or modify it
* under the terms of the GNU General Public License as published by the Free
* Software Foundation; either version 2 of the License, or (at your option)
* any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
* more details.
*
* You should have received a copy of the GNU General Public License along with
* this program; if not, write to the Free Software Foundation, Inc., 59 Temple
* Place, Suite 330, Boston, MA  02111-1307  USA
*/
/*=================================================================================*
*FileName:		prtstruct.h
*Description:	��?ot???��1??�???���̨�
*Revision:		0.0
*Date:			2004.03.17
*Author:		
*Histroy:		
*==================================================================================*/
#ifndef _PRTSTRUCT_H_
#define _PRTSTRUCT_H_

#include "pd.h"
#include "define.h"	//zsm. 2005.06.07


#ifdef _PTOUCH_


#define DUMB_BUF_SIZE	(  16384	)		/*  16KB					*/

typedef	enum {
	CONTINUOUS_TAPE = 0x0A ,
	DIE_CUT_LABEL	= 0x0B
}TapeType ;

/* Ptouch standard tape size */
typedef struct pt_tape{
	/* Tape Basic size */
	unsigned char		ID[ 16 ] ;			/* ID or Label name */
	unsigned char		ubTapeType ;		/* x0A : Continous Tape ; x0B : Die-cut Label */
	unsigned short	usTapeWidth ;		/* Tape Width in dot , 300dpi */
	unsigned short	usTapeHeight ;		/* Tape Height in dot , 300dpi */
	unsigned short	usPrintAreaWidth ;	/* Width of Printable Area in dot , 300dpi */
	unsigned short	usPrintAreaHeight ;	/* Height of Printable Area in dot , 300dpi */
	unsigned short	usWidthOffset;		/* Width offset in dot , 300dpi */
	unsigned short	usHeightOffset;		/* Height offset in dot , 300dpi */



	/* For raster data */
	unsigned short	unPinsLeftMargin;	/* Number of Pins for Left Margin in dot , 300dpi */
	unsigned short	unPinsPrintArea;	/* Number of Print Area Pins */
	unsigned short	unPinsRightMargin;	/* Number of Pins for Right Margin in dot , 300dpi */
	unsigned short	unRasterBytes;		/* Number of Raster Graphics Transfer Bytes */
	/* for send print information command */
	unsigned char	ubWidthMM ;		/* width in mm */
	unsigned char	ubLengthMM ;	/* length in mm */
}PT_TAPE , * LPPT_TAPE ;


#define	kCTapeMinLength			(295)	/* 25  mm , in 300dpi */
#define	kCTapeMaxLength			(11811)	/* 1000mm , in 300dpi */
#define	kCTapeMinMargin			(35)	/* 3   mm , in 300dpi */
#define	kCTapeMaxMargin			(1500)	/* 127 mm , in 300dpi */

#ifndef _LINUX_STD_
/* Tape index */
typedef enum{
	TAPE_12MM = 1,
	TAPE_29MM ,
	TAPE_62MM ,
	TAPE_38MM ,
	TAPE_50MM ,
	TAPE_54MM ,
	
	TAPE_DC01 ,
	TAPE_DC02 ,
	TAPE_DC03 ,
	TAPE_DC04 ,
	TAPE_DC05 ,
	TAPE_DC06 ,
	TAPE_DC07 ,
	TAPE_DC12 ,
	TAPE_DC13 ,
	TAPE_DC17 ,
	TAPE_DC20 ,
	TAPE_DC24 ,
} TAPEINDEX;
#endif

typedef enum tagHalftone{
	HALFTONE_BINARY = 4 ,
	HALFTONE_DITHER = 2 ,
	HALFTONE_ERRORDIFFUSION = 3 ,
}HALFTONEPATTERN ;



#endif
typedef struct{
#ifdef _PTOUCH_
	char			PTName[ 32 ] ;			/* The Ptouch Name */
	short			model	 ;			/* model */
	LPPT_TAPE		pTape	 ;			/* Tape */

	short			compress ;			/* 1 : compress ; 0 : non-compress */
	short			orientation ;		/* 1 : portrait ; 2 : landscape ; 3 : reverse portrait ; 4 : reverse landscape */
	short			sTapeLength ;		/* Length set on the UI , for continuous tapes */
	short			sTapeMargin ;		/* Margin , for continuous tapes */
//	short			sAutoCut ;			/* 1 : Auto Cut On (Def.) ; 0 : Auto Cut Off */
	short                   sCutAtEnd ;                      /* 1 : Cut At End  On (Def.) ; 0 : Cut At End */

	short			sMirrorPrinting ;	/* 1 : Mirror Printing ; 0 : Off (Def.) */
	short			sPriority ;			/* 0 : Give priority to print speed (Def.) ; 1 : Give priority to print quality */

	short			sHalftonePattern ;	/* 0 : Binary ; 1 : Dither ; 2 : Error Diffusion (Def.) */
	short			sBrightness ;		/* -50 ~ 50 */
	short			sContrast ;			/* -50 ~ 50 */

	/* For the raster data */
	short			iPage ;				/* The page number */
	short			sSourceWidth  ;		/* Width of source data , in pixel */
	short			sSourceHeight ;		/* Height of source data , in pixel */

	/* For the Source Buffer */
    short			bandTotal;			/* Number of bands */
    short			lastBandH;			/* Height of last band */

    short			bandNum;			/* the index of current band ( 0 ~ bandTotal - 1 ) */
    short			bandline;			/* the index of the first line of the current band ( 0 ~ sSourceHeight ) */
	unsigned char * pBandData ;			/* Buffer of the current band data */
	short			sSourceWidthBytes ;	/* Bytes of a line */
    short			bandHeight;			/* height of the current band */



	/* for Halftone precess */
	short			sDestWidth ;		/* Width of dest data , in Pins */
	short			sDestHeight ;		/* Height of dest data , in Pins */

#else
	char		shortnickname[31+1];/* buff size defined by CUPS DDK */
	short		mediaType;			/* Media type */
									/* {MEDIA_PLAIN_BH3/MEDIA_INKJET_BH3/MEDIA_GLOSSY_BH3/  */
									/*  MEDIA_TRSPN_BH3/MEDIA_NO_DRY_BH3} */
	short		resolution;			/* Quality */
									/* {QLTY_MID/QLTY_HIGH/QLTY_TOP/QLTY_PHOTO/QLTY_HIGHEST} */
//	short		biDirPrinting;		/* Bi-Dir Printing */
									/* {1:ON/0:OFF} */
//	short		enhNormPrinting ;	/* Enhanced normal printing */
									/* {1:ON/0:OFF} */
	short		mirrorPrinting ;		/* Mirror printing option */
									/* {1:ON/0:OFF} */
//	short		nearEdge ;			/* Near Edge Flag */
									/* {1:ON/0:OFF} */
	short		paperSize;			/* ��???���̣����o{DMPAPER_?��} */
	short		paperWidth;			/* ��???��y(points/72dpi)    */
	short		paperHeight;		/* ��???1a���(points/72dpi)  */
	short		pageWidth;			/* ����??��?��y(pixel)   */
	short		pageHeight;			/* ����??��?1a���(pixel) */
	short	 	ppBottom;			/* ��?ot��?��?��?2?o?��?(points) 0:����??��?��??? */
	short	 	pgRight;			/* ��?ot��?��?��?2?o?��?(points) 0:����??��?��??? */
	short	 	prTop;				/* ��?ot��?��?o???o?��?(points) 0:����??��?��??? */
	short	 	prLeft;				/* ��?ot��?��?o???o?��?(points) 0:����??��?��??? */
	unsigned	bytePerLine;		/* 1��������������?����?��D�������?? */
	short		paperThickness;		/* ��????����� */
									/* {1:Regular/3:Thick} */
	short		feed;				/* Paper Source */
									/* {SOURCE_AUTO/SOURCE_TRAY1/SOURCE_TRAY2} */
	short		copies;				/* ��?ot��??? */
									/* {1?��999} */
	short		colorOrMono;		/* ?�� */
									/* {0:Mono/1:Color} */
//	short		document;			/* ������-��?������������??���� */
									/* {DOCS_PHOTO:Photo/DOCS_GRAPH:Graphics/DOCS_CUSTOM:Custom} */
	short		colorMatching;		/* ��?����??��T��?������������ */
									/* {1:Natural/2:Vivid/0:None} */
//	short		halfTonePattern;	/* ��???��?����??������?��???���� */
									/* {1:Diffusion/0:Dither} */
//	short		colorEnhance;		/* ��?����??��?������?������1True2Life */
									/* {1:ON/0:OFF} */
	short		brightness;			/* ��?�����������������1?�� */
									/* {-20?��20} */
	short		contrast;			/* ��3��������������1����?�� */
									/* {-20?��20} */
	short		redKey;				/* ��??�죤-???�� */
									/* {-20?��20} */
	short		greenKey;			/* ?D?�죤-???�� */
									/* {-20?��20} */
	short		blueKey;			/* ��??�죤-???�� */
									/* {-20?��20} */
#ifdef _STDBJ_LINUX_
  short   saturationkey;     //Added by zhangshumin. 2005.07.04
	short		tone;

	unsigned char	securePass[MAX_PASSWORD+1];
	unsigned char	secureName[MAX_USERNAME+1] ;
	unsigned char	secureJob[MAX_JOBNAME+1] ;
	short	EnBlackPrinting;
	short	Gray;
	short	Collate;
	short	printx1;
	short	printx2;
	short	printx3;
#endif


#endif

} PRTJOB_PARAM;

#define	kMinBrightnessAdj		( -50 )
#define	kMaxBrightnessAdj		(  50 )
#define	kMinContrastAdj			( -50 )
#define	kMaxContrastAdj			(  50 )

typedef enum tagColorEffect{
	EFFECT_BRIGHTNESS	= 0 ,
	EFFECT_RED			= 1 ,
	EFFECT_GREEN		= 2 ,
	EFFECT_BLUE			= 3 ,
	EFFECT_CONTRAST		= 4 ,
	EFFECT_WEIGHT_RED	= 5 ,
	EFFECT_WEIGHT_GREEN	= 6 ,
	EFFECT_WEIGHT_BLUE	= 7 ,

	EFFECT_ITEM_NUM

}COLOREFFECT ;

#define	kMaxSourceBytes			( 720 )		/* for QL */
#define	kMaxRasterBytes			( 90 )		/* for QL */



#define		INCH2DOT( flen )	(int)(flen * 300 + 0.5 )
#define		MM2DOT( flen )		(int)(flen * 300 / 25.4 + 0.5)

#define	kNoErr                  (  0  )
#define kBandSize				( 512 )		/*One band */

#endif /* _PRTSTRUCT_H_ */

