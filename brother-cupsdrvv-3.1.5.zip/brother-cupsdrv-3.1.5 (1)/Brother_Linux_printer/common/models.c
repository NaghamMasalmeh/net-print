/* $Id: models.c,v 1.3 2005/06/29 07:16:22 cvs Exp $ */

//#include <cups/cups.h>
/*#include <cups/string.h>*/ 
//#include <cups/raster.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>

#include "option.h"
#include "pd.h"
#include"models.h"

#include "define.h"         // added by liubin
#ifdef _STDBJ_LINUX_       // deleted by liubin
prn_model		model_language  = MODEL_UNKNOWN ;
#endif
//unsigned short        model_index        = 0 ;

unsigned short	GetModel( const char  *pstrShortNickName );	//Get model index and language from model name

//Get model index and language from model name
unsigned short	GetModel( const char *pstrShortNickName )
{
	unsigned short i=1;
	const char * pstrValue = NULL ;
	const char * pstrFaxNumber = NULL ;
	const char * pstrFaxDestCount = NULL ;
	
	if( !pstrShortNickName ){
		return 0 ;
	}
	model_language = MODEL_INK;

	pstrValue = GetOption( kBRSendFaxOutputMenuTicket ) ;
	if( pstrValue && strcmp( pstrValue , kFaxOutputMenu_Facsimile ) == 0 ){		/* If the facsimile is selected */			
		pstrFaxNumber   = GetOption( kBRSendFaxInputFaxNumTicket ) ;			/* Get Fax Dest */
		pstrFaxDestCount = GetOption( kBRSendFaxDestinationCountTicket ) ;		/* Get Fax Count */

		if( ( pstrFaxNumber != NULL && strlen( pstrFaxNumber ) > 0 && ( strcmp( pstrFaxNumber , kFaxNum_Null ) != 0 )) || \
			( pstrFaxDestCount != NULL && atoi( pstrFaxDestCount ) > 0 ) ){		/* Edit box or Destination */
			
				model_language = MODEL_FAX ;
					
		}/* ELSE , No Fax number is available , Send Fax will NOT be set */
	}/* ELSE , Send Fax is not set */

	return i ;
}
