#ifndef	_STRING_H_
#define	_STRING_H_

#include <stdio.h>

size_t fwrite_line_string(const char *lpString, size_t length, FILE *stream);
size_t fread_line_string(char *ptr, FILE *stream);

#endif
