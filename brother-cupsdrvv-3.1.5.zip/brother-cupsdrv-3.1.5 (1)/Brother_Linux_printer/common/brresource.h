/* $Id: brresource.h,v 1.8 2005/07/22 05:54:00 cvs Exp $ */

/*
* Copyright (C) 2004-2013 Brother. Industries, Ltd.
*
* This program is free software; you can redistribute it and/or modify it
* under the terms of the GNU General Public License as published by the Free
* Software Foundation; either version 2 of the License, or (at your option)
* any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
* more details.
*
* You should have received a copy of the GNU General Public License along with
* this program; if not, write to the Free Software Foundation, Inc., 59 Temple
* Place, Suite 330, Boston, MA  02111-1307  USA
*
* In addition, as a special exception, Brother Industries, Ltd. gives
* permission to link the code of this program with certain libraries covered
* by BROTHER PRINTER DRIVER SOFTWARE PUBLIC LICENSE AGREEMENT, and distribute
* linked combinations including the two.  You must obey the GNU General Public
* License in all respects for all of the code used other than the libraries as
* stipulated in the above.  If you modify this file, you may extend this
* exception to your version of the file, but you are not obligated to do so.
* If you do not wish to do so, delete this exception statement from your
* version.
*/

#ifndef __BRRESOURCE_H__
#define __BRRESOURCE_H__

#include "define.h"   //Added by zhangshumin. 2005.07.06


#define _LINUX_STD_		// added by Liu Bin 2005.12.5

#define ARRAY_LENGTH( array )	(sizeof(array)/sizeof(array[0]))	/* ÇÛÎóÄ¹€µ */
#define ARRAY_LAST( array )		(ARRAY_LENGTH(array)-1)				/* ÇÛÎóºÇœª¥€¥ó¥Ç¥Ã¥¯¥¹ */

#ifdef _PTOUCH_UP1_ // Added by Zhang Tianxia 2013.05.13 for Update QL-Base
#define BR_INFO_PATH		"/opt/brother/PTouch/%s/inf/"
#else // _PTOUCH_UP1_
#define BR_INFO_PATH		"/usr/local/Brother/PTouch/%s/inf/"
#endif // _PTOUCH_UP1_

//int RAN 
//RAN="$RANDOM";
//#define RAN     
//#define BR_PRINTLIST_PATH	BR_INFO_PATH "brPrintListij"
#define BR_RCFILE_PATH		BR_INFO_PATH "br%src"
#define BR_FUNCLIST_PATH	BR_INFO_PATH "br%sfunc"

#define BR_RECORD_RC_PATH   "/var/tmp/lprng_%s_rcname"

#define BR_SECT_SELECTION_ITEM	"[SelectionItem]"


#define	BR_MAX_ITEM_NAME	(30)	/*	ÀßÄê¥¢¥€¥Æ¥à€ÎºÇÂçÊž»úÎóÄ¹	*/
//#S1
#define	BR_MAX_ITEM_NUM		(40)	/*	ÀßÄê¥¢¥€¥Æ¥à€ÎºÇÂç¿ô		*/


#define _DEF_NAME_				// added by Liu Bin 2006.3.13


#ifdef  BR_CONSTRAINT               /* Added by Chenxujin , SteadyBJ , 2004.11.17 */
#define BR_SECT_CONSTRAINT	"[Constraint]"
#define MAX_CONSTRAINT_NUM  (100)
#endif /* BR_CONSTRAINT */

 
/*	¥Ñ¥é¥á¡Œ¥¿€Î¥Ñ¥Ã¥±¡Œ¥ž¹œÂ€ÂÎ	*/
typedef struct{
	short		Param_ID;				/* 0 ~ n */ //Satyam added for QL 570
	const char	*szKey;					/*	¥­¡ŒÌŸ							*/
	const char	*szCmd;					/*	conf€Ç€Î¥­¡ŒŒ±ÊÌ¥³¥Þ¥ó¥É		*/
	const short	nItemNum;				/*	Í­žú¹àÌÜ¿ô						*/
	const char	**paRcItemList;			/*	¥ê¥œ¡Œ¥¹ÄêµÁ€Ç€Î¥¢¥€¥Æ¥à¥ê¥¹¥È	*/
	const char	**paCmdItemList;		/*	conf¥³¥Þ¥ó¥É€Ç€Î¥¢¥€¥Æ¥à¥ê¥¹¥È	*/
	const short	*paInnerValList;		/*	¥¢¥€¥Æ¥à€ÎÆâÉôÉœžœÃÍ€Î¥ê¥¹¥È	*/

	short	aValid[BR_MAX_ITEM_NUM];	/*	¥¢¥€¥Æ¥à€ÎÍ­žúŒ±ÊÌ¥Þ¡Œ¥­¥ó¥°	*/
										/*	(1=Í­žú, 0=Ìµžú)				*/
	short	nMax;						/*	ÈÏ°ÏÊýŒ°»þ€ÎŸåžÂÃÍ				*/
	short	nMin;						/*	ÈÏ°ÏÊýŒ°»þ€Î²ŒžÂÃÍ				*/

	short	nValue;						/*	ÈÏ°ÏÊýŒ°»þ€ÎÀßÄêÃÍ³ÊÇŒ			*/
	short	nIndex;						/*	¥¢¥€¥Æ¥à¥ê¥¹¥È€Ø€Î¥€¥ó¥Ç¥Ã¥¯¥¹	*/
} BR_PARAM_INFO;

typedef enum{
  PARAM_TYPE_STRING=0,
  PARAM_TYPE_NUMERICAL,
  PARAM_TYPE_LANGUAGE,

  PARAM_TYPE_UNKNOWN
} BR_PARAM_TYPE ;

#ifdef  BR_CONSTRAINT               /* Added by Chenxujin , SteadyBJ , 2004.11.17 */
/* This structure is defined to deal with constraints between options */
typedef struct{
  short nBaseCount ;
  short nCount ;
  const char **paConstraintList ;
} BR_CONSTRAINT_INFO;
#endif /* BR_CONSTRAINT */

#define _CUSTOM_TAPE_


/*	¥×¥ê¥ó¥¿¥ê¥œ¡Œ¥¹ŸðÊó¹œÂ€ÂÎ	*/
typedef struct{
	char			szPrinterName[31+1];	/*	¥×¥ê¥ó¥¿ÌŸ					*/
	int				nParamNum;				/*	¥Ñ¥é¥á¡Œ¥¿¿ô(ÇÛÎóÍ×ÁÇ¿ô)	*/
	BR_PARAM_INFO	*aParams;				/*	¥Ñ¥é¥á¡Œ¥¿ÇÛÎó				*/
#ifdef  BR_CONSTRAINT               /* Added by Chenxujin , SteadyBJ , 2004.11.17 */
  BR_CONSTRAINT_INFO constraint ; /* constraints between options */
#endif /* BR_CONSTRAINT */

#ifdef _CUSTOM_TAPE_
	char		tapename[512];
	char		tapeid[512];
#endif

} BR_RESOURCE_INFO;

/*------------------*/
/*	¥Ñ¥é¥á¡Œ¥¿ID	*/
/*------------------*/
enum{
#ifndef _LINUX_STD_
	BR_PARAM_ID_MEDIA = 0,				
	BR_PARAM_ID_RESOLUTION,		
	BR_PARAM_ID_MIRROR_PRINT,
	BR_PARAM_ID_PAPER_TYPE,		
	BR_PARAM_ID_PAPER_SOURCE,	
	BR_PARAM_ID_COPIES,			
	BR_PARAM_ID_COLOR_OR_MONO,
	BR_PARAM_ID_COLOR_MATCH,	
	BR_PARAM_ID_BRIGHTNESS,		
	BR_PARAM_ID_CONTRAST,		
	BR_PARAM_ID_RED_KEY,		
	BR_PARAM_ID_GREEN_KEY,		
	BR_PARAM_ID_BLUE_KEY,		
	BR_PARAM_ID_LANGUAGE,
  
	BR_PARAM_ID_CAPT,
	BR_PARAM_ID_ImpoveGray,
	BR_PARAM_ID_EnBlkPrinting,
	BR_PARAM_ID_Saturation,
	BR_PARAM_ID_TonerSaveMode,
	BR_PARAM_ID_SleepTime,
	BR_PARAM_ID_HRC,

	BR_PARAM_ID_LANDSCAPEADJUSTMENT,	// added by liubin 2005.7.20
#endif

#ifdef _LINUX_STD_		// for PTouch QL 2005.12.8
	BR_PARAM_ID_COPIES = 0,
	BR_PARAM_ID_LANGUAGE,
	BR_PARAM_ID_QL_CutLabel,		//Satyam added for QL570
	BR_PARAM_ID_QL_CutAtEnd,
	BR_PARAM_ID_QL_Trimtape,	 /* QL720NW  */ 
	BR_PARAM_ID_QL_Compress,		//Satyam added for QL720NW  #S1
	//BR_PARAM_ID_QL_AutoCut,
	BR_PARAM_ID_QL_Brightness,
	BR_PARAM_ID_QL_Contrast,
	BR_PARAM_ID_QL_Halftone,
	BR_PARAM_ID_QL_MirrorPrinting,
	BR_PARAM_ID_QL_Quality,
	BR_PARAM_ID_QL_Resolution,
	BR_PARAM_ID_QL_Feed,
	BR_PARAM_ID_QL_MediaSize,
	BR_PARAM_ID_QL_Collate,
#endif

	BR_NUM_OF_PARAM
} BR_PARAMETERS;

#ifndef _LINUX_STD_
/* ¥­¡ŒÌŸÄêµÁ */
#define BR_PARAM_KEY_MEDIA			"Media"
#define BR_PARAM_KEY_RESOLUTION		"Resolution"
#define BR_PARAM_KEY_REAL_RESO		"RResolution"
#define BR_PARAM_KEY_MIRROR_PRINT	"MirrorPrint"
#define BR_PARAM_KEY_PAPER_TYPE		"PaperType"
#define BR_PARAM_KEY_PAPER_SOURCE	"PaperSource"
#define BR_PARAM_KEY_COPIES			"Copies"
#define BR_PARAM_KEY_COLOR_OR_MONO	"ColorOrMono"
#define BR_PARAM_KEY_COLOR_MATCH	"ColorMatch"
#define BR_PARAM_KEY_BRIGHTNESS		"Brightness"
#define BR_PARAM_KEY_CONTRAST		"Contrast"
#define BR_PARAM_KEY_RED_KEY		"RedKey"
#define BR_PARAM_KEY_GREEN_KEY		"GreenKey"
#define BR_PARAM_KEY_BLUE_KEY		"BlueKey"
#define BR_PARAM_KEY_LANGUAGE		"Language"

#define BR_PARAM_KEY_CAPT            "CAPT"
#define BR_PARAM_KEY_IMPROVEGRAY     "ImpoveGray"
#define BR_PARAM_KEY_ENBLKPRINTING   "EnBlkPrinting"
#define BR_PARAM_KEY_SATURATION      "Saturation"
#define BR_PARAM_KEY_TONERSAVEMODE   "TonerSaveMode"
#define BR_PARAM_KEY_SLEEPTIME       "SleepTime"
#define BR_PARAM_KEY_HRC             "HRC"
#define BR_PARAM_KEY_LANDSCAPEADJUSTMENT     "LandscapeAdjustment"
#endif // _LINUX_STD_

/************************************************************/
// Added by Zhang Tianxia 2013.02.24 for QL-Base Driver
/************************************************************/
/************************************************************/
// For brprintconf szKey
// szCmd : szKey
// -media : MediaSize
/************************************************************/
#ifdef _LINUX_STD_		// for PTouch QL 2005.12.8
#define BR_PARAM_KEY_COPIES			"Copies"
#define BR_PARAM_KEY_LANGUAGE		"Language"


//#define BR_PARAM_KEY_QL_AutoCut     "AutoCut"
#define BR_PARAM_KEY_QL_CutAtEnd    "CutAtEnd"
#define BR_PARAM_KEY_QL_Trimtape	"Trimtape"	 /* QL720NW */
#define BR_PARAM_KEY_QL_Brightness     "Brightness"
#define BR_PARAM_KEY_QL_Contrast     "Contrast"
#define BR_PARAM_KEY_QL_Halftone     "Halftone"
#define BR_PARAM_KEY_QL_MirrorPrinting     "MirrorPrinting"
#define BR_PARAM_KEY_QL_Quality     "Quality"
#define BR_PARAM_KEY_QL_Resolution     "Resolution"
#define BR_PARAM_KEY_QL_Feed     "Feed"
#define BR_PARAM_KEY_QL_MediaSize     "MediaSize"
#define BR_PARAM_KEY_QL_Collate			"Collate"
#define BR_PARAM_KEY_QL_CutLabel			"CutLabel"     // Satyam added for QL570
#define BR_PARAM_KEY_QL_Compress			"Compress"   //Satyam added for QL720NW  #S1
#endif

/************************************************************/
// For brprintconf szKey end.
/************************************************************/

/************************************************************/
// For brprintconf szCmd
// szCmd : szKey
// -media : MediaSize
/************************************************************/
#define BR_CONF_PRINTER_NAME                "-P"
#ifndef _LINUX_STD_
#define BR_CONF_CMD_MEDIA                   "-md"
#define BR_CONF_CMD_RESOLUTION              "-reso"
#define BR_CONF_CMD_MIRROR_PRINT            "-mirro"
#define BR_CONF_CMD_PAPER_TYPE              "-pt"
#define BR_CONF_CMD_PAPER_SOURCE            "-feed"
#define BR_CONF_CMD_COPIES                  "-copy"
#define BR_CONF_CMD_COLOR_OR_MONO           "-corm"
#define BR_CONF_CMD_COLOR_MATCH             "-cm"
#define BR_CONF_CMD_BRIGHTNESS              "-brit"
#define BR_CONF_CMD_CONTRAST                "-cont"
#define BR_CONF_CMD_RED_KEY                 "-red"
#define BR_CONF_CMD_GREEN_KEY               "-green"
#define BR_CONF_CMD_BLUE_KEY                "-blue"

#define BR_CONF_CMD_CAPT_KEY                "-capt"
#define BR_CONF_CMD_IMPROVEGRAY_KEY         "-impg"
#define BR_CONF_CMD_ENBLKPRINTING_KEY       "-ebp"
#define BR_CONF_CMD_SATURATION_KEY          "-saturation"
#define BR_CONF_CMD_TONERSAVEMODE_KEY       "-tsm"
#define BR_CONF_CMD_SLEEPTIME_KEY           "-slt"
#define BR_CONF_CMD_HRC_KEY                 "-hrc"

#define BR_CONF_CMD_LANDSCAPEADJUSTMENT_KEY "-adj"
#endif // _LINUX_STD_

#ifdef _LINUX_STD_        // for PTouch QL 2005.12.8
#define	BR_CONF_CMD_COPIES                  "-copy"

//#define BR_CONF_CMD_QL_AutoCut            "-cut"
#define BR_CONF_CMD_QL_CutAtEnd             "-cutend"
#define BR_CONF_CMD_QL_Trimtape             "-trimtape"  /* QL720NW*/
#define BR_CONF_CMD_QL_Brightness           "-brit"
#define BR_CONF_CMD_QL_Contrast             "-cont"
#define BR_CONF_CMD_QL_Halftone             "-half"
#define BR_CONF_CMD_QL_MirrorPrinting       "-mirro"
#define BR_CONF_CMD_QL_Quality              "-quality"
#define BR_CONF_CMD_QL_Resolution           "-reso"
#define BR_CONF_CMD_QL_Feed                 "-feed"
#define BR_CONF_CMD_QL_MediaSize            "-media"
#define BR_CONF_CMD_QL_Collate              "-collate"


#define BR_CONF_CMD_QL_CutLabel             "-cutlabel"   //Satyam added for QL570
#define BR_CONF_CMD_QL_Compress             "-compress"      //Satyam added for QL720NW  #S1

#define BR_CONF_CMD_QL_RC_NAME              "-rcfile" // For -rcfile command

#endif // _LINUX_STD_

/************************************************************/
// For brprintconf szCmd end.
/************************************************************/

#define    QUALITY_HIGH_IDX         (1) /*    ²òÁüÅÙ¡§600dpi(HIGH)€ÎindexÃÍ    */
#define    QUALITY_ENH_IDX          (2) /* The index of Enhanced Normal Printing Quality */

/*==========================*/
/* ¥×¥ê¥ó¥¿¥ê¥œ¡Œ¥¹ŽÉÍýŸðÊó */
/*==========================*/
extern BR_RESOURCE_INFO g_rcInfo;

#endif // __BRRESOURCE_H__
