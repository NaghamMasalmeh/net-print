/* $Id: modelfunction.h,v 1.2 2005/06/21 11:49:59 cvs Exp $ */

/* 
* Copyright (C) 2003 Brother. Industries, Ltd.
*
* This program is free software; you can redistribute it and/or modify it
* under the terms of the GNU General Public License as published by the Free
* Software Foundation; either version 2 of the License, or (at your option)
* any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
* more details.
*
* You should have received a copy of the GNU General Public License along with
* this program; if not, write to the Free Software Foundation, Inc., 59 Temple
* Place, Suite 330, Boston, MA  02111-1307  USA
*/
#ifndef	_MODEL_FUNCTION_H_
#define	_MODEL_FUNCTION_H_

#include "pd.h"

#ifdef	_cplusplus
extern "C" {
#endif /* _cplusplus */


typedef	short	(*LPFNINITJOB)( prn_model, send_buffer *, SENDPARAM * ) ;
typedef	short	(*LPFNEXITJOB)( send_buffer * ) ;
typedef	short	(*LPFNBEGINJOB)( SENDPARAM * ) ;
typedef	short	(*LPFNENDJOB)() ;
typedef	short	(*LPFNBEGINPAGE)() ;
typedef	short	(*LPFNENDPAGE)() ;
typedef	short	(*LPFNSENDBANDDATA)( int, int, send_buffer *, SENDPARAM *, unsigned char * ) ;


typedef	struct ModelFunctionTable{
	LPFNINITJOB			lpfnMInitJob ;
	LPFNEXITJOB			lpfnMExitJob ;
	LPFNBEGINJOB		lpfnMBeginJob ;
	LPFNENDJOB			lpfnMEndJob ;
	LPFNBEGINPAGE		lpfnMBeginPage ;
	LPFNENDPAGE			lpfnMEndPage ;
	LPFNSENDBANDDATA	lpfnMSendBandData ;
}MFUNTABLE ;

extern	MFUNTABLE	fun_table ;

extern	short	SetFunctionTable( prn_model ) ;
extern	short	ValidateFunctionTable() ;
extern	void	ResetFunctionTable() ;

#ifdef	_cplusplus
}
#endif /* _cplusplus */


#endif/* _MODEL_FUNCTION_H_ */
