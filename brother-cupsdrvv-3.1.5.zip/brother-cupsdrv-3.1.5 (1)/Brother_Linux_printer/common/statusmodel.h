#ifndef _STATUS_MODEL_H_
#define	_STATUS_MODEL_H_

//#include "pd.h"
//#include "status.h"

#include "define.h"

#if 0
#ifdef _cplusplus
extern "C" {
#endif/*_cplusplus*/

typedef	struct	StatusModel{
	PrinterStatus	reqest_status ;			/* requested status */
	PrinterStatus	page_status[3] ;		/* read status when printing a page */
	short			action_to_continue ;	/* action to continue after an error is fixed */

}STATUSMODEL , * PSTATUSMODEL ;
#endif
/* init the status model. */
/* 
 1.send a request command
 2.read requested status
 3.analysis the status
 4.return action to continue
*/
extern	short	init_status_model();

/* ----Check the status after an error is fixed and the user decided to continue 
 * 1. send a request command
 * 2. read requested status
 * 3. analysis the status
 * 4. return action to continue
 */
extern	short	check_status() ;

/* ----Read the status after an error is fixed and the user decided to continue 
 * 1. read requested status
 * 2. analysis the status
 * 4. return action to continue
 */
extern	short	get_status(short index ) ;


/* ----Check the status after the filter finishs sending a page
 * 1. Get Printing started status
 * 2. Get Printing completed status
 * 3. Get Receiving status
 * 4. analysis above status
 * 5. return error code
 */

extern	short	check_page_completion();

/* ----analysis a status
 * 1. return error code
 */
extern	short	analysis_status( PrinterStatus * stat );

/* get message according to error code */
extern	char * get_error_message(short err) ;


/* get action to continue */
extern	short  get_action_to_continue(short err , short i ) ;

/* send error message to the statusUI and return an action user decide */
extern	short	deal_with_error(short err , char * errmsg ) ;

#ifdef _cplusplus
}
#endif/*_cplusplus*/

#endif	/* _STATUS_MODEL_H_ */
