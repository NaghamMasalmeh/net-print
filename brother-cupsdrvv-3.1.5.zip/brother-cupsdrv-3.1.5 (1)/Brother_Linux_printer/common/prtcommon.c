/* $Id: prtcommon.c,v 1.10 2005/08/02 11:06:00 cvs Exp $ */

/* 
* Copyright (C) 2003-2004 Brother. Industries, Ltd.
*
* This program is free software; you can redistribute it and/or modify it
* under the terms of the GNU General Public License as published by the Free
* Software Foundation; either version 2 of the License, or (at your option)
* any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
* more details.
*
* You should have received a copy of the GNU General Public License along with
* this program; if not, write to the Free Software Foundation, Inc., 59 Temple
* Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <signal.h>

#include "pd.h"
#include "prtcommon.h"
#include "models.h"
#include "modelfunction.h"
#include "brerror.h"
#include "paper.h"

#include "define.h"	//added by zhangshumin. 2005-06-06.

#define	CTRL_CNT	(10)
#define kNumValue_EffectItem 6 //zsm. 2005.06.07
static	void	*g_aMemCtrl[CTRL_CNT] = { NULL };


static	void	CancelJob( int sig );			/* I - Signal */
static	void	FlushBuf( void );

#ifdef _STDBJ_LINUX_
SENDPARAM *g_psParam = NULL;        // added by liubin 2005.6.21
#endif

/*-------------------------------------------------------------------------------------
*Name           : PrepareSendParam
*Description    : SENDPARAM�??��������1�?
*Parameters     : 
*       psRaram : SENDPARAM�?���飤��������1
*Return         : 
*             0 : ����???a??
*        �?�??? : ��?����???a??
*--------------------------------------------------------------------------------------*/
short
PrepareSendParam( SENDPARAM *psParam )
{
	int		nResult = 0;

	assert( psParam );

	/* ��?0������������ */
	memset( psParam, 0, sizeof(SENDPARAM) );

	psParam->pPrint = (PrPrint *)malloc( sizeof(PrPrint) );
	EntryMemoryCtrl( psParam->pPrint );
	if( psParam->pPrint == NULL ){
		nResult = BR_ERROR_MEMORY;
	}
	else{
		memset( psParam->pPrint, 0, sizeof(PrPrint) );
	}

//    fprintf(stderr, "ERROR: PrepareSendParam sizeof(DEVDATA) = %d\n", sizeof(DEVDATA));
	psParam->pdev = (PDEVDATA)malloc( sizeof(DEVDATA) );
	EntryMemoryCtrl( psParam->pdev );
	if( psParam->pdev == NULL ){
		nResult = BR_ERROR_MEMORY;
	}
	else{
		memset( psParam->pdev, 0, sizeof(DEVDATA) );
	}

	psParam->pso = (SURFOBJ *)malloc( sizeof(SURFOBJ) );
	EntryMemoryCtrl( psParam->pso );
	if( psParam->pso == NULL ){
		nResult = BR_ERROR_MEMORY;
	}
	else{
		memset( psParam->pso, 0, sizeof(SURFOBJ) );
	}

	if( nResult != 0 ){
		/* ?????? */
		BrError( nResult, NULL );
	}
	return 0;
}


/*-------------------------------------------------------------------------------------
*Name           : SetSendParam
*Description    : SENDPARAM1???
*Parameters     : 
*       psRaram : SENDPARAM�?���飤��������1
*       pjParam : ��?ot��?��?��?��?��������??��?
*         nType : ??������?��������??��?��??����?�������(0=CUPS,1=LPRng)
*Return         : ������
*--------------------------------------------------------------------------------------*/
void
SetSendParam( SENDPARAM *psParam, PRTJOB_PARAM *ppjParam, int nType )
{
  psParam->pdev->cCopies = 1;         //Added by zhangshumin. 2005.07.12.
	psParam->mode			= ppjParam->resolution;
	psParam->paperWidth		= ppjParam->paperWidth * 120 / 72;	// 120dpi�?��??1
	psParam->paperHeight	= ppjParam->paperHeight * 120 / 72;	// 120dpi�?��??1
	psParam->pagewidth		= ppjParam->pageWidth;
	psParam->bandHeight		= kBandSize;
	{
		short	n, 	len;

		n   = ppjParam->pageHeight / kBandSize;
		len = ppjParam->pageHeight - kBandSize * n;
		if( len ){	/* the number of band */
			psParam->bandTotal  = n + 1;
			psParam->lastBandH  = len;
		}
		else{
			psParam->bandTotal  = n;
			psParam->lastBandH  = psParam->bandHeight;
		}
	}
	psParam->bandNum		= 0;
	psParam->graySLen		= ppjParam->bytePerLine;
	psParam->margin			= 0;

	psParam->offset			= 0;



	psParam->tempOrApple	= 0;
	psParam->tray			= SOURCE_AUTO;
	psParam->colorOrMono	= ppjParam->colorOrMono;
#ifdef _STDBJ_LINUX_
	psParam->grayBitWidth	= psParam->pagewidth;
#else
	psParam->grayBitWidth	= 0; /* ���?����?? */
#endif
	psParam->graySAddress	= NULL;
	psParam->grayHandle		= NULL;
	psParam->grayHandle2	= NULL;
	{ /* MONOPRT��???��?:���������?�o�?�?�T�To??? */
		psParam->real_ColorOrMono = psParam->colorOrMono;
		psParam->colorOrMono = 1; /* color */
	}
	psParam->feed			= ppjParam->feed;

	{
		psParam->pPrint->prTop	= ppjParam->prTop;
		psParam->pPrint->prLeft	= ppjParam->prLeft;
		psParam->pPrint->prStl.iPageV = psParam->paperHeight;
		psParam->pPrint->prStl.iPageH = psParam->paperWidth;
		psParam->pPrint->prInfo.iVRes	= RESDEF;	/* 72dpi */
		psParam->pPrint->prInfo.iHRes	= RESDEF;	/* 72dpi */
		psParam->pPrint->prInfo.pgRight	= ppjParam->pgRight - ppjParam->prLeft ;
		psParam->pPrint->prInfo.ppBottom= ppjParam->ppBottom - ppjParam->prTop ;
		
#ifdef _STDBJ_LINUX_	//added by zsm. 2005.06.07
#ifdef COLOR_LASER	
		psParam->pPrint->prBottom = ppjParam->prTop;
		psParam->pPrint->imgAreaTop = ppjParam->prTop + ppjParam->ppBottom;
		psParam->pPrint->imgAreaRight = ppjParam->paperWidth - ppjParam->prLeft;
#endif
		psParam->collate = ppjParam->Collate;
		psParam->tone	= ppjParam->tone;
		strcpy(psParam->secureName, ppjParam->secureName);		
		strcpy(psParam->secureJob, ppjParam->secureJob);
		strcpy(psParam->securePass, ppjParam->securePass);
		
#endif	//_STDBJ_LINUX_

		/* Media Type */
		psParam->pPrint->printX[7] = ppjParam->mediaType;

		/*----- Print Quality -----*/
		psParam->pPrint->printX[4] = ppjParam->resolution;


		{
			/*----- Color, Paper Thickness -----*/
			long	thick = 0 ;				// What Paper Thickness are we working with.

			thick = ((ppjParam->paperThickness - 1) << 1) & THICKBIT;
			
#ifndef _STDBJ_LINUX_	//zhangshumin. 2005.06.07.
			psParam->pPrint->printX[10]  = COLOR_FULL + BIDIFLG + (short)thick;
#else
			psParam->pPrint->printX[10]  = COLOR_FULL;
#endif 

		}
#ifndef _STDBJ_LINUX_	//zsm . 2005.06.07.
		/* Borderless printing */
		if( ppjParam->nearEdge != 0 ){
			psParam->pPrint->printX[10] |= NREDGEBIT ;	/* On */
		}else{
			psParam->pPrint->printX[10] &= (~NREDGEBIT) ;	/* Off */
		}
#endif //_STDBJ_LINUX_

		{
			short	printx_11 = 0;
#ifndef _STDBJ_LINUX_	//zsm. 2005.06.07.
			printx_11 = ppjParam->document;	/* DOCS_?�� */

			if( ppjParam->biDirPrinting == 1 ){
				printx_11 |= BIDIBIT;		/* set Bi-dir */
			}
			else{
				printx_11 &= (~BIDIBIT);	/* set Uni-dir */
			}

			/* Enhanced normal printing */
			if( ppjParam->enhNormPrinting != 0 ){
				printx_11 |= E_NORMALBIT ;	/* set Enhanced Normal Printing = ON */
			}else{
				printx_11 &= (~E_NORMALBIT) ;	/* set Enhanced Normal Printing = OFF */
			}
#endif	//_STDBJ_LINUX_
#ifdef _STDBJ_LINUX_	//zsm 2005.06.07.
			if( ppjParam->EnBlackPrinting == 1 )		
			{
				printx_11 |= IMPBLACKBIT;
			}
			else if(ppjParam->EnBlackPrinting == 0 )
			{	

				printx_11 &= (~IMPBLACKBIT);
			}else{
				printx_11 &= (~IMPBLACKBIT);
			}
			
			/*-- Improve Gray Color ---*/
			if( ppjParam->Gray == 1 )		
			{
				printx_11 |= IMPGRAYBIT;
			}
			else if( ppjParam->Gray == 0 )
			{	
				printx_11 &= (~IMPGRAYBIT);
			}else{
				printx_11 &= (~IMPGRAYBIT);
			}
			
#endif
			/* Mirror printing */
			if( ppjParam->mirrorPrinting != 0 ){
				printx_11 |= MIRRORBIT ;		/* set Mirror Printing = ON */
			}else{
				printx_11 &= (~MIRRORBIT) ;		/* set Mirror Printing = OFF */
			}

			if( ppjParam->colorMatching == 1 ){
				/* Natural */
				printx_11 &= (~COLRBIT);
				printx_11 &= (~NONEBIT);
			}
			else if( ppjParam->colorMatching == 2 ){
				/* Vivid */
				printx_11 |= COLRBIT;
				printx_11 &= (~NONEBIT);
			}
			else{
				/* None */
				printx_11 |= NONEBIT;
			}
#ifndef	_STDBJ_LINUX_
			if( ppjParam->halfTonePattern == 1 ){
				/* Diffusion */


				printx_11 |= HALFBIT;
			}
			else{
				/* Dither */
				printx_11 &= (~HALFBIT);
			}

			if( ppjParam->colorEnhance == 1 ){
				/* True2Life ON */
				printx_11 |= TUNEBIT;
			}
			else{
				/* True2Life OFF */
				printx_11 &= (~TUNEBIT);
			}
#endif	//_STDBJ_LINUX_

			/*----- Color Control -----*/
			psParam->pPrint->printX[11]  = printx_11;
		}

		if( nType == 0 ){
			/* CUPS */
#ifndef _STDBJ_LINUX_ //modify by zhangshumin. 2005.06.06.
			psParam->pPrint->printX[0] = CheckSendPaper(psParam->paperHeight, psParam->paperWidth);
#else
			psParam->pPrint->printX[0] = checkSendPaper(psParam->paperHeight, psParam->paperWidth);
#endif
		}
		else{
			/* LPRng */
			psParam->pPrint->printX[0] = ppjParam->paperSize;
		}

		psParam->pPrint->printX[12] = 0;
		


		
#ifndef _STDBJ_LINUX_	//zsm. 2005.06.07
		if( ppjParam->colorEnhance == 1 ){
			char	ctune1 = 0;
			char	ctune2 = 0;

			/*----- Contrast / Brightness -----*/
			ctune1 = (char)ppjParam->brightness;

			/*---- Brightness�??���?��???����?���?��??���??�����?��3�3�?��� ----*/
			if (psParam->real_ColorOrMono == 0)
			{
				ctune1 = (char)(0-ctune1);
			}
			else
			{
				ctune1 = (char)ctune1;
			}
			/*---- Brightness�??���?��???����?���?��??���??�����?��3�3�T�? ----*/
			ctune2 = (char)ppjParam->contrast;
			psParam->pPrint->printX[1] = (short)((ctune1 & 0x00FF) | (ctune2 << 8));

			/*----- Green / Red -----*/
			ctune1 = (char)ppjParam->redKey;
			ctune2 = (char)ppjParam->greenKey;
			psParam->pPrint->printX[2] = (short)((ctune1 & 0x00FF) | (ctune2 << 8));

			/*----- Sharpness / blue -----*/
			ctune1 = (char)ppjParam->blueKey;
			psParam->pPrint->printX[3] = (short)(0x0200 | (ctune1 & 0x00FF));
		}
		else
		{
			psParam->pPrint->printX[1] = 0;
			psParam->pPrint->printX[2] = 0;
			psParam->pPrint->printX[3] = (short)(0x0200);
		}
#else
#if 1//Modified by zhangshumin. 2005.07.04.
			char	ctune1 = 0;
			char	ctune2 = 0;

      ctune1 = (char)ppjParam->brightness;
			/*---- Brightness�??���?��???����?���?��??���??�����?��3�3�?��� ----*/
/*			if (psParam->real_ColorOrMono == 0)
			{
				ctune1 = (char)(0-ctune1);
			}
			else
			{
				ctune1 = (char)ctune1;
			}
*/			/*---- Brightness�??���?��???����?���?��??���??�����?��3�3�T�? ----*/
			ctune2 = (char)ppjParam->contrast;
			psParam->pPrint->printX[1] = (short)((ctune1 & 0x00FF) | (ctune2 << 8));

			/*----- Green / Red -----*/
			ctune1 = (char)ppjParam->redKey;
			ctune2 = (char)ppjParam->greenKey;
			psParam->pPrint->printX[2] = (short)((ctune1 & 0x00FF) | (ctune2 << 8));

			/*----- Sharpness / blue -----*/
			ctune1 = (char)ppjParam->blueKey;
			ctune2 = (char)ppjParam->saturationkey;
			psParam->pPrint->printX[3] = (short)((ctune1 & 0x00FF) | (ctune2 << 8));

#else
		psParam->pPrint->printX[1] = ppjParam->printx1;
		psParam->pPrint->printX[2] = ppjParam->printx2;
		psParam->pPrint->printX[3] = ppjParam->printx3;
#endif
		
#endif //_STDBJ_LINUX_
		
		/*----- WhiteBalance / Chroma -----*/

		psParam->pPrint->printX[13] = 0x0202;

		/*----- Hidden settings -----*/
		psParam->pPrint->printX[17] = 0x0064;
	}
}


/*-------------------------------------------------------------------------------------
*Name           : InitJob
*Description    : ��?ot��?��?��??��?��2?
*Parameters     : 
*         model : 
*      send_buf : 
*       psRaram : SENDPARAM�?���飤��������1
*Return         : 
*--------------------------------------------------------------------------------------*/
short

InitJob( prn_model model, send_buffer *send_buf, SENDPARAM *psParam )
{
	short	sRet;
#ifdef _STDBJ_LINUX_
    g_psParam = psParam;
#endif

	/* ��?ot��?��?��??��?��2? */
	sRet = fun_table.lpfnMInitJob( model, send_buf, psParam );

	return sRet;
}

/*-------------------------------------------------------------------------------------
*Name           : BeginPageData
*Description    : ����??��?3????����y
*Parameters     : 
*       psRaram : SENDPARAM�?���飤��������1
*Return         : 
*--------------------------------------------------------------------------------------*/
short
BeginPageData( SENDPARAM *psParam )
{
	short	sRet;

	signal( SIGTERM, CancelJob );

	/* ��?ot��?��?��?3??? */
	sRet = fun_table.lpfnMBeginJob( psParam );

	if( sRet != 0 ){
		return sRet;
	}

	/* ����??��?3??? */
	sRet = fun_table.lpfnMBeginPage();

	return sRet;
}

/*-------------------------------------------------------------------------------------
*Name           : SendBandData

*Description    : ��D����������???��?����??
*Parameters     : 

*         width : ��y
*        height : 1a���
*       psRaram : SENDPARAM�?���飤��������1
*Return         : 
*--------------------------------------------------------------------------------------*/
short
SendBandData( int width, int height, send_buffer *send_buf, SENDPARAM *psParam, unsigned char *pBandBuf )
{
	short	sRet;

	/* ��D����������???��?����?? */
	sRet = fun_table.lpfnMSendBandData( width, height, send_buf, psParam, pBandBuf );


	return sRet;
}

/*-------------------------------------------------------------------------------------

*Name           : EndPageData
*Description    : ����??��??a???����y
*Parameters     : ������
*Return         : 
*--------------------------------------------------------------------------------------*/
short
EndPageData( void )
{
	short	sRet;


	/*                      */
#ifdef _STDBJ_LINUX_
    sRet = fun_table.lpfnMEndPage(g_psParam);
#else
	sRet = fun_table.lpfnMEndPage();

#endif


	FlushBuf();

	signal(SIGTERM, SIG_IGN);

	return sRet;
}

/*-------------------------------------------------------------------------------------
*Name           : EndPrintJob
*Description    : ��?ot��?��?��??a???����y
*Parameters     : ������
*Return         : 
*--------------------------------------------------------------------------------------*/
short
EndPrintJob( void )
{
	short	sRet;

	/* ��?��?��??a?? */
	sRet = fun_table.lpfnMEndJob();

	FlushBuf();

	return sRet;
}

/*-------------------------------------------------------------------------------------
*Name           : ExitJob
*Description    : ��?ot��?��?��?3?����
*Parameters     : 
*      send_buf : 
*Return         : 
*--------------------------------------------------------------------------------------*/
short
ExitJob( send_buffer *send_buf )
{
	short	sRet;

	/* ��?��?��?3?���� */
	sRet = fun_table.lpfnMExitJob( send_buf );

	/* ������a����3?���� */
	FreeAllMemory();

	return 0;
}



/*-------------------------------------------------------------------------------------
*Name           : FreeAllMemory
*Description    : ������a��������㨬3??����y�1�?�?���?D??�1�?
*Parameters     : ������
*Return         : ������
*--------------------------------------------------------------------------------------*/
void
EntryMemoryCtrl( void *ptr )
{
	int		i;
	int		fEntry = 0;

	for( i = 0; i < CTRL_CNT; i++ ){
		if( g_aMemCtrl[i] == NULL ){
			g_aMemCtrl[i] = ptr;
			fEntry = 1;
			break;

		}

	}

	assert( fEntry );
}


/*-------------------------------------------------------------------------------------
*Name           : FreeCtrlMemory
*Description    : ?D??����?������a�������3?�����1�?
*Parameters     : ������
*Return         : ������

*--------------------------------------------------------------------------------------*/
void
FreeCtrlMemory( void *ptr )
{
	int		i;
	int		fFree = 0;

	for( i = 0; i < CTRL_CNT; i++ ){
		if( g_aMemCtrl[i] == ptr ){
			free( g_aMemCtrl[i] );
			g_aMemCtrl[i] = NULL;
			fFree = 1;
			break;
		}
	}

	assert( fFree );
}


/*-------------------------------------------------------------------------------------
*Name           : FreeAllMemory
*Description    : prtcommon.c�?3?��Y����?������a�������3?�����1�?
*Parameters     : ������
*Return         : ������
*--------------------------------------------------------------------------------------*/
void
FreeAllMemory( void )
{
	int		i;

	for( i = 0; i < CTRL_CNT; i++ ){
		if( g_aMemCtrl[i] != NULL ){
			free( g_aMemCtrl[i] );

			g_aMemCtrl[i] = NULL;
		}
	}
}


/*-------------------------------------------------------------------------------------
*Name           : CancelJob
*Description    : ��?ot?��??�?�?��?��?��??????����y
*Parameters     : ������
*Return         : ������
*--------------------------------------------------------------------------------------*/
void
CancelJob( int sig )
{
  	sig = sig;
 	EndPageData();
	EndPrintJob();
	FlushBuf();
	FreeAllMemory();

	exit( 0 ) ;
}


void
FlushBuf( void )
{
	fflush( stdout );
}

