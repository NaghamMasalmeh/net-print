#ifndef	_MODEL_FUNCTION_H_
#define	_MODEL_FUNCTION_H_

#define _LPR_
#ifndef _LPR_
//#include <cups/cups.h>
//#include <cups/raster.h>
#endif
#include "pd.h"

#ifdef	_cplusplus
extern "C" {
#endif /* _cplusplus */


#ifdef _LPR_
typedef	short	(*LPFNBEGINJOB)( LPPTPARAM sParam ) ;
typedef	short	(*LPFNBEGINPAGE)( int ) ;
#else
typedef	short	(*LPFNBEGINJOB)( cups_page_header_t * header , LPPTPARAM sParam ) ;
typedef	short	(*LPFNBEGINPAGE)( cups_page_header_t * , int ) ;
#endif
typedef	short	(*LPFNENDJOB)() ;
typedef	short	(*LPFNENDPAGE)( short sLastPage ) ;
typedef	short	(*LPFNSENDBAND)( LPPTPARAM sParam ) ;
typedef	short	(*LPFNSENDBUFDATA)( send_buffer * send_buf ) ;

typedef	struct ModelFunctionTable{
	LPFNBEGINJOB		lpfnMBeginJob 	;
	LPFNENDJOB			lpfnMEndJob 	;
	LPFNBEGINPAGE		lpfnMBeginPage ;
	LPFNENDPAGE			lpfnMEndPage	;
	LPFNSENDBAND		lpfnMSendBand 	;
	LPFNSENDBUFDATA		lpfnMSendData 	;	
}MFUNTABLE ;

extern	MFUNTABLE	fun_table ;

extern	short	SetFunctionTable() ;
extern	short	ValidateFunctionTable() ;
extern	void ResetFunctionTable() ;

#ifdef	_cplusplus
}
#endif /* _cplusplus */


#endif/* _MODEL_FUNCTION_H_ */

