/*=================================================================================*
*FileName:     	paper.c
*Description:	function for paper selection
*Revision:     	1.0									
*Date:         	2003.08.28							
*Author:       	Chenxujin , SteadyBJ 									
*Histroy:      	1.Chenxujin , Create
*==================================================================================*/
#include "pd.h"
#include"paper.h"

//#include <cups/cups.h>
//#include <cups/raster.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>

/* QL series Ptouch standard tape sizes */


#define _LINUX_STD_
#include "define.h"
#define		NUM_CONTINUOUS_TAPE	(6) //Satyam changed for QL570

#ifdef _LINUX_STD_
//#define		NUM_TAPE			(36) //Satyam changed for QL570
#define		NUM_TAPE			(39) //MSat added
#else
#define		NUM_TAPE			(12)
#endif


#ifdef _LINUX_STD_
typedef struct
{
	int	iTapeCheckTableItemCount;
	PT_TAPE		*pTapeCheckTable;
}
TMediaType;
TMediaType g_MediaType;

#endif	//_LINUX_STD_
PT_TAPE		TapeCheckTable[ NUM_TAPE ] = {

        {"12X1" ,0x0A, 142,0   ,106,0   ,18,0  ,585,106,29 ,90,12,0   },
        {"29X1" ,0x0A, 342,0   ,306,0   ,18,0  ,408,306,6  ,90,29,0   },
        {"38X1" ,0x0A, 449,0   ,413,0   ,18,0  ,295,413,12 ,90,38,0   },
                                                                                                                             
        {"50X1" ,0x0A, 590,0   ,554,0   ,18,0  ,154,554 ,12 ,90,50,0  },
        {"54X1" ,0x0A, 636,0   ,590,0   ,23,0  ,130,590, 0 ,90,54,0   },
        {"62X1" ,0x0A, 732,0   ,696,0   ,18,0  ,12 ,696,12 ,90,62,0   }, 
                                                                                                                             
        {"12X2" ,0x0A,142,0   ,106,0   ,18,0  ,585,106,29 ,90,12,0   },
        {"12X3" ,0x0A,142,0   ,106,0   ,18,0  ,585,106,29 ,90,12,0   },
        {"12X4" ,0x0A,142,0   ,106,0   ,18,0  ,585,106,29 ,90,12,0   },
                                                                                                                             
        {"29X2" ,0x0A,342,0   ,306,0   ,18,0  ,408,306,6  ,90,29,0   },
        {"29X3" ,0x0A,342,0   ,306,0   ,18,0  ,408,306,6  ,90,29,0   },
        {"29X4" ,0x0A,342,0   ,306,0   ,18,0  ,408,306,6  ,90,29,0   },
        
        {"38X2" ,0x0A, 449,0   ,413,0   ,18,0  ,295,413,12 ,90,38,0   },
        {"38X3" ,0x0A, 449,0   ,413,0   ,18,0  ,295,413,12 ,90,38,0   },
        {"38X4" ,0x0A, 449,0   ,413,0   ,18,0  ,295,413,12 ,90,38,0   },
                                                                                                                             
        {"50X2" ,0x0A, 590,0   ,554,0   ,18,0  ,154,554 ,12 ,90,50,0  },
        {"50X3" ,0x0A, 590,0   ,554,0   ,18,0  ,154,554 ,12 ,90,50,0  },
        {"50X4" ,0x0A, 590,0   ,554,0   ,18,0  ,154,554 ,12 ,90,50,0  },
                                                                                                                             
        {"54X2" ,0x0A, 636,0   ,590,0   ,23,0  ,130,590, 0 ,90,54,0   },
        {"54X3" ,0x0A, 636,0   ,590,0   ,23,0  ,130,590, 0 ,90,54,0   },
        {"54X4" ,0x0A, 636,0   ,590,0   ,23,0  ,130,590, 0 ,90,54,0   },
                                                                                                                     
        {"62X2" ,0x0A,732,0   ,696,0   ,18,0  ,12 ,696,12 ,90,62,0   },
        {"62X3" ,0x0A,732,0   ,696,0   ,18,0  ,12 ,696,12 ,90,62,0   },
        {"62X4" ,0x0A,732,0   ,696,0   ,18,0  ,12 ,696,12 ,90,62,0   },
                                                                                                                             
        {"17x54" ,0x0B,201,636 ,165,566 ,18,35 ,555,165,0  ,90,17,54   },
        {"17x87" ,0x0B,201,1026,165,956 ,18,35 ,555,165,0  ,90,17,87  },
        {"23x23" ,0x0B, 272,272   ,236,202   ,18,35  ,442,236,42 ,90,23,23  },

        {"29x42" ,0x0B,342,496, 306,427   ,18,35 ,408,306,6  ,90,29,42  },
        {"29x90" ,0x0B,342,1061,306,991   ,18,35 ,408,306,6  ,90,29,90  },
        {"38x90" ,0x0B,449,1061,413,991   ,18,35 ,295,413,12 ,90,38,90  },
        {"39x48" ,0x0B, 461,565,425,495   ,18,35 ,289,425,6  ,90,39,48   },

        {"52x29" ,0x0B, 614,341   ,578,271   ,18,35  ,142 ,578,0 ,90,52,29   },
//        {"54X1" ,0x0A, 636,0   ,590,0   ,23,0  ,130,590, 0 ,90,54,0   },
        {"54x29" ,0x0B, 638,341   ,602,271   ,18,35  ,118 ,602, 64 ,90,54,29   },
        {"60x86" ,0x0B,708,1014   ,672,944   ,18,35   ,36-12 ,672,12+12 ,90,60,86 },
        {"62x29" ,0x0B,732,341 ,696,271 ,18,35 ,12 ,696,12 ,90,62,29   },
        {"62x100" ,0x0B,732,1179,696,1109,18,35 ,12 ,696,12 ,90,62,100 },

 
        {"12Dia"  ,0x0B,142,142 ,94 ,94  ,24,24 ,513,94 ,113,90,12,12      },
        {"24Dia"  ,0x0B,284,284 ,236,236 ,24,24 ,442,236,42 ,90,24,24     },
        {"58Dia" ,0x0B,688,688 ,618,618 ,35,35 ,51 ,618,51 ,90,58,58    }
	
};

#ifndef _LINUX_STD_
int LoadMediaType(const char* MediaTypeFile);
int FreeMediaType();
int FreeMediaType()
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	if(g_MediaType.pTapeCheckTable != NULL)
	{
		g_MediaType.iTapeCheckTableItemCount = 0;
		free(g_MediaType.pTapeCheckTable);
	}
#ifdef _MY_DEBUG_
	fprintf(stderr, "ERROR: FreeMediaType - OK(count = %d, size = %d)\n", g_MediaType.iTapeCheckTableItemCount, sizeof(PT_TAPE) * g_MediaType.iTapeCheckTableItemCount);
#endif	
	return 0;
}

int ExportMediaType(const char* MediaTypeFile)
{
       FILE* file = fopen(MediaTypeFile, "w+b");
	if(file != NULL)
	{
		if(g_MediaType.iTapeCheckTableItemCount > 0)
		{
			fwrite(&g_MediaType.iTapeCheckTableItemCount, 1, sizeof(int), file);
			fwrite(g_MediaType.pTapeCheckTable, 1, sizeof(PT_TAPE) * g_MediaType.iTapeCheckTableItemCount, file);
		}
		fclose(file);
		chmod(MediaTypeFile, 00666);
	}
#ifdef _MY_DEBUG_
	fprintf(stderr, "ERROR: ExportMediaType - OK (count = %d, size = %d)\n", g_MediaType.iTapeCheckTableItemCount, sizeof(PT_TAPE) * g_MediaType.iTapeCheckTableItemCount);
#endif
	return 0;
}

int LoadMediaType(const char* MediaTypeFile)
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
       g_MediaType.iTapeCheckTableItemCount = 0;
       g_MediaType.pTapeCheckTable = NULL;

       FILE* file = fopen(MediaTypeFile, "rb");
#ifdef _MY_DEBUG_
	if(file == NULL)
	{
			fprintf(stderr, "ERROR: Load file - ERROR!!\n");
	}
#endif       
	if(file != NULL)
	{
       	fread(&g_MediaType.iTapeCheckTableItemCount, 1, sizeof(int), file);
	}
#ifdef _MY_DEBUG_
	fprintf(stderr, "ERROR: g_MediaType.iTapeCheckTableItemCount = %d\n", g_MediaType.iTapeCheckTableItemCount);
#endif
	if(g_MediaType.iTapeCheckTableItemCount <= 0)
	{
		fclose(file);
		return 0;		// normal return
	}

	g_MediaType.pTapeCheckTable = (PT_TAPE*)malloc(sizeof(PT_TAPE) * g_MediaType.iTapeCheckTableItemCount);
	if(g_MediaType.pTapeCheckTable == NULL)
	{
		g_MediaType.iTapeCheckTableItemCount = 0;
		fclose(file);
		fprintf(stderr, "ERROR: Allocate memory failed!(error code=STD052101)\n");
		return -1;	// error occurs
	}

	fread(g_MediaType.pTapeCheckTable, 1, sizeof(PT_TAPE) * g_MediaType.iTapeCheckTableItemCount, file);
	fclose(file);

	
#ifdef _MY_DEBUG_
	fprintf(stderr, "ERROR: Load file - OK!!!\n");
#endif
#ifdef _MY_DEBUG_
	fprintf(stderr, "ERROR: LoadMediaType - OK (count = %d, size = %d)\n", g_MediaType.iTapeCheckTableItemCount, sizeof(PT_TAPE) * g_MediaType.iTapeCheckTableItemCount);
#endif
	return 0;
}

#endif

/*-------------------------------------------------------------------------------------
*Name			: checkSetTape
*Description 	: Get tape from tape name
*Parameters		: 
*	tapeName	: PageSize select name in PPD file
*Precondition	: N/A
*Operation		: Search for matched tape
*Postcondition 	: N/A
*Return			: Pointer to the matched tape	; NULL : no mached tape
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.07.27
*--------------------------------------------------------------------------------------*/
LPPT_TAPE checkSetTape(const unsigned char * tapeName , int cupsWidth , int cupsHeight )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	LPPT_TAPE	pTape = NULL ;
	int i ;
#ifdef _MY_DEBUG_	
	fprintf(stderr, "ERROR:typename=%s, cupsWidth=%d, cupsHeight=%d\n", tapeName, cupsWidth, cupsHeight);
#endif

	if( NULL != tapeName ){
		/* Check for standard size */
		for (i=0; (i < NUM_TAPE) && (pTape == NULL); i++){
#ifdef _MY_DEBUG_			
			fprintf(stderr, "ERROR:ID=%s, TapeWidth=%d, TapeHeight=%d\n",
				TapeCheckTable[i].ID,
				TapeCheckTable[i].usPrintAreaWidth,
				TapeCheckTable[i].usPrintAreaHeight);
#endif				
#ifdef _LINUX_STD_
			if( strncmp( tapeName , TapeCheckTable[i].ID, strlen(tapeName) ) == 0 )
			{
				pTape = &(TapeCheckTable[i]) ;
				break;
			}

#else
#if 0
			if( strstr( tapeName , TapeCheckTable[i].ID ) )
#else
			if( (strcmp( tapeName , TapeCheckTable[i].ID ) == 0)  && \
				(cupsWidth == TapeCheckTable[i].usPrintAreaWidth ) )
#endif
			{
				if( i < NUM_CONTINUOUS_TAPE ){	//Continuous Tape range
					pTape = &(TapeCheckTable[i]) ;
					break ;
				}else{			//Die-cut labels
					if( cupsHeight == TapeCheckTable[i].usPrintAreaHeight ){
						pTape = &(TapeCheckTable[i]) ;
						break ;
					}
				}
			}
#endif			
		}

#ifdef _LINUX_STD_
		for (i=0; (i < g_MediaType.iTapeCheckTableItemCount) && (pTape == NULL); i++){
#ifdef _MY_DEBUG_
			fprintf(stderr, "ERROR:ID=%s, LabelWidth=%d, LabelHeight=%d\n",
				g_MediaType.pTapeCheckTable[i].ID,
				g_MediaType.pTapeCheckTable[i].usPrintAreaWidth,
				g_MediaType.pTapeCheckTable[i].usPrintAreaHeight);
#endif
			if( strncmp( tapeName , g_MediaType.pTapeCheckTable[i].ID, strlen(tapeName) ) == 0 )
			{
				pTape = &(TapeCheckTable[i]) ;
				break;
			}
		}

#endif
		
		/* Check for customed tape */
		if( NULL == pTape ){
			for (i = 0; i < NUM_CONTINUOUS_TAPE; i++){
				if( cupsWidth <= TapeCheckTable[i].usPrintAreaWidth ){
					pTape = &(TapeCheckTable[i]) ;
					break ;
				}
			}
		}
	}
	
	/* If there is no matche tape , set the Max size tape */
	if( NULL == pTape ){
		pTape = &(TapeCheckTable[2]) ;
	}
#ifdef _MY_DEBUG_	
	fprintf(stderr, "ERROR:ID=%s, TypeWidth=%d, TypeHeight=%d, AreaWidth=%d, AreaHeight=%d\n",	
	pTape->ID,
	pTape->usTapeWidth,
	pTape->usTapeHeight,
	pTape->usPrintAreaWidth,
	pTape->usPrintAreaHeight);
#endif	
	return pTape ;
}

LPPT_TAPE GetTape(int index )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	if( index <1 || index > NUM_TAPE ){
		return NULL ;
	}
	
	return &(TapeCheckTable[index-1]);
}

