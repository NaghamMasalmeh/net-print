/*=================================================================================*
*FileName:     	paper.h
*Description:	function for paper selection
*Revision:     	1.0									
*Date:         	2003.08.28							
*Author:       	Chenxujin , SteadyBJ 									
*Histroy:      	1.Chenxujin , Create
*==================================================================================*/
#ifndef _PAPER_H_
#define _PAPER_H_

#include"pd.h"

#ifdef _cplusplus
extern "C" {
#endif/*_cplusplus*/

extern	LPPT_TAPE checkSetTape(const unsigned char * tapeName , int cupsWidth , int cupsHeight ) ;
extern	LPPT_TAPE GetTape(int index ) ;

#ifdef _cplusplus
}
#endif/*_cplusplus*/

#endif/*_PAPER_H_*/

