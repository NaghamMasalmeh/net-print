
#include "pd.h"
#include "coloreffect.h"

static unsigned char tblColorLevel[ EFFECT_ITEM_NUM ][ 256 ]={} ;

short	setEffect(short type, short value );
short	effectGray(unsigned char * data , short len , short brightness , short contrast );

short	setEffect(short type, short value )
{
	unsigned char * p = tblColorLevel[ type ] ;
	long i , val , val2 ;
	
	switch(type){
	case EFFECT_BRIGHTNESS :;
		val2 = value * 255L / 128;
		for ( i = 0; i < 256; i++ ) {
			val = i + val2;
			if ( val < 0 )
				val = 0;
			else if ( val > 255 )
				val = 255;
			*p++ = val;
		}

		break ;
	case EFFECT_RED :;
	case EFFECT_GREEN :;
	case EFFECT_BLUE :;
		for ( i = 0; i < 256; i++ ) {
			val = i + i * value / 100;
			if ( val < 0 )
				val = 0;
			else if ( val > 255 )
				val = 255;
			*p++ = val;
		}

		break ;
	case EFFECT_CONTRAST :;
		for ( i = 0; i < 256; i++ ) {
			val = i + ((i - 128) * value / 100);
			if ( val < 0 )
				val = 0;
			else if ( val > 255 )
				val = 255;
			*p++ = val;
		}

		break ;
	case EFFECT_WEIGHT_RED :;
	case EFFECT_WEIGHT_GREEN :;
	case EFFECT_WEIGHT_BLUE :;
		for ( i = 0; i < 256; i++ ) {
			*p++ = i * value / 255;
		}

		break ;
	default :;
		break ;
	}
	
	return 0 ;
}

short	effectGray(unsigned char * data , short len , short brightness , short contrast )
{
	short x ;
	unsigned char * tbl ;
	
	/* Brightness */
	if( brightness ){
		tbl = tblColorLevel[ EFFECT_BRIGHTNESS ] ;
		for( x = 0 ; x < len ; x++ ){
			if( 0 == data[x] || 255 == data[x] ){
				continue ;
			}else{
				data[x] = tbl[ data[x] ];
			}
		}
	}

	/* Contrast */
	if( contrast ){
		tbl = tblColorLevel[ EFFECT_CONTRAST ] ;
		for( x = 0 ; x < len ; x++ ){
			data[x] = tbl[ data[x] ];
		}
	}

	return 0 ;
}

