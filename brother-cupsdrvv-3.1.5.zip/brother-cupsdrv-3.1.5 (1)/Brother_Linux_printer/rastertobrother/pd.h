/*=================================================================================*
*FileName:     	pd.h
*Description:	base data structures for driver
*Revision:     	1.0									
*Date:         	2005.07.26							
*Author:       	Chenxujin , SteadyBJ 									
*Histroy:      	1.Chenxujin , Create
*			3.Liu Bin , Modify , 2005 . 09 . 04
*==================================================================================*/
#ifndef	_PD_H_
#define _PD_H_

/*
*Macro used for debug
*
*/
/*
*If you want to get debug messages from DEBUGMSG,
*Please enable the Macro _DEBUG by changing the #if 0 to #if 1
*/
#if 1
#define	_DEBUG
#endif

#ifdef	_DEBUG
#define	DEBUGMSG		fprintf
#else
#define	DEBUGMSG		1 ? (void)0: fprintf
#endif/*	_DEBUG	*/

//#include "model.h"

#ifdef _cplusplus
extern "C" {
#endif/*_cplusplus*/


#define _QL500_650TD_			// added by liu bin 2006.2.6	for QL500/650TD driver
#define _QL570_                   // Satyam added for QL570 Driver
#define _QL720NW_ 
/*printer model type*/
typedef enum PtouchModel{
	MODEL_UNKNOWN	= 0 ,				/*	Unknown Type	*/
#ifdef _QL500_650TD_
/*Add other model here*/
	MODEL_QL_550 = 1 ,		/*	QL 500 model		*/
	MODEL_QL_500,			/*	QL 500 model		*/
	 MODEL_QL_570,         /*      QL570 model  */
	MODEL_QL_650TD,		/*	QL 650TD model	*/
	 MODEL_QL_720NW,         /*      QL720NW model  */
#else
	MODEL_QL		= 1 ,			/*	QL model		*/
#endif
	MODEL_MASK		= 0x0F
}pt_model ;


/*Output resolution*/
/*unit dpi*/
typedef enum Resolution{
	QLTY_MID	= 300 ,				/*Middle output quality for printer		*/
/*Add other resolution here*/

}pt_resolution ;

typedef struct SendBuffer{
	pt_model		model ;
	unsigned char * buffer ;
	long			lBufByteCnt ;
}send_buffer ;

#define DUMB_BUF_SIZE	(  16384	)		/*  16KB					*/

typedef	enum {
	CONTINUOUS_TAPE = 0x0A ,
	DIE_CUT_LABEL	= 0x0B
}TapeType ;

/* Ptouch standard tape size */
typedef struct pt_tape{
	/* Tape Basic size */
	unsigned char		ID[ 16 ] ;			/* ID or Label name */
	unsigned char		ubTapeType ;		/* x0A : Continous Tape ; x0B : Die-cut Label */
	unsigned short	usTapeWidth ;		/* Tape Width in dot , 300dpi */
	unsigned short	usTapeHeight ;		/* Tape Height in dot , 300dpi */	
	unsigned short	usPrintAreaWidth ;	/* Width of Printable Area in dot , 300dpi */
	unsigned short	usPrintAreaHeight ;	/* Height of Printable Area in dot , 300dpi */	
	unsigned short	usWidthOffset;		/* Width offset in dot , 300dpi */
	unsigned short	usHeightOffset;		/* Height offset in dot , 300dpi */	
	/* For raster data */
	unsigned short	unPinsLeftMargin;	/* Number of Pins for Left Margin in dot , 300dpi */
	unsigned short	unPinsPrintArea;	/* Number of Print Area Pins */
	unsigned short	unPinsRightMargin;	/* Number of Pins for Right Margin in dot , 300dpi */
	unsigned short	unRasterBytes;		/* Number of Raster Graphics Transfer Bytes */
	/* for send print information command */
	unsigned char	ubWidthMM ;		/* width in mm */
	unsigned char	ubLengthMM ;	/* length in mm */
}PT_TAPE , * LPPT_TAPE ;

#define	kCTapeMinLength			(295)	/* 25  mm , in 300dpi */
#define	kCTapeMaxLength			(11811)	/* 1000mm , in 300dpi */
#define	kCTapeMinMargin			(35)	/* 3   mm , in 300dpi */
#define	kCTapeMaxMargin			(1500)	/* 127 mm , in 300dpi */

#ifndef _LINUX_STD_
/* Tape index */
typedef enum{
	TAPE_12MM = 1,
	TAPE_29MM ,
	TAPE_38MM ,
        TAPE_50MM ,
        TAPE_54MM ,
	TAPE_62MM ,
	
	TAPE_DC01 ,
	TAPE_DC02 ,
	TAPE_DC03 ,
	TAPE_DC04 ,
	TAPE_DC05 ,
	TAPE_DC06 ,
	TAPE_DC07 ,
	TAPE_DC12 ,
	TAPE_DC13 ,
	TAPE_DC17 ,
	TAPE_DC20 ,
	TAPE_DC24 ,
} TAPEINDEX;
#endif

typedef enum tagHalftone{
	HALFTONE_BINARY = 4 ,
	HALFTONE_DITHER = 2 ,
	HALFTONE_ERRORDIFFUSION = 3 ,
}HALFTONEPATTERN ;

typedef struct tagPTPARAM{
	char			PTName[ 32 ] ;			/* The Ptouch Name */
	short			model	 ;			/* model */
	LPPT_TAPE		pTape	 ;			/* Tape */
//Satyam added for QL570
	unsigned char			CutLabel;			/* cut at the specific labels 1~255*/  

	short			compress ;			/* 1 : compress ; 0 : non-compress */
	short			orientation ;		/* 1 : portrait ; 2 : landscape ; 3 : reverse portrait ; 4 : reverse landscape */
	short			sTapeLength ;		/* Length set on the UI , for continuous tapes */
	short			sTapeMargin ;		/* Margin , for continuous tapes */
	short 			Trimtape;  /* Trim Tape after data*/
//	short			sAutoCut ;			/* 1 : Auto Cut On (Def.) ; 0 : Auto Cut Off */
        short                   sCutAtEnd ;                      /* 1 : Cut At End: on (Def.) ; 0 : Cut At end  Off */

	short			sMirrorPrinting ;	/* 1 : Mirror Printing ; 0 : Off (Def.) */
	short			sPriority ;			/* 0 : Give priority to print speed (Def.) ; 1 : Give priority to print quality */

	short			sHalftonePattern ;	/* 0 : Binary ; 1 : Dither ; 2 : Error Diffusion (Def.) */
	short			sBrightness ;		/* -50 ~ 50 */
	short			sContrast ;			/* -50 ~ 50 */
	
	/* For the raster data */
	short			iPage ;				/* The page number */
	short			sSourceWidth  ;		/* Width of source data , in pixel */
	short			sSourceHeight ;		/* Height of source data , in pixel */
		
	/* For the Source Buffer */
    short			bandTotal;			/* Number of bands */
    short			lastBandH;			/* Height of last band */

    short			bandNum;			/* the index of current band ( 0 ~ bandTotal - 1 ) */
    short			bandline;			/* the index of the first line of the current band ( 0 ~ sSourceHeight ) */
	unsigned char * pBandData ;			/* Buffer of the current band data */
	short			sSourceWidthBytes ;	/* Bytes of a line */
    short			bandHeight;			/* height of the current band */



	/* for Halftone precess */
	short			sDestWidth ;		/* Width of dest data , in Pins */
	short			sDestHeight ;		/* Height of dest data , in Pins */
	char			*pszNamePrinter;	/* printer name */
}PTPARAM , * LPPTPARAM ;


#define	kMinBrightnessAdj		( -50 )
#define	kMaxBrightnessAdj		(  50 )
#define	kMinContrastAdj			( -50 )
#define	kMaxContrastAdj			(  50 )

typedef enum tagColorEffect{
	EFFECT_BRIGHTNESS	= 0 ,
	EFFECT_RED			= 1 ,
	EFFECT_GREEN		= 2 ,
	EFFECT_BLUE			= 3 ,
	EFFECT_CONTRAST		= 4 ,
	EFFECT_WEIGHT_RED	= 5 ,
	EFFECT_WEIGHT_GREEN	= 6 ,
	EFFECT_WEIGHT_BLUE	= 7 ,
	
	EFFECT_ITEM_NUM

}COLOREFFECT ;

#define	kMaxSourceBytes			( 720 )		/* for QL */
#define	kMaxRasterBytes			( 90 )		/* for QL */



#define		INCH2DOT( flen )	(int)(flen * 300 + 0.5 )
#define		MM2DOT( flen )		(int)(flen * 300 / 25.4 + 0.5)

#define	kNoErr                  (  0  )
#define kBandSize				( 512 )		/*One band */

//#define	kNumBlankData			( 600 )

#ifdef _cplusplus
}
#endif/*_cplusplus*/

#endif/*_PD_H_*/

