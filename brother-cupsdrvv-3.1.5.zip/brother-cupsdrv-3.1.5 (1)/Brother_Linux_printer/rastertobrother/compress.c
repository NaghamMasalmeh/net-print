/*=================================================================================*
*FileName:     	compress.c
*Description:	variable and function declarations for source line data and compression
*Revision:     	1.0									
*Date:         	2003.08.28							
*Author:       	Chenxujin , SteadyBJ 									
*Histroy:      	1.Chenxujin , Create
*==================================================================================*/

//#include <cups/cups.h>
//#include <cups/raster.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>

#include"pd.h"
#include"compress.h"
#include "Message.h"
#include "send.h"

unsigned char *	Planes[ 4 ] ={ NULL } ;

#ifdef SEND_BAND
MODE9	compData = {	MODEL_UNKNOWN , 0 , \
					NULL , 0 , \
					NULL , 0 , \
					NULL , 0 , \
					NULL , NULL	, NULL} ;
#else
MODE9	compData = {	MODEL_UNKNOWN , 0 , \
					NULL , 0 , \
					NULL , 0 , \
					NULL , 0 , \
					NULL , NULL				} ;
#endif

short	CreateCompressBuf( prn_model model , unsigned long lSourceLen , unsigned long lSourceHeight ) ;
void	DestroyCompressBuf() ;

short	CreateLineBuf( unsigned long lBytesPerLine , int iNumPlane ) ;
void	DestroyLineBuf() ;

#ifdef SEND_BAND
short	CreateBandBuf( unsigned long lBytesPerLine, short line );
void	DestroyBandBuf();
#endif

#ifdef SEND_BAND
/*-------------------------------------------------------------------------------------
*Name 		: CreateCompressBuf
*Description 	: Create buffer for compression
*Parameters : 
*	model		: printer model
*	lSourceLen	: souce length before compressed( used for printer )
*	lSourceHeight	: source height of a page( used for PC FAX)
*Precondition	: N/A
*Operation 	: Allocate memory for compression operation
*Postcondition 	: Memory is allocated
*Return 	:
*		0 	: Succeeded ; otherwise , Failed.
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
				  2.Changed , by R.Tarao, BIL, 2004.12.01
*--------------------------------------------------------------------------------------*/
short	CreateCompressBuf( prn_model model , unsigned long lSourceLen , unsigned long lSourceHeight )
{
	fprintf( stderr , "In %s File, %s Function" , __FILE__ , __FUNCTION__ ) ;
	short	sRet = 1 ;
	long	size;

	if( MODEL_UNKNOWN == model || 0 == lSourceLen ){
		fprintf( stderr , "%s%s" , kError , kInvalidParameter ) ;
		return sRet ;
	}
	
/*
*Allocate memory for PC FAX
*lSourceHeight	: the height of a fax page
*
*compData.source	:	page data after halftone process
*compData.sLen	:	size of one line data after halftone without center adjustment
*compData.dest		:	page data after compression
*compData.dLen	:	data length length after compression
*/	
	if( model == MODEL_FAX ){
		lSourceHeight = ((lSourceHeight + 15) >> 4) << 4;	/* 16 no baisuu */
		compData.dest = malloc( MAX_FAX_BYTE * lSourceHeight * 5  ) ;
		compData.extendbuf = compData.dest;
		
		if( NULL == compData.dest ){
			fprintf( stderr , "%s%s" , kError , kInsufficientMemory ) ;
			return sRet ;
		}
		
		DEBUGMSG( stderr , "Memory Size for FAX = %ld\n" , MAX_FAX_BYTE * lSourceHeight * 5 + lSourceLen ) ;
		
		memset( compData.dest , 0 , MAX_FAX_BYTE * lSourceHeight * 4 + \
							  MAX_FAX_BYTE * lSourceHeight  ) ;		/* whole page data after halftone process */

		send_buf.faxbuf		= compData.dest + MAX_FAX_BYTE * lSourceHeight ;
		send_buf.buffer = send_buf.faxbuf;
		compData.seed		= NULL ;
		compData.compBuf	= NULL ; 
		compData.stretch	= NULL ;
		
		compData.model	 = model			;
		compData.lOrginSLen = lSourceLen		;
		compData.sLen		 = 0				;
		compData.dLen		 = 0				;
		compData.seedLen	 = 0				;
		
		return 0 ;
	}

	size = lSourceLen * 5 / 8 ;
	compData.dest = malloc(size);
	
	compData.compBuf = malloc(size);

	return 0 ;
}
#else
/*-------------------------------------------------------------------------------------
*Name 		: CreateCompressBuf
*Description 	: Create buffer for compression
*Parameters : 
*	model		: printer model
*	lSourceLen	: souce length before compressed( used for printer )
*	lSourceHeight	: source height of a page( used for PC FAX)
*Precondition	: N/A
*Operation 	: Allocate memory for compression operation
*Postcondition 	: Memory is allocated
*Return 	:
*		0 	: Succeeded ; otherwise , Failed.
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/
short	CreateCompressBuf( prn_model model , unsigned long lSourceLen , unsigned long lSourceHeight )
{
	fprintf( stderr , "In %s File, %s Function" , __FILE__ , __FUNCTION__ ) ;
	short	sRet = 1 ;

	if( MODEL_UNKNOWN == model || 0 == lSourceLen ){
		fprintf( stderr , "%s%s" , kError , kInvalidParameter ) ;
		return sRet ;
	}
	
/*
*Allocate memory for PC FAX
*lSourceHeight	: the height of a fax page
*
*compData.source	:	page data after halftone process
*compData.sLen	:	size of one line data after halftone without center adjustment
*compData.dest		:	page data after compression
*compData.dLen	:	data length length after compression
*/	
	if( model == MODEL_FAX ){
		compData.dest = malloc( MAX_FAX_BYTE * lSourceHeight * 5 + lSourceLen ) ;
		if( NULL == compData.dest ){
			fprintf( stderr , "%s%s" , kError , kInsufficientMemory ) ;
			return sRet ;
		}
		
//		DEBUGMSG( stderr , "Memory Size for FAX = %ld\n" , MAX_FAX_BYTE * lSourceHeight * 5 + lSourceLen ) ;
		
		memset( compData.dest , 0 , MAX_FAX_BYTE * lSourceHeight * 4 + \
							  lSourceLen + \
							  MAX_FAX_BYTE * lSourceHeight  ) ;		/* whole page data after halftone process */
		compData.source	= compData.dest + MAX_FAX_BYTE * lSourceHeight * 4 	 ;
		compData.seed		= NULL ;
		compData.compBuf	= NULL ; 
		compData.stretch	= NULL ;
		
		compData.model	 = model			;
		compData.lOrginSLen = lSourceLen		;
		compData.sLen		 = 0				;
		compData.dLen		 = 0				;
		compData.seedLen	 = 0				;
		
		return 0 ;
	}

/*
*Allocate memory for printers
*---------compressed data		: lSourceLen + lSourceLen / 2 
*---------source data & seed data	: lSourceLen + lSourceLen
*---------temp buffer			: COMPBUF_SIZE
*---------stretch buffer			: STRETCH_SIZE
*/
	compData.dest	 = malloc(	lSourceLen + lSourceLen / 2  + 	\
						lSourceLen  + lSourceLen  + 	\
						COMPBUF_SIZE + 			\
						STRETCH_SIZE 			) ;
	if( NULL == compData.dest ){
		fprintf( stderr , "%s%s" , kError , kInsufficientMemory ) ;
		return sRet ;
	}
	compData.source	= compData.dest	+ lSourceLen + lSourceLen / 2  	 ;
	compData.seed		= compData.source  	+ lSourceLen 				 ;
	compData.compBuf	= compData.seed    	+ lSourceLen 				 ; 
	compData.stretch	= compData.compBuf + COMPBUF_SIZE 			 ;

/*
*Reset other members.
*/
	compData.model	 = model			;
	compData.lOrginSLen = lSourceLen 		;
	compData.sLen		 = 0				;
	compData.dLen		 = 0				;
	compData.seedLen	 = 0				;
	
	return 0 ;
}
#endif

/*-------------------------------------------------------------------------------------
*Name 		: DestroyCompressBuf
*Description 	: Destroy the compression buffer
*Parameters : 
*Precondition	: N/A
*Operation 	: Free memory
*Postcondition 	: Compression buffer is freed
*Return 		: N/A
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/
void	DestroyCompressBuf()
{
	fprintf( stderr , "In %s File, %s Function" , __FILE__ , __FUNCTION__ ) ;
	if( compData.dest ){
		free( compData.dest ) ;
	}

	compData.model		= MODEL_UNKNOWN ;
	compData.lOrginSLen	= 0 ;
	compData.source		= NULL ;
	compData.dest			= NULL ;
	compData.seed			= NULL ;
	compData.compBuf		= NULL ;
	compData.stretch		= NULL ;
#ifdef SEND_BAND
	compData.extendbuf		= NULL ;
#endif
	compData.sLen			= 0 ;
	compData.dLen			= 0 ;
	compData.seedLen		= 0 ;
}


#ifdef SEND_BAND
/*-------------------------------------------------------------------------------------
*Name 		: CreateBandBuf
*Description 	: Create buffer for 1 Band(512 line) raster data
*Parameters : 
*	lBytesPerLine	: Length of one line ( in bytes)
*	line			: 1 Band = 512 line
*Precondition	: N/A
*Operation 	: Allocate memory for a 1 Band raw raster data
*Postcondition 	: 1 Band Size Memory is allocated
*Return 	:
*		0 	: Succeeded ; otherwise , Failed.
*History 		: 1.Created , by R.Tarao , BIL , 2003.01.15
*--------------------------------------------------------------------------------------*/
short	CreateBandBuf( unsigned long lBytesPerLine, short line )
{
	fprintf( stderr , "In %s File, %s Function" , __FILE__ , __FUNCTION__ ) ;
	short 		sRet = 1 	;
	
        if( lBytesPerLine <= 0 ){
                fprintf( stderr , kInvalidParameter ) ;	
		return sRet ;
	}
	
/*
*Allocate 1 Band memory
*/
	 Planes[ 0 ] = (unsigned char *)malloc( lBytesPerLine*line);
	 if( NULL == Planes[ 0 ] ){
		fprintf( stderr , "%s%s" , kError , kInsufficientMemory ) ;
		 return sRet ;
	 }

	return 0 ;
}

/*-------------------------------------------------------------------------------------
*Name 		: DestroyBandBuf
*Description 	: Destroy the raster line data buffer
*Parameters : 
*Precondition	: N/A
*Operation 	: Free memory
*Postcondition 	: raster data buffer is freed
*Return 		: N/A
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/
void	DestroyBandBuf()
{
	fprintf( stderr , "In %s File, %s Function" , __FILE__ , __FUNCTION__ ) ;
	if( Planes[ 0 ] ){
		free(Planes[ 0 ]) ;
	}
}
#else
/*-------------------------------------------------------------------------------------
*Name 		: CreateLineBuf
*Description 	: Create buffer for a line raster data
*Parameters : 
*	lBytesPerLine	: Length of one line ( in bytes)
*	iNumPlane		: Number of planes
*Precondition	: N/A
*Operation 	: Allocate memory for a line raw raster data
*Postcondition 	: Memory is allocated
*Return 	:
*		0 	: Succeeded ; otherwise , Failed.
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/
short	CreateLineBuf( unsigned long lBytesPerLine , int iNumPlane )
{
	fprintf( stderr , "In %s File, %s Function" , __FILE__ , __FUNCTION__ ) ;
	short 		sRet = 1 	;
	int 		i 		;
	
	if( lBytesPerLine <= 0 || iNumPlane <= 0 ){
		fprintf( stderr , kInvalidParameter ) ;	
		return sRet ;
	}
	
/*
*Allocate memory
*/
	 Planes[ 0 ] = malloc( lBytesPerLine );
	 if( NULL == Planes[ 0 ] ){
		fprintf( stderr , "%s%s" , kError , kInsufficientMemory ) ;
		 return sRet ;
	 }

	 for( i = 1 ; i < 4 ; i++ ){
		 if( i < iNumPlane ){
			Planes[ i ] = Planes[ i - 1 ] + lBytesPerLine / iNumPlane ;
		 }else{
		 	Planes[ i ] = NULL ;
		 }
	 }

	return 0 ;
}

/*-------------------------------------------------------------------------------------
*Name 		: DestroyLineBuf
*Description 	: Destroy the raster line data buffer
*Parameters : 
*Precondition	: N/A
*Operation 	: Free memory
*Postcondition 	: raster data buffer is freed
*Return 		: N/A
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/
void	DestroyLineBuf()
{
	fprintf( stderr , "In %s File, %s Function" , __FILE__ , __FUNCTION__ ) ;
	if( Planes[ 0 ] ){
		free(Planes[ 0 ]) ;
	}
}
#endif

