//#include <cups/cups.h>
/* #include <cups/string.h> */
//#include <cups/raster.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>

#include "../pd.h"
#include"../Models.h"
//#include "../option.h"

extern	unsigned short	model_index ;
extern	pt_model		model_series ;	//	1 = PCL mode9, 2 = YL dumb, 3 = 1030 dumb

unsigned short	GetModel( const unsigned char * pstrShortNickName ) ;	//Get model index and language from model name
short	CheckModel( model_check_num checkNumber ) ;		//Check supportion for specific check number

/*
*Supported models and their language number
*/
const unsigned char	aStrModelSupported[][ 64 ] = {
	/* 1 = QL */
#ifdef _QL500_650TD_
	"ql550",		/* 1 */
	"ql500",		/* 2 */
	"ql800",        /* 3 */
    "ql810w",       /* 4 */
    "ql820nwb",      /* 5 */
#else
	"1 QL-500",		/* 1 */
	"1 QL-550",		/* 2 */
	"1 QL-650TD",   /* 3 */
    "1 QL-570",     /* 4 */
    "1 QL-720NW",   /* 5 */
#endif
	
	//Add new supported models here!

} ;


/* Model Index list of supporting mode switch */
const unsigned short	asModelModeSwitch[] = {		/* USE_MODESWITCH_PREC */
#ifdef _QL500_650TD_
	MODEL_QL_650TD,
	MODEL_QL_570,
	MODEL_QL_720NW,
#else
	0x0003,				/* QL-650TD */
	0x0004,				/* QL-570 */
	0x0005,				/* QL-720NW */
#endif
} ;

/* Model Index List of supporting Compression */
const unsigned short	asModelCompression[] = {		/* USE_COMPRESSION_PREC */
	0x0003,				/* QL-650TD */
	0x0004,				/* QL-570 */
	0x0005,				/* QL-720NW */
} ;

/* Model Index List of supporting Auto Cut */
const unsigned short	asModelAutoCut[] = {	/* USE_AUTOCUT_PREC */
	0x0002,				/* QL-550 */
	0x0003,				/* QL-650TD */
} ;


//* Model Index List of supporting Serial Connection 
/*  #S1
const unsigned short	asModelSerial[] = {		// USE_SERIAL_PREC 
	0x0003,				// QL-650TD 
	0x0004,                         // QL-570 
} ;
*/

//Get model index and language from model name
unsigned short	GetModel( const unsigned char * pstrShortNickName )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	unsigned short i , num ;
	
	if( !pstrShortNickName ){
		return 0 ;
	}

	num = sizeof( aStrModelSupported ) /sizeof( aStrModelSupported[ 0 ] ) ;
#ifdef _QL500_650TD_
	model_series  = MODEL_UNKNOWN ;
	for( i = 0 ; i < num ; i++ )
	{
		if(strcmp( aStrModelSupported[ i ], pstrShortNickName) == 0 )
		{
			model_series  = MODEL_QL_550 + i;
			break;
		}
	}
	model_index = model_series;
	return model_series;
#else
	num = sizeof( aStrModelSupported ) /sizeof( aStrModelSupported[ 0 ] ) ;
	for( i = 0 ; i < num ; i++ ){
		if(!strcmp( pstrShortNickName , &( aStrModelSupported[ i ][ 2 ] ) ) ){
			break ;
		}
	}

	if( i >= num ){
		i = 0 ;
		model_series  = MODEL_UNKNOWN ;
	}else{
		model_series  = MODEL_QL ;//aStrModelSupported[ i ][ 0 ] - 0x30 ;
		i++ ;
	}
	model_index = i ;
	return i;
#endif

}

//Check supportion for specific check number
short	CheckModel( model_check_num checkNumber )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	unsigned short	sSize = 0 , i ;
	const unsigned short * paModels = NULL ;
	short			hasModel = 0 ;

	switch( checkNumber ){
	case USE_MODESWITCH_PREC :
		sSize	 = sizeof( asModelModeSwitch ) /sizeof( unsigned short ) ;
		paModels = ( unsigned short * )(&asModelModeSwitch[ 0 ] ) ;
		break ;
	case USE_COMPRESSION_PREC :
		sSize	 = sizeof( asModelCompression ) /sizeof( unsigned short ) ;
		paModels = ( &asModelCompression[ 0 ] ) ;
		break ;
	case USE_AUTOCUT_PREC :
		sSize	 = sizeof( asModelAutoCut ) /sizeof( unsigned short ) ;
		paModels = ( &asModelAutoCut[ 0 ] ) ;
		break ;
//#S1
//	case USE_SERIAL_PREC :
//		sSize	 = sizeof( asModelSerial ) /sizeof( unsigned short ) ;
//		paModels = ( &asModelSerial[ 0 ] ) ;
//		break ;
	default :
		return 0 ;
		break ;
	} ;

	for( i = 0 ; i < sSize ; i++ ){
		if( model_index == paModels[ i ] ){
			hasModel = 1 ;
			break ;
		}
	}

	return hasModel ;
}
