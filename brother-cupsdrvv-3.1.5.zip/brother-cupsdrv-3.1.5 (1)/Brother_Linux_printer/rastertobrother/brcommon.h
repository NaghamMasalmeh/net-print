/*=================================================================================*
*FileName:     	brcommon.h
*Description:	common functions 
*Revision:     	1.0									
*Date:         	2003.08.28							
*Author:       	Chenxujin , SteadyBJ 									
*Histroy:      	1.Chenxujin , Create
*==================================================================================*/

#ifndef _BRCOMMON_H_
#define _BRCOMMON_H_

#ifdef _cplusplus
extern "C" {
#endif/*_cplusplus*/

extern	void	copyData(unsigned char *src, unsigned char *dst, short len) ;
extern	void	clearData(unsigned char *dst, short len) ;
extern	short	checkZero(unsigned char	*dat, short len) ;
extern	void	invertData(unsigned char *src, unsigned char *dst, short len) ;
extern	void	setCommand(char *com,unsigned char *dat,short count) ;
extern	void	checkOptByte(char *com,short off,short cnt,unsigned short *comC) ;
extern	int	NumericLength( long num ) ;

#ifdef _cplusplus
}
#endif/*_cplusplus*/

#endif/*_BRCOMMON_H_*/

