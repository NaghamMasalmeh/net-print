#ifndef _OPTION_H_
#define _OPTION_H_

//#include <cups/cups.h>
//#include <cups/raster.h>

#define _PTOUCH_

#ifdef _PTOUCH_
#include "string.h"
#endif // _PTOUCH_


#ifdef _cplusplus
extern "C" {
#endif /* _cplusplus */

/* Print options */
#define kResolution                     "Resolution" /* Resolution */
#define kResolution_300dpi              "300dpi"

#define	kPageSize							"PageSize"
#define	kMedia								"media"

//#define	kAutoTapeCut						"BrAutoTapeCut"		/* Auto Tape Cut :{On , Off} */

#define kCutAtEnd                           "BrCutAtEnd"    /* Cut At End :{On , Off}

#define	kMirrorPrinting						"BrMirror"			/* Mirror Printing  :{On , Off} */
#define	kMargin								"BrMargin"			/* Set Margin for continuous tapes */

#define	kPriority							"BrPriority"
#define	kPriority_Speed						"BrSpeed"
#define	kPriority_Quality					"BrQuality"


#define kHalftonePattern                "BrHalftonePattern" /* Halftone Pattern */
#define kHalftonePattern_Binary         "Binary"            /* Binary */
#define kHalftonePattern_Dither         "Dither"            /* Dither */
#define kHalftonePattern_ErrorDiffusion "ErrorDiffusion"    /* Error Diffusion */

#if 1
/* Used in linux case */
#define kBrightness                     "BrBrightness"      /* Brightness */
#define kContrast                       "BrContrast"        /* Contrast */

#else // 1
/* Used in Mac case */
#define kBrightness                     "com.brother.ptouch.PrintSettings.Brightness"
#define kContrast                       "com.brother.ptouch.PrintSettings.Contrast"

#endif // 1

#define kTapeLength                     "com.brother.print.PtouchSettings.tapelength"
#define kOrientation                    "com.apple.print.PrintSettings.PMOrientation..n."


/* values for check box */
#define kOn                             "ON"    /* checked */
#define kOff                            "OFF"   /* unchecked */

/* values for Boolean option , such as ManualFeed */
#define kTrue                           "True"
#define kFalse                          "False"

extern int num_options ;
extern cups_option_t *options ;

extern void SetThisPPD( ppd_file_t * ppd ) ;
extern void ParseOptions( const char * argv5 ) ;
extern void FreeOptions() ;
extern const char * GetOption( const char * name ) ;
extern int CheckOptionValue( const char * option , const char * value ) ;

#ifdef    _cplusplus
}
#endif /* _cplusplus */

#endif /* _OPTION_H_ */

