# /bin/sh

PRINTER=$1
CMD=$2

if [ $CMD = -n ]; then
echo "brpapertoollpr -P $PRINTER $CMD Standard\ Address\ Label	 -w 29 -h 42"
brpapertoollpr -P $PRINTER $CMD Standard\ Address\ Label	 -w 29 -h 42

echo "brpapertoollpr -P $PRINTER $CMD Standard\ Address\ Label	 -w 29 -h 90"
brpapertoollpr -P $PRINTER $CMD Standard\ Address\ Label	 -w 29 -h 90

echo "brpapertoollpr -P $PRINTER $CMD Large\ Address\ Label	-w 38 -h 90"
brpapertoollpr -P $PRINTER $CMD Large\ Address\ Label	-w 38 -h 90

echo "brpapertoollpr -P $PRINTER $CMD Small\ Address\ Label	-w 62 -h 29"
brpapertoollpr -P $PRINTER $CMD Small\ Address\ Label	-w 62 -h 29

echo "brpapertoollpr -P $PRINTER $CMD Return\ Address\ Label	-w 17 -h  54"
brpapertoollpr -P $PRINTER $CMD Return\ Address\ Label	-w 17 -h  54

echo "brpapertoollpr -P $PRINTER $CMD Shipping\ Label	-w 62 -h  100"
brpapertoollpr -P $PRINTER $CMD Shipping\ Label	-w 62 -h  100

echo "brpapertoollpr -P $PRINTER $CMD Visitor\ Name\ Badge\ Label	-w 62 -h  100"
brpapertoollpr -P $PRINTER $CMD Visitor\ Name\ Badge\ Label	-w 62 -h  100

echo "brpapertoollpr -P $PRINTER $CMD CD/DVD\ Label	-w 58 -h  58"
brpapertoollpr -P $PRINTER $CMD CD/DVD\ Label	-w 58 -h  58

echo "brpapertoollpr -P $PRINTER $CMD File\ Folder\ Label	-w 17 -h  87"
brpapertoollpr -P $PRINTER $CMD File\ Folder\ Label	-w 17 -h  87

echo "brpapertoollpr -P $PRINTER $CMD Hanging\ File\ Forlder\ Label	-w 17 -h  54"
brpapertoollpr -P $PRINTER $CMD Hanging\ File\ Forlder\ Label	-w 17 -h  54

echo "brpapertoollpr -P $PRINTER $CMD 1/2\\\"\ Round\ Label	-w 12 -h 12"
brpapertoollpr -P $PRINTER $CMD 1/2\"\ Round\ Label	-w 12 -h 12

echo "brpapertoollpr -P $PRINTER $CMD 1\\\"\ Round\ Label -w 24 -h 24"
brpapertoollpr -P $PRINTER $CMD 1\"\ Round\ Label -w 24 -h 24

echo "brpapertoollpr -P $PRINTER $CMD Floppy\ Disk	-w 62 -h  50"
brpapertoollpr -P $PRINTER $CMD Floppy\ Disk	-w 62 -h  50

echo "brpapertoollpr -P $PRINTER $CMD Compact\ Flash\ \(TM\)	-w 12 -h  36"
brpapertoollpr -P $PRINTER $CMD Compact\ Flash\ \(TM\)	-w 12 -h  36

echo "brpapertoollpr -P $PRINTER $CMD Smart\ Media\ \(TM\)	-w 12 -h  26"
brpapertoollpr -P $PRINTER $CMD Smart\ Media\ \(TM\)	-w 12 -h  26

echo "brpapertoollpr -P $PRINTER $CMD Memory\ Stick\ \(TM\)	-w 12 -h  34"
brpapertoollpr -P $PRINTER $CMD Memory\ Stick\ \(TM\)	-w 12 -h  34

echo "brpapertoollpr -P $PRINTER $CMD MO\ -\ Face	-w 62 -h  45"
brpapertoollpr -P $PRINTER $CMD MO\ -\ Face	-w 62 -h  45

echo "brpapertoollpr -P $PRINTER $CMD Binder\\ 1-1\\/4\\\"\ -Spine	-w 29 -h  209"
brpapertoollpr -P $PRINTER $CMD Binder\ 1-1\/4\"\ -Spine	-w 29 -h  209

echo "brpapertoollpr -P $PRINTER $CMD Binder\ 2\\\"\ -Spine	-w 62 -h  209"
brpapertoollpr -P $PRINTER $CMD Binder\ 2\"\ -Spine	-w 62 -h  209

echo "brpapertoollpr -P $PRINTER $CMD 7\\\"\ Postage\ Label	-w 62 -h  184"
brpapertoollpr -P $PRINTER $CMD 7\"\ Postage\ Label	-w 62 -h  184

echo "brpapertoollpr -P $PRINTER $CMD 8\\\"\ Postage\ Label -w 62 -h  209"
brpapertoollpr -P $PRINTER $CMD 8\"\ Postage\ Label	-w 62 -h  209

fi
if [ $CMD = -d ]; then
echo "brpapertoollpr -P $PRINTER $CMD Standard\ Address\ Label"
brpapertoollpr -P $PRINTER $CMD Standard\ Address\ Label

echo "brpapertoollpr -P $PRINTER $CMD Large\ Address\ Label"
brpapertoollpr -P $PRINTER $CMD Large\ Address\ Label

echo "brpapertoollpr -P $PRINTER $CMD Small\ Address\ Label"
brpapertoollpr -P $PRINTER $CMD Small\ Address\ Label

echo "brpapertoollpr -P $PRINTER $CMD Return\ Address\ Label"
brpapertoollpr -P $PRINTER $CMD Return\ Address\ Label

echo "brpapertoollpr -P $PRINTER $CMD Shipping\ Label"
brpapertoollpr -P $PRINTER $CMD Shipping\ Label

echo "brpapertoollpr -P $PRINTER $CMD Visitor\ Name\ Badge\ Label"
brpapertoollpr -P $PRINTER $CMD Visitor\ Name\ Badge\ Label

echo "brpapertoollpr -P $PRINTER $CMD CD/DVD\ Label"
brpapertoollpr -P $PRINTER $CMD CD/DVD\ Label

echo "brpapertoollpr -P $PRINTER $CMD File\ Folder\ Label"
brpapertoollpr -P $PRINTER $CMD File\ Folder\ Label

echo "brpapertoollpr -P $PRINTER $CMD Hanging\ File\ Forlder\ Label"
brpapertoollpr -P $PRINTER $CMD Hanging\ File\ Forlder\ Label

echo "brpapertoollpr -P $PRINTER $CMD 1/2\\\"\ Round\ Label"
brpapertoollpr -P $PRINTER $CMD 1/2\"\ Round\ Label

echo "brpapertoollpr -P $PRINTER $CMD 1\\\"\ Round\ Label"
brpapertoollpr -P $PRINTER $CMD 1\"\ Round\ Label

echo "brpapertoollpr -P $PRINTER $CMD Floppy\ Disk"
brpapertoollpr -P $PRINTER $CMD Floppy\ Disk

echo "brpapertoollpr -P $PRINTER $CMD Compact\ Flash\ \(TM\)"
brpapertoollpr -P $PRINTER $CMD Compact\ Flash\ \(TM\)

echo "brpapertoollpr -P $PRINTER $CMD Smart\ Media\ \(TM\)"
brpapertoollpr -P $PRINTER $CMD Smart\ Media\ \(TM\)

echo "brpapertoollpr -P $PRINTER $CMD Memory\ Stick\ \(TM\)"
brpapertoollpr -P $PRINTER $CMD Memory\ Stick\ \(TM\)

echo "brpapertoollpr -P $PRINTER $CMD MO\ -\ Face"
brpapertoollpr -P $PRINTER $CMD MO\ -\ Face

echo "brpapertoollpr -P $PRINTER $CMD Binder\ 1-1\/4\\\"\ -Spine"
brpapertoollpr -P $PRINTER $CMD Binder\ 1-1\/4\"\ -Spine

echo "brpapertoollpr -P $PRINTER $CMD Binder\ 2\\\"\ -Spine"
brpapertoollpr -P $PRINTER $CMD Binder\ 2\"\ -Spine

echo "brpapertoollpr -P $PRINTER $CMD 7\\\"\ Postage\ Label"
brpapertoollpr -P $PRINTER $CMD 7\"\ Postage\ Label

echo "brpapertoollpr -P $PRINTER $CMD 8\\\"\ Postage\ Label"
brpapertoollpr -P $PRINTER $CMD 8\"\ Postage\ Label
fi

