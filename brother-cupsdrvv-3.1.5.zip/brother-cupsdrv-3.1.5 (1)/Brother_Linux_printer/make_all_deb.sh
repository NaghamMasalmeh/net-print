# ! /usr/bin

echo "Ready to make rastertobrpt1 filter......"
cd rastertobrother
make clean all
echo "***********************************************"
echo

echo "Ready to check rastertobrpt1......"
ldd -v rastertobrpt1
echo "***********************************************"
echo

echo "Ready to make brps2ps......"
cd ../ps2ps
make clean all
echo "***********************************************"
echo

echo "Ready to check brps2ps......"
ldd -v brps2ps
echo "***********************************************"
echo

echo "Ready to make brpapertoolcups......"
cd ../paper_size_tool/cups
make clean all
echo

echo "Ready to check brpapertoolcups......"
ldd -v brpapertoolcups
echo "***********************************************"
echo

echo "Ready to make brpapertoollpr......"
cd ../lpr
make clean all
echo

echo "Ready to check brpapertoollpr......"
ldd -v brpapertoollpr
echo "***********************************************"
echo

echo "Ready to make brcupsconfpt1......"
cd ../../cupswrapperfilter
make clean all
echo

echo "Ready to check brcupsconfpt1......"
ldd -v brcupsconfpt1
echo "***********************************************"
echo

echo "Ready to make mk_cupswrapper......"
./mk_cupswrapper
echo "*****************************"

echo "Ready to make brprintconfpt1......"
cd ../lprng/brprintconf
make clean all
echo "*****************************"

echo "Ready to check brprintconfpt1......"
ldd -v brprintconfpt1
echo "***********************************************"
echo

echo "Ready to make LPRng filter ShellScript......"
cd ../filter
./mk_filterMFC
echo "*****************************"

echo "Ready to make LPRng RPM Packages......"
cd ../release/english/dpkg/
rm -fr linux-2.6-intel/
./makePackageMFC_deb
BACKUP=RPM_`date '+%y%m%d_%H%M%S'`
mkdir ../../../../installer/dpkg/$BACKUP
mv -f ../../../../installer/dpkg/*lpr*.deb ../../../../installer/dpkg/$BACKUP
cp -f linux-2.6-intel/*.deb ../../../../installer/dpkg/
echo "*****************************"


cd ../../../../
echo "Ready to make brcupsconfpt1......"
cd cupswrapperfilter
make clean all
echo

echo "Ready to check brcupsconfpt1......"
ldd -v brcupsconfpt1
echo "***********************************************"
echo

echo "Ready to make CUPSWrapper RPM Packages......"
cd release/dpkg/
rm -fr linux-2.6-intel/
./makePackageMFC_debian

mv -f ../../../installer/dpkg/*cupswrapper*.deb ../../../installer/dpkg/$BACKUP
mv -f linux-2.6-intel/english/*.deb ../../../installer/dpkg/
echo "*****************************"

cd ../../../installer/dpkg
echo Please get the deb Packages in the folder \"installer/dpkg\"
ls -l *.deb
