/* $Id: message.h,v 1.2 2005/06/21 11:50:00 cvs Exp $ */

#ifndef	__MESSAGE_H__
#define	__MESSAGE_H__

/*
*Message type
*/
#define	kDebug				"DEBUG: "
#define	kDebug2				"DEBUG2: "
#define	kError				"ERROR: "
#define	kInfo					"INFO: "
#define	kPage				"PAGE: "
#define	kWarning				"WARNING: "

/* 
* messages 
*/
#define	kInvalidParameter		"Invalid Parameter(s).\n"
#define	kInsufficientMemory		"Insufficient memory!\n"
#define	kFailedHalftone			"Halftone process failed!\n"
#define	kUnsupportedFormat		"Unsupported data format!\n"
#define	kFailedSecureSettings		"Getting Secure print settings failed.\n"
#define	kUnknownModel		"Unknown printer model.\n"
#define	kFailedSendData		"Sending data failed!\n"
#define	kFailedInitJob			"Initializing printer for new job failed.\n"
#define	kFailedInitPage			"Initializing the printer for new page failed.\n"
#define	kEFailedSendLine_d2		"ERROR: Sending line No.%d failed!\n"
#define	kFailedNickName		"Getting the short nick name failed.\n"
#define	kInvalidFormatNickName	"Invalid format for short nick name.\n"
#define	kIPrintingProgress_dd5	 "INFO: Printing Page %d , %d%% comppleted...\n"
#define	kMainArguments		"Need arguments: job-id user title copies options [file]\n"
#define	kFailedOpenRasterFile	"Opening raster file failed!\n"
#define	kFailedOpenPPDFile		"Open PPD file Failed!\n"
#define	kFailedFunctionTable		"Setting function table failed!\n"
#define	kNoPage				"No pages found!\n"
#define	kPrintReady			"The printer is ready to print.\n"

/*
* Debug messages
*/
/* Header members */
	/* Standard Page Device Dictionary String Values */
#define	kDHeader_MediaClass			"Header->MediaClass[ 64 ]"
#define	kDHeader_MediaColor			"Header->MediaColor[ 64 ]"
#define	kDHeader_MediaType			"Header->MediaType[ 64 ]"
#define	kDHeader_OutputType			"Header->OutputType[ 64 ]"
	/* Standard Page Device Dictionary Integer Values */
#define	kDHeader_AdvanceDistance		"Header->AdvanceDistance"
#define	kDHeader_AdvanceMedia			"Header->AdvanceMedia"
#define	kDHeader_Collate				"Header->Collate"
#define	kDHeader_CutMedia				"Header->CutMedia"
#define	kDHeader_Duplex				"Header->Duplex"
#define	kDHeader_HWResolution0			"Header->HWResolution[ 0 ]"
#define	kDHeader_HWResolution1			"Header->HWResolution[ 1 ]"
#define	kDHeader_ImagingBoundingBox0	"Header->ImagingBoundingBox[ 0 ]"
#define	kDHeader_ImagingBoundingBox1	"Header->ImagingBoundingBox[ 1 ]"
#define	kDHeader_ImagingBoundingBox2	"Header->ImagingBoundingBox[ 2 ]"
#define	kDHeader_ImagingBoundingBox3	"Header->ImagingBoundingBox[ 3 ]"
#define	kDHeader_InsertSheet			"Header->InsertSheet"
#define	kDHeader_Jog					"Header->Jog"
#define	kDHeader_LeadingEdge			"Header->LeadingEdge"
#define	kDHeader_Margin0				"Header->Margins[ 0 ]"
#define	kDHeader_Margin1				"Header->Margins[ 1 ]"
#define	kDHeader_ManualFeed			"Header->ManualFeed"
#define	kDHeader_MediaPosition			"Header->MediaPosition"
#define	kDHeader_MediaWeight			"Header->MediaWeight"
#define	kDHeader_MirrorPrint			"Header->MirrorPrint"
#define	kDHeader_NegativePrint			"Header->NegativePrint"
#define	kDHeader_NumCopies			"Header->NumCopies"
#define	kDHeader_Orientation			"Header->Orientation"
#define	kDHeader_OutputFaceUp			"Header->OutputFaceUp"
#define	kDHeader_PageSize0				"Header->PageSize[ 0 ]"
#define	kDHeader_PageSize1				"Header->PageSize[ 1 ]"
#define	kDHeader_Separations			"Header->Separations"
#define	kDHeader_TraySwitch			"Header->TraySwitch"
#define	kDHeader_Tumble				"Header->Tumble"
	/* CUPS Page Device Dictionary Values */
#define	kDHeader_cupsWidth				"Header->cupsWidth"
#define	kDHeader_cupsHeight			"Header->cupsHeight"
#define	kDHeader_cupsMediaType			"Header->cupsMediaType"
#define	kDHeader_cupsBitsPerColor		"Header->cupsBitsPerColor"
#define	kDHeader_cupsBitsPerPixel		"Header->cupsBitsPerPixel"
#define	kDHeader_cupsBytesPerLine		"Header->cupsBytesPerLine"
#define	kDHeader_cupsColorOrder			"Header->cupsColorOrder"
#define	kDHeader_cupsColorSpace			"Header->cupsColorSpace"
#define	kDHeader_cupsCompression		"Header->cupsCompression"
#define	kDHeader_cupsRowCount			"Header->cupsRowCount"
#define	kDHeader_cupsRowFeed			"Header->cupsRowFeed"
#define	kDHeader_cupsRowStep			"Header->cupsRowStep"

/* Resolution messages */
#define	kDRes1200_1200				"1200 * 1200 dpi is set\n"
#define	kDRes1200_600					"1200 * 600 dpi is set\n"
#define	kDRes600_600					"600 * 600 dpi is set\n"
#define	kDRes300_300					"300 * 300 dpi is set\n"
#define	kDRes150_150					"150 * 150 dpi is set\n"

#endif/* __MESSAGE_H__ */
