/* $Id: compress_define.h,v 1.6 2005/07/26 12:09:18 cvs Exp $ */

/***************************************************************************
                          typedef.h  -  description
                             -------------------
    begin                : Wed Jun 8 2005
    copyright            : (C) 2005 by STD
    email                : liu.bin@steadybj.com
 ***************************************************************************/
#ifndef _TYPEDEF_H_
#define _TYPEDEF_H_

#define _MAC_USE_
#define XL2HB
#define WIN32_MAC
#define WINVER              0x0400

#define MULTIPAGE
#define COLOR_DRV
#define HPGL2
#define USE_DM_SCALE
#define	NewCalFunc				//new printer calibration function	//2001/11/09_m2_add
#define	NewCalFunc2				//new printer calibration function	//2001/11/20_m2_add
#define	GRAYTEXT				//2001/10/29_m2_add (monocro gray text on)
#define	NEW_LOG_FUNC			//2003/10/17 K1
#define	TRY_NO_BANDING			//2003/10/17_m2_modify_M-494(Low4C) (banding problem)

#define _cdecl              /* NULL */
#define XL_FAR_PASCAL       /* NULL */
#define L4C_FAR     		/* NULL */
#define L4C_PASCAL      	/* NULL */
#define CONST               /* NULL*/
#define FAR                 /* NULL */
#define NEAR                /* NULL */
#define far                 /* NULL*/
#define near                /* NULL*/
//#define NULL              /* NULL*/
#define true                1
#define false               0
#define TRUE                1
#define FALSE               0


#define EXIST_C  0x02
#define EXIST_M  0x04
#define EXIST_Y  0x08
#define EXIST_K  0x01

/*************************************
WORD        wTwoColorMode
**************************************/

#define	DMCOLORMODE_FULL	0
#define	DMCOLORMODE_TWO		1
#define	DMCOLORMODE_TREE	2
//C57-Y
#define	DMCOLORMODE_KC		3			//1998/03/31_m2_add_2color
#define	DMCOLORMODE_KM		4			//1998/03/31_m2_add_2color
#define	DMCOLORMODE_KY		5			//1998/03/31_m2_add_2color

#include "define.h"
#include "prtstruct.h"


typedef long 	            LONG;
//typedef unsigned long       DWORD;
typedef DWORD               PSREAL;
typedef int                 BOOL;
typedef char             	CHAR;
typedef short           	SHORT;
typedef unsigned char       BYTE;
typedef unsigned short      WORD;
typedef float               FLOAT;
typedef FLOAT               *PFLOAT;
typedef BOOL near           *PBOOL;
typedef BOOL far            *LPBOOL;
typedef BYTE near           *PBYTE;
typedef BYTE far            *LPBYTE;
typedef int near            *PINT;
typedef int far             *LPINT;
typedef WORD near           *PWORD;
typedef WORD far            *LPWORD;
typedef long far            *LPLONG;
typedef DWORD near          *PDWORD;
typedef DWORD far           *LPDWORD;
typedef void far            *LPVOID;
typedef CONST void far      *LPCVOID;
typedef void                *PVOID;
#if 1
#define VOID                void
#else
typedef void                VOID;
#endif
typedef BYTE                *LPSTR;
typedef BYTE                *PSTR;
typedef unsigned short      WCHAR;
typedef unsigned long       ULONG;
typedef ULONG               *PULONG;
typedef unsigned short      USHORT;
typedef USHORT              *PUSHORT;
typedef unsigned char       UCHAR;
typedef UCHAR               *PUCHAR;
typedef char                *PSZ;
typedef DWORD               COLORREF;
typedef DWORD               *LPCOLORREF;
typedef WCHAR               TCHAR, *PTCHAR;
typedef int                 INT;
typedef CHAR                *PCSTR;
typedef CHAR                *LPCSTR;
typedef DWORD               FLONG;
typedef WCHAR               *LPWSTR, *PWSTR;
typedef LPWSTR              PTSTR, LPTSTR;

#define __based(a)		/* NULL */
#define __segname(a)	/* NULL */
#define INTENSITY(r,g,b)  (BYTE)((((DWORD)(r)*299) + ((DWORD)(g)*587) + ((DWORD)(b)*114) + 499)/1000)

typedef struct tagSIZE
{
    LONG        cx;
    LONG        cy;
} SIZE, *PSIZE, *LPSIZE;

typedef SIZE               SIZEL;
typedef SIZE               *PSIZEL, *LPSIZEL;

typedef struct tagPOINT
{
    LONG  x;
    LONG  y;
} POINT, *PPOINT, NEAR *NPPOINT, FAR *LPPOINT;

typedef struct _POINTL      /* ptl  */
{
    LONG  x;
    LONG  y;
} POINTL, *PPOINTL;

typedef struct _RECTL       /* rcl */
{
    LONG    left;
    LONG    top;
    LONG    right;
    LONG    bottom;
} RECTL, *PRECTL, *LPRECTL;

typedef struct tagPOINTS
{
    SHORT   x;
    SHORT   y;
} POINTS, *PPOINTS, *LPPOINTS;

typedef struct tagBRRTCPARAM{
	short		sIsColor;
	short		sColorType;		//	Full Color / TWO color
	short		sBrightness;
	short		sContrast;
	short		sBlue;
	short		sGreen;
	short		sRed;
	short		sSaturation;
	short		sColorMode;
	short		sCaptMode;
	short		sImproveGray;
	short		sImproveBlack;
	short		sBlackImgAdj;
	BYTE		bColorEffect;
	BYTE		bCyan0;
	BYTE		bMagenta0;
	BYTE		bYellow0;
	BYTE		bBlack0;
	LPSTR		lpCmTbl;
	LPSTR		lpCalibTbl;
}BRRTCPARAM;
typedef	BRRTCPARAM	FAR *LPBRRTCPARAM;

typedef struct
{
	BYTE	all;
	BYTE	sun0;
	BYTE	sun1;
	BYTE	sun2;
	BYTE	sun3;
	BYTE	sun4;
	BYTE	sun5;
	BYTE	sun6;
	BYTE	sun7;
}SANTAIVAL;
typedef SANTAIVAL far*	LPSANTAIVAL;

/* Logical Font */
#define LF_FACESIZE         32
typedef struct tagLOGFONTW
{
    LONG      lfHeight;
    LONG      lfWidth;
    LONG      lfEscapement;
    LONG      lfOrientation;
    LONG      lfWeight;
    BYTE      lfItalic;
    BYTE      lfUnderline;
    BYTE      lfStrikeOut;
    BYTE      lfCharSet;
    BYTE      lfOutPrecision;
    BYTE      lfClipPrecision;
    BYTE      lfQuality;
    BYTE      lfPitchAndFamily;
    WCHAR     lfFaceName[LF_FACESIZE];
} LOGFONTW, *PLOGFONTW, NEAR *NPLOGFONTW, FAR *LPLOGFONTW;
typedef LOGFONTW LOGFONT;
typedef PLOGFONTW PLOGFONT;
typedef NPLOGFONTW NPLOGFONT;
typedef LPLOGFONTW LPLOGFONT;

typedef struct _devicemodeW {
////    WCHAR  dmDeviceName[CCHDEVICENAME];	//
    WORD dmSpecVersion;
    WORD dmDriverVersion;				//
    WORD dmSize;
    WORD dmDriverExtra;
    DWORD dmFields;
    short dmOrientation;		//
    short dmPaperSize;			//
//    short dmPaperLength;
    short dmPaperWidth;			//
//    short dmScale;
//    short dmCopies;				//
    short dmDefaultSource;
    short dmPrintQuality;		//
    short dmColor;				//
    short dmDuplex;
//    short dmYResolution;
//    short dmTTOption;
//    short dmCollate;
//    WCHAR  dmFormName[CCHFORMNAME];
    WORD   dmLogPixels;
    DWORD  dmBitsPerPel;		//
    DWORD  dmPelsWidth;
    DWORD  dmPelsHeight;
    DWORD  dmDisplayFlags;
    DWORD  dmDisplayFrequency;
    DWORD  dmICMMethod;
    DWORD  dmICMIntent;
//    DWORD  dmMediaType;
    DWORD  dmDitherType;
    DWORD  dmICCManufacturer;
    DWORD  dmICCModel;
    DWORD  dmPanningWidth;
    DWORD  dmPanningHeight;
} DEVMODEW, *PDEVMODEW, *NPDEVMODEW, *LPDEVMODEW;
typedef DEVMODEW DEVMODE;
typedef PDEVMODEW PDEVMODE;
typedef NPDEVMODEW NPDEVMODE;
typedef LPDEVMODEW LPDEVMODE;

/**************the following code added by zhangshumin. 2005.06.09***************/

// PSCRIPT output buffer

#define PSBUFFERSIZE 4096

typedef struct {
    DWORD       max;            // size of buffer
    PBYTE       pnext;          // pointer to next available byte
    DWORD       count;          // number of valid bytes
    BYTE        Buffer[PSBUFFERSIZE];
} WRITEBUF;

//	BRUSHSOURCE - bType
#define	BS_TYPE_NULL		0
#define	BS_TYPE_RGB			1		
#define	BS_TYPE_GRAY		2		
#define	BS_TYPE_PATTERN		3		

typedef struct{
	BYTE		bType;		
	DWORD		udwData;			//	RGBColor or GrayLevel or PatternSelectID
	POINTL		ptlPatternOrigin;
} BRUSHSOURCE;

#define	LD_MAX_STYLE		20	//	LineDashStyle is limited to 20 segments.
typedef struct{
	WORD		uwNumOfStyle;	//	Number of Style (Note: cStyle = 0 ,when Line is Solid )
	WORD		puwStyle[LD_MAX_STYLE];	
	WORD		uwDashOffset;	
} LINEDASH;

#ifdef	WIN32_MAC
	#define	XLGS_NEXT
#else
	#define	XLGS_NEXT	far
#endif
#define	S08		signed char			//        -128 ~        127
#define	U08		unsigned char		//           0 ~        255
#define	S16		signed short		//      -32768 ~      32767
#define	U16		unsigned short		//           0 ~      65535
#define	S32		signed long			// -2147483648 ~ 2147483647
#define	U32		unsigned long		//           0 ~ 4294967295
#define	R32		float				// 3.4E +/- 38(7columns)

typedef struct _XLGS		// XLGS
{
	struct _XLGS XLGS_NEXT *pstrXLGSNext;	// next XLGS pointer.
	short	sCharAngle;			//	-360 <= fCharAngle <= 360
	double	fCharScaleX;		//	-32768.0 <= fCharScaleX <= 32767.0
	double	fCharScaleY;		//	-32768.0 <= fCharScaleY <= 32767.0
	double	fCharShearX;		//	-32768.0 <= fCharShearX <= 32767.0
	double	fCharShearY;		//	-32768.0 <= fCharShearY <= 32767.0
	double	fCharBoldValue;		//	0.0 <= fCharBoldValue <= 1.0
	U08		ubFontName[17];	
	R32		reCharSize;	
	U16		uwSymbolSet;
	BYTE	bLineCap;			//	eButtCap , eRoundCap , eSquareCap or eTriangleCap
	BYTE	bLineJoin;			//	eMiterJoin , eRoundJoin , eSquareJoin or eNoJoin
	WORD	uwMiterLength;		//	
	WORD	uwPenWidth;			//	dwPenWidth >= 0
	LINEDASH	strLineDash;	//

	BYTE	bClipMode;			//	eNonZeroWinding or eEvenOdd
	BYTE	bClipType;			//	
	RECTL	rectClipRect;		//	for CP_TYPE_RECT

	BYTE	bFillMode;			//	eNonZeroWinding or eEvenOdd
	BYTE	bPaintTxMode;		//	eOpaque or eTransparent
	BYTE	bSourceTxMode;		//	eOpaque or eTransparent

	BYTE	bROP;				//	

	BYTE	bColorSpace;		//	eGray or eRGB

	BRUSHSOURCE	strBrush;		//	BrushSource
	BRUSHSOURCE	strPen;		//	BrushSource

//	CurrentClipPath	imagable area of the page	
//	CurrentFont	no font defined	
//	CurrentPath	no path defined	
//	HalftoneMethod	DitherMatrix eDeviceBest	
//	PageCTM	session defaults at the	current page orientation	
//	CharSubMode	eNoSubstitution	
//	WritingMode(2.0)	eHorizontal	
} XLGS;
typedef XLGS *PXLGS;

	typedef struct tagBRRGBTRIAD{
		BYTE	rgbBlue;
		BYTE	rgbGreen;
		BYTE	rgbRed;
	}BRRGBTRIAD;
	typedef	BRRGBTRIAD	L4C_FAR *LPBRRGBTRIAD;

	typedef struct tagBRCMMPARAM{
		short		Version;
		short		IsColor;
		short		Saturation;
		short		ColorMode;
		short		ObjectType;
		short		BlackImgAdj;
		LPSTR		lpCmTbl;
		BRRGBTRIAD	SrcRgb;
	}BRCMMPARAM;
	typedef	BRCMMPARAM	L4C_FAR *LPBRCMMPARAM;

typedef struct tagBRCMODEPARAM{
	short		Version;
	short		IsColor;
	short		PrtQuality;
	short		Brightness;
	short		Contrast;
	short		Red;
	short		Green;
	short		Blue;
	short		Saturation;
//04/02/20 M-LOW4C-610 for ResetDevice
	BYTE		bImpGray;
//04/02/20 M-LOW4C-610 end
	LPBYTE		lpSrcTable;
	LPBYTE		lpDstTable;
}BRCMODEPARAM;
typedef	BRCMODEPARAM	L4C_FAR *LPBRCMODEPARAM;

// rectangle extension

typedef struct {
    PSREAL          left;
    PSREAL          bottom;
    PSREAL          right;
    PSREAL          top;
    PSREAL          xoffset;
    PSREAL          yoffset;
} PSRECTEX;

// PostScript size

typedef struct {
    PSREAL          width;
    PSREAL          height;
} PSSIZE;

typedef struct
{
//    WCHAR   FormName[CCHFORMNAME];  // form name
//    CHAR    PaperName[CCHFORMNAME]; // printer paper name
    PSRECTEX  ImageArea;              // imageable area (points in 24.8 format)
    PSSIZE  PaperSize;              // paper size (points in 24.8 format)
//    BOOL    bLandscape;             // landscape mode?
//    WORD    featureIndex;           // page size feature index
                                    // OPTION_INDEX_ANY for custom page size
} PRINTERFORM, *PPRINTERFORM;

typedef void *HANDLE;

typedef HANDLE                  HHEAP;

//Booklet
#define	BOOKLET_NOT		0	//	Not Use
#define	BOOKLET_TYPE1	1	//	Left Binding
#define	BOOKLET_TYPE2	2	//	Right Binding
#define	BOOKLET_TYPE3	3	//	Top Binding
#define	BOOKLET_TYPE4	4	//	Bottom Binding

typedef	struct {
	DWORD		type;
	DWORD		BindingMargin;
	DWORD		DuplexUnit;
}	BOOKLET;

//
typedef struct {
	DWORD		splRotateFlag;			// 
	DWORD		angle;					//
} ROTATE;

//
typedef struct {
	BYTE		splin;					// StapleType setting
	BYTE		splout;					// JobOffset setting
} INOUT;


#define	SPL_MAX_USERNAME	64

typedef struct {
	WCHAR		splUserName[SPL_MAX_USERNAME];	// User name
	WCHAR		splDocumentName[128];	// Docment name
} JOBINFO;

//
typedef	struct	{
	short		splOutputMode;			//
	short		splOutputBin;			//
	BYTE		splBinFlags;			//
	BYTE		splMaxBinNumber;		//
	BYTE		splMinBinNumber;		//
	BYTE		splReserve	;			// Reserve
} BINCONTROL;

//
typedef struct {
	INOUT		splStaple;				// StapleType setting
	INOUT		splJobOffset;			// JobOffset setting
	INOUT		splPunch	;			// Punch setting

	INOUT		splReserve	;			// Reserve
} FINSHER;

typedef struct {
	BOOL		bFitToPaper;
	short		ftpPaperSize;			//see DEVMODE.dmPaperSize
	short		ftpPaperLenght;			//see DEVMODE.dmPaperLenght
	short		ftpPaperWidth;			//see DEVMODE.dmPaperPaperWidth
} FITTOPAPER, *LPFITTOPAPER;

typedef   struct{
	BYTE		bCollate;				//
	BYTE		bCopyNum;				//
} COPYINFO;

typedef	  struct{

//03/10/14 M-LOW4C-429
//at RESOURCE.H #define	DUPLEX_TYPE			0x00ff
//at RESOURCE.H #define	DUPLEX_MODE			0x0100
//at RESOURCE.H #define	DUPLEX_UNIT			0x0200
//at RESOURCE.H #define	DUPLEX_SET_DMDUPLEX	0x0400
#define DUPLEX_MANDUP_2NDJOB				0x8000	//Manual Duplex 2nd Step Job (set by Print Processor)
//03/10/14 M-LOW4C-429 end
	WORD		DuplexType;				//
	WORD		BindingOffset;			//
} MDCTRL;

typedef	  struct{
	WORD		StartPage;				//
	WORD		EndPage;				//
} PAGERANGE;

typedef	struct	{
	char		string[64];				// 
	DWORD		position;				// = DateWmarkFlgs
	LOGFONTW	logFont;				//
	COLORREF	color;					//
	COLORREF	bkcolor;				//
	DWORD		density;				// mono printer = 1 (fix)
	char		cWeek[7][6];			// Data Watermark Week string
	char		cMonth[12][6];			// Data Watermark Week string
} TIMESTAMP, *LPTIMESTAMP;


typedef struct{
	WCHAR			splCtrlName[32];		//V1	ProgramName
	WORD			splCtrlVersion;			//V1	VersionNumber
	WORD			splCSSize;				//V1	sizeof(SplCtrl)
	MDCTRL			splManualDuplexCtrl;	//V1	ManualDuplexControl
	LONG			splXin1Control;			//V1	Normal,2in1,4in1
	BYTE			splKeepFlag;			//V1
	BYTE			splPriority;			//V1	Normal,Top
	COPYINFO		splCopyInfo;			//V1
	PAGERANGE		splPageRange;			//V1
	WORD			splCountry;				//V1	Country code
	BYTE			splManualFeed;			//V1	1: manual feed on
	BYTE			splReverseOrder;		//V1
	short			splOrientation;			//V1	0, 90, 180, 270, 360 for landscape.
//	WMARK			splWaterMark;			//V1
	BYTE			splPageBoders;			//V1	none, solid, dash
	BYTE			MDplxPrnType;			//V1	Printer type 0:like HL730, 1:like HL1260 type //2000/1/13_mada_add
//	BYTE			splReserve[4];			//V1

	TIMESTAMP		splDateWmark;			//V3	Data Watermark
	FITTOPAPER		splFitPaper;			//V3
	FINSHER			splFinisherSetting;		//V3	Finisher setting
	BINCONTROL		splBinControl;			//V3	MX bin control
	ROTATE			splRotate;				//V3	rotate info
	short			splSrcSize;				//V3	Source Paper Size (sFitPaperDocSize)
	short			splDstSize;				//V3	Des    Paper Size (sFitPaperUseSize)
	DWORD			splScale;				//V3	= (wScaleSave)
	DWORD			splRetFlag;				//V3	from SPLOOER retun Flag
	DWORD			splAccessories;			//V3
	JOBINFO			splJobInfo;				//V3	Job Infomation	2000.12.7
	WORD			wMDupTray;				//V3	Manual Duplex Reverse print Tray.
	WORD			wReserve;				//V3
//	BYTE			splReserve[4];			//V3
	BYTE			splProcFlg1;			//V4	bit0:1=LotusFreelance flag/0=None(default)
											//V7	bit1:1=Landscape&Portrait in same JOB/0=different JOB(default) (from Ver 0x0007)

//05/04/18 M-LCF-133 & M-PDRV-97 Reserve of LONG alignment by BOOKLET
	BYTE			splReserve2[3];			//??	Reserved
//05/04/18 end

	BOOKLET			splBooklet;				// Booklet Structure
	BYTE			res_dll[20];			// Driver Resource Name (New Date & Time)
	

//05/04/18 M-LCF-133 & M-PDRV-97 use splProcFlg2
	#define	TRANS_BMP_WMARK		0x01
	BYTE			splProcFlg2;			//V8	bit0:1=Transparent drawing BMP Wmark/0=Background Drawing(default)
//05/04/18 end

//03/09/08 M-LOW4C-SPLCTRL-003  splReserve[3] ==> splReserve[4] (splEndStr(DWORD) is LONG alignment)
//05/04/18 M-LCF-133 & M-PDRV-97 be same as member of SPLCTRL of P.P. 
	BYTE			splReserve[2];			//V4	Reserved
	BYTE			splEndStr[4];			//V3	str= "EOSC"
//old	BYTE			splReserve[4];		//V4	Reserved
//old	DWORD			splEndStr;			//V3	str= "EOSC"
//05/04/18 end
} SPLCTRL;

#define	MOPY_MAX_JOBNAME	256
#define	MOPY_MAX_USERNAME	256

#ifdef NEW_LOG_FUNC
#define	BR_MAX_COMPUTERNAME_LENGTH	32
#else//NEW_LOG_FUNC
#define	MOPY_MAX_ATOM		32
#endif//NEW_LOG_FUNC

typedef struct _JOBREPRINTPARAMS {
	WORD	flags;
	short	password;
	WCHAR	szUser[MOPY_MAX_USERNAME];
	WCHAR	szJob[MOPY_MAX_JOBNAME];
#ifdef NEW_LOG_FUNC//M-LOW4C-231
	union {
		struct
		{
			WORD	CurJobAtom;
			WCHAR	szCurJobAtom[BR_MAX_COMPUTERNAME_LENGTH];
		};
		WCHAR	szComputer[BR_MAX_COMPUTERNAME_LENGTH + 1];
	};
#else//NEW_LOG_FUNC
	WORD	CurJobAtom;
	WCHAR	szCurJobAtom[MOPY_MAX_ATOM];
#endif//NEW_LOG_FUNC
	BYTE	cPrinterHdd;
	short	sCollateCopies;
} JOBREPRINTPARAMS, *PJOBREPRINTPARAMS;

#ifndef _PTOUCH_
//FR526 add Custom Setting Button part2
typedef struct _COLOREFFECT {
	short		epBrightness;				// adjust brightness
	short		epContrast;					// adjust Contrast
	short		epRed;						// adjust Red
	short		epGreen;					// adjust Green
	short		epBlue;						// adjust Blue
	short		epSaturation;				// adjust Saturation
} COLOREFFECT, *PCOLOREFFECT;
#endif

#define MAX_PRINTER_OPTIONS 64
#define		MAX_RESERVED_SIZE	64			//2001/11/28_m2_add
#define	MAXCOLOREFFECT	12

// Private devmode field for current version

typedef struct
{
    WORD        wSplOffset;                     // offset to SPLCTRL structure
    DWORD       dwPrivDATA;                     // private data id
    DWORD       dwFlags;                        // flag bits
#ifndef	_MAC_USE_
    COLORADJUSTMENT coloradj;                   // structure for halftoning
#endif	//_MAC_USE_

    WORD        wChecksum;                      // PPD file checksum
    WORD        wOptionCount;                   // number of options to follow
    BYTE        options[MAX_PRINTER_OPTIONS];   // printer options
	WORD        wSleepTime;						// sleep time
	WORD        wMultiPage;						// multi page 0:normal 2:2in1 4:4in1
	WORD        wEconomy;
	WORD        wMediaType;
	WORD        wPrtRET;                        // RET mode
	WORD        wPageProtect;                   // Page Protect
	WORD        wAPTMode;                       // APT mode
	WORD        wErrPrint;                      // Error Print 0:off 1:on
	WORD        PrtCaps;						// printer caps
    WORD        prtResExt;                      // printer resolution Extension (support 1200dpi)
    WORD        wResMode;                       // 0:normal 1:true 1200
    DWORD       dwLanguage;                     // support language
    BYTE        bMacroFlg;                      // Macro flag
    int         iMacroID;                       // Macro ID
    BYTE        bMacroPage;                     // Macro Page
    TCHAR		MacroName[24];                  // Macro Name
    BYTE        InsMacroTOL;                    // Macro Pos

#ifdef	COLOR_DRV

//color adjust 
	short		epBrightness;					// adjust brightness
    short   	epContrast;						// adjust Contrast
    short		epRed;							// adjust Red
    short		epGreen;						// adjust Green
    short		epBlue;							// adjust Blue
	short		epSaturation;					// adjust Saturation
	COLOREFFECT	ColorEffect[MAXCOLOREFFECT];	// adjust brightness/Contrast/Red/Green/Blue for each DocType/Res
	int			iSelCE;							// Selected Color Effect Number

	BOOL		isCalibSeed;

	BYTE		bCalibDefSeed[88];//	M-LCF-60	2005/2/28 Y.Miyata	
	BYTE		bCalibSeed[88];

    BYTE		epDocmodeType;					// Document Type setting
    											// 0:auto 1:Graphic 2:photo 3:custom
//04/02/18 M-LOW4C-610 add Reserve 3 byte to adjust Old Devmode
//04/02/26 M-LOW4C-613 UI setting
	BYTE		bOutputLutLog;					//Output LUT log
	BYTE		bReserve[2];
//old	BYTE		bReserve[3];
//04/02/26 M-LOW4C-613 end
//04/02/18 M-LOW4C-610 end

//04/02/09 M-LOW4C-610 BOOL ==> BYTE + BYTE + WORD
	BYTE		bImproveGrayColor;				// 1:Improve Gray Color On
	BYTE		bImproveBlackColor;				// 1:Improve Black Color On
	WORD		wReserve;
//old	BOOL		bImproveGrayColor;			// 1:Improve Gray Color On
//04/02/09 M-LOW4C-610 end

	#ifndef BST_INDETERMINATE
		#define BST_INDETERMINATE 2
	#endif

	BOOL		epCollate;						// TRUE: use dmCollate value. C34-H
	BOOL		bGray;							// Hide Control Flag
    WORD        prtDivNum;						// 1 to N page current page
    WORD        prtDivMax;						// 1 to N page
    WORD        dmSizeUnit;						// user defined size unit
    WORD        iCustomWidth;					// user defined width
    WORD        iCustomHeight;					// user defined height

//03/08/31 M-LOW4C-311 for 2) BYTE => WORD
	WORD		epCompressMode;					// compress mode only use in PCL
												// DMCMPRESS_OFF						0
												// DMCMPRESS_MODE5(PCLXL: Mode2)		1
												// DMCMPRESS_MODE9(PCLXL: Mode3)		3
												// DMCMPRESS_ADV(PCLXL:same as Mode2)	0x8001
												// DMCMPRESS_MODE9_M9(PCLXL: Mode9?)	9
	WORD		wBandSize;						// adjust Bandsize in Enable C5-H
#define	BAND_FLAG_RELATE_RES	0x01
#define	BAND_FLAG_AUTO_SIZE		0x02
	WORD		wBandFlag;						// 1:relates to resolution C5-H
//------------BY ONLY USED---------------------
	BYTE		epPrintDensity;					// DMDENSITY_LOW	0	add Honda
												// DMDENSITY_NOMAL	1	add Honda
												// DMDENSITY_MID	2	add Honda
												// DMDENSITY_HI		3	add Honda
	BYTE		fer;							// TRUE:"brmoncal.dat" exist
	float		fGamma[4];						//
	unsigned short BlackPoint[4];				//
//------------BY ONLY USED---------------------
#endif //COLOR_DRV
    WORD        prtGMode;                       // Printer Mode
    WORD        PrtMemory;
    BYTE        TTRaster;
    BYTE        bUseTTFonts;
    WCHAR       szUserName[32];
//	WORD		SaveGMode;		//    WORD        Pre_Media;
    WORD        wTwoColorMode; //C57-Y	WORD        wClPrtRET;                      // Color RET mode
	WORD        epCoolTime;
	DWORD       AutoSleepMode;
	DWORD       dwJobInterVal;
	WORD		wDuplexMode;	//bit9:Duplex Unit Use(1)/notUse(0)	1999/11/29_m2_add
								//bit8:Duplex On(1)/Off(0)			1999/11/29_m2_add
								//bit7-0:Duplex Type				1999/11/29_m2_add
	BYTE        bManDupBind;
	WORD		wDuplexBind;	//									2001/10/23_K1_add

	BYTE		bBookletUse;
	WORD		uwBookletType;
	int			dwBkMultiPage;        // 1:1in1,2:2in1,4:4in1

#ifdef QUICKMON //@1999.10.22 K1 add
	BYTE		bQIKMON;
#endif	//QUICKMON 1999.10.22 K1 end

	WORD		iModelInfo;				// model info 
	int			iMultiPage;
	DWORD		dwAccessories;
	WORD		wRamDiskSize;
	WORD		wOptAccessories;
	short		dmPaperDocSize;			// Document Paper Size (PUBLIC ID)
	short		dmPaperOutSize;			// Output Paper Size (PUBLIC ID)
	short		dmFirstSource;			// first page tray.
	short		dmSecondSource;			// other page tray.
	BYTE		bSepaTray;				// 1: Differerent paper for first page.
	DWORD		dwSecret;
	BYTE		bScaling;
#ifndef USE_DM_SCALE
	WORD		uwScale;
#endif	//USE_DM_SCALE
	BYTE		bImageProcess;			// Mirror & Reverse print
	BYTE		bBrstswnd;				// Status Monitor on/off
	WORD		wScaleSave;
//Mac	TRAYINFO	TrayInfo;				// Accessories Paper Source Setting

	WORD		wSelLang;				// IDS_LANG
	int			DateWmarkFlgs;			// Print mode
	LOGFONT		lfDateWmareFont;		// Font
	DWORD		dwDateWmareColor;		// Color
	DWORD		dwDateWmareBkColor;		// Transparency mode back color

	DWORD		dwHideCtrlFlag1;			//bit0:tatemansen enable flag(1:tatemansen/0:H2dither)
											//bit1:fine fast enable flag(1:enable 8x8 dither/0:disable)
	JOBREPRINTPARAMS	JobReprintParams;	//Job Spooling 1999/11/01_m2_add

//for PCLXL (The kernel driver can realize the follonwing functions)
#ifdef WATER_MARK
	DWORD		WaterMarkFlag;
	WORD		CurrentWaterMark;			//WaterMark Select No to draw Bmp by Kernel Driver
#endif //WATER_MARK

#ifdef NewCalFunc		//2001/11/09_m2_add
	WORD		CAdj_Enable;
	WORD		DefaultColorTblType;		//HL-2600CN for Hitachi Redish Engine Problem 2001/11/20_m2_add
  #ifndef NewCalFunc2	//2001/11/20_m2_add
	CADJPARAM	CmyGammaParams;
  #endif //2001/11/20_m2_add
#endif //NewCalFunc		//2001/11/09_m2_add

	BYTE		bPosNoBand;

	BYTE		Reserved[MAX_RESERVED_SIZE];		//if add work then dec. reserved size (max.64byte)

	SPLCTRL 	splOptions; 				// spooler option
} PRIVATEDEVMODE;

typedef struct
{
    DEVMODE         dmPublic;                   // public portion
    PRIVATEDEVMODE  dmPrivate;                  // private portion
} PSDEVMODE;

/**********************************************/

typedef struct _SURFOBJ
{
//    DHSURF  dhsurf;
//    HSURF   hsurf;
//    DHPDEV  dhpdev;
//    HDEV    hdev;
    SIZE	sizlBitmap;
    ULONG	cjBits;
    PVOID   pvBits;
    PVOID   pvScan0;
    LONG    lDelta;
//    ULONG   iUniq;
    ULONG   iBitmapFormat;
    USHORT  iType;
//    USHORT  fjBitmap;
} SURFOBJ;
/******************************************/

#ifdef NewCalFunc		//2001/11/09_m2_add
// new calibration function

	#define	CADJ_DRAFT	0
	#define	CADJ_FINE	1
	#define	CADJ_SFINE	2

//WORD CAdj_Enable
	#define	CADJ_ENABLE		0x0001
	#define	CADJ_ADV_MODE	0x0002

	#define	CADJ_VALUE_NUM			11
	#define	CADJ_VALUE_NUM_ALIGN	(CADJ_VALUE_NUM+3)&~3

	#define	CADJ_TBL_NUM			256

	typedef struct
	{
		// parameter
		WORD		DataID;			//11 point data ID (0)
		DWORD		PortID;			//Port ID :Reserved
		DWORD		TableID;		//Create Table(CAdj_Tblx_x) ID :Reserved
		char		CAdj_TblC_F [CADJ_TBL_NUM];
		char		CAdj_TblM_F [CADJ_TBL_NUM];
		char		CAdj_TblY_F [CADJ_TBL_NUM];
		char		CAdj_TblC_SF[CADJ_TBL_NUM];
		char		CAdj_TblM_SF[CADJ_TBL_NUM];
		char		CAdj_TblY_SF[CADJ_TBL_NUM];
	}CADJPARAM, *LPCADJPARAM;
#endif  //NewCalFunc		//2001/11/09_m2_add

/* Following is added by liubin 2005.7.26 */
#define MAXCOMMANDCOUNT		100
#define MAXCOMMANDLENGTH	100
typedef struct
{
	long lPJLCount;		// command count
	char PJLList[MAXCOMMANDCOUNT][MAXCOMMANDLENGTH];    // command list
}PJLCOMMANDLIST, *LPJLCOMMANDLIST;

/* Above is added by liubin 2005.7.26 */
	
typedef struct _DEVDATA
{
//    DWORD           dwID;               // 'PSDD' = driver id
    PSDEVMODE       dm;                 // devmode
//    PPRINTERDATA    pPrinterData;       // printer property data
//    HANDLE          hModule;            // handle to loaded module
    HHEAP           hheap;              // heap handle for current pdev.
//    HANDLE          hPrinter;           // handle passed in at enablepdev time.
//    PWSTR           pwstrDocName;       // pointer to document name.
//    DWORD           ScaledDPI;          // (DPI * dmScale) / 100.
    DWORD           cCopies;            // count of copies.
//    HDEV            hdev;               // engine's handle for device.
//    HSURF           hsurf;              // our surface handle.
//	HSURF			hsurfClip;			//	Out Clip Surface handle for Improve Brush Printing
//    HSURF           hsurfWholeC;         // our whole surface handle for Multi Page
//    HSURF           hsurfWholeM;         // our whole surface handle for Multi Page
//    HSURF           hsurfWholeY;         // our whole surface handle for Multi Page
//    HSURF           hsurfWholeK;         // our whole surface handle for Multi Page
	BYTE			*pbPlaneExist;
//	WORD			uwExistLength;
//	BOOL			isWholeSurfError;	//
//    HANDLE          hpal;               // handle to our palette.
//    HPPD            hppd;               // handle to PPD object
//    WORD            cSelectedFeature;   // number of printer-specific features
//    PFEATUREDATA    pFeatureData;       // data for handling printer features
//    CGS             cgs;                // current graphics state.
    DWORD           dwFlags;            // a bunch of flags defined above.
    PRINTERFORM     CurForm;            // current form information.
    PRINTERFORM		pfFitPaperDocForm;	// FitToPaper Document form information.
    PRINTERFORM		pfFitPaperOutForm;	// FitToPaper Output paper form information.
//    DWORD           maxDLFonts;         // downloadable font threshold.
    DWORD           iPageNumber;        // page number of current page.
//    PNTFM          *pDeviceNtfms;       // pointer to device font metrics table
//    ULONG           cDeviceFonts;       // count of device fonts.
//    ULONG           cSoftFonts;         // count of all soft fonts.
//    DWORD           cLocalSoftFonts;    // count of local soft fonts.
//    DWORD           cDownloadedFonts;   // count of downloaded fonts.
//    DLFONT         *pDLFonts;           // place to track downloaded fonts.
//    PSOFTNODE       pLocalSoftNode;     // soft node for local soft fonts
//    PSOFTNODE       pRemoteSoftNode;    // soft node for remote soft fonts
//    PBITARRAY       pFontFlags;         // bit array for PS fonts
//    PVOID           pSuppliedFonts;     // list of supplied fonts
	CHAR			BRMODE;				// temp spool switch
//	BYTE			ScaleFac;			// Scale factor 0:600,300, 1:150, 2:75
	BYTE			PclProtect;			// 0:dumb OK (AUTO PageProtect), 1:dumb NG
	BYTE			ResX2;				// 2:ResExt=1200, 1: else
	SHORT			ResExt;				// 0:normal, 600:1200dpi, 1200:w/1200dpi buffer

	SIZE			sizeMPPhys;			//	Physical size for Multi Page
	SIZE			sizeMPImage;		//	Image size for Multi Page

	POINT			ptBindingOffset;	//	BindingOffset

	SIZE			sizeFirstPagePhys;	//	Base Physical size for Multi Page
	SIZE			sizeFirstPageImage;	//	Base Image size for Multi Page
	BYTE			bFirstPageOrient;	// orientation 1:landscape

	#define	PAGE_ROTATE_LAYOUT_NONE				0
	#define	PAGE_ROTATE_LAYOUT_BASE_PORTLATE	1
	#define	PAGE_ROTATE_LAYOUT_BASE_LANDSCAPE	2

	BYTE			bPageRotateLayout;	
	BYTE			bYReverse;
#ifdef MULTIPAGE
	short			mpXOffset;			// adjust value for multipage
	short			mpYOffset;			// adjust value for multipage
#ifdef _MAC_CUPS_
	short			MultiPage;			// 0:normal, 1:2in1, 2:4in1
#else
	BYTE			MultiPage;			// 0:normal, 1:2in1, 2:4in1
#endif

	#define	POSTER_PRINT_OFF	1
	BYTE			bPosterPage;		// 1:normal, 2:1in2x2, 3:1in3x3
	BYTE			bPosterPosition;
#ifdef TRY_NO_BANDING
	BYTE			bPosterNoBand;
#endif //TRY_NO_BANDING
#endif //MULTIPAGE
	#define	STREAM_NAME_FMT			"PDATA%04d"
	#define	STREAM_MACRO_NAME_FMT	"%05d"

	#define	ST_MODE_OFF			0
	#define	ST_MODE_PAUSE		1
	#define	ST_MODE_READ		2
	#define	ST_MODE_SAVE_MACRO	3

	BYTE			bStreamMode;

	BYTE			realorient;			// orientation 1:landscape
	WORD			numBands;			// number of Band
	WORD			NBand;				// current band no.
	WORD			BandDepth;			// band size
	WORD			LastBandSz;			//
	short			Curx;				//
	short			Cury;				//
	short			MidRasGr;			// 
	short			RasWidth;			// raster graphics width
	short			RasHeight;			// raster graphics height
	short			CurrentMode;		// current compress mode
	short			XOffset;			//
	short			YOffset;			//
	ULONG			DataCounts;			// for HL-730, not use in PCL
	CHAR		    *CompBuf;			//
	int				iLastTextCol;
	int				iLastTextTrans;
	BYTE			bTextOut;			// use in textout
	LONG			epFreeMem;			// free memory
	DWORD			dwFontSize;			// Size of last TT font used
	short			epCurTTFont;		// current TT font id
	BYTE			bGlyphIndex;		// use in download font (glyphindex)
	BYTE			bTowerFeed;			// 1:TowerFeed mode N32-H
#ifndef XL2HB
	WORD			epwAPTMode;			// from dm.dmPrivate.wAPTMode
	BYTE			bImpGray;			//	Improve Gray Color
//04/02/09 M-LOW4C-610
	BYTE			bImpBlack;			//	Improve Black Color
//04/02/09 M-LOW4C-610 end
#endif //XL2HB

#ifdef	COLOR_DRV
	short			epd_exist;			// current page data data exist
										// 		use for auto doctype
	short			erYpos;				// Current position.

//04/02/20 M-LOW4C-610 for ResetDevice
	short			OrgdmColor;			//UI Setting
	int				iCurSelCE;			//Current Job Color Effect Number

	#define NO_SUB_LUT			0		//not set SubLut
	#define NOT_CHANGE_SUB_LUT	1		//remain current Sublut
	#define COMPARE_SUB_LUT		2		//can change current Sublut
	#define CHANGE_SUB_LUT		3
//04/02/20 M-LOW4C-610 end
	BYTE			bMakeSubLut;
#ifdef XL2HB
	#define NO_CALB_TBL			0		//not set CalibTable
	#define NOT_CHANGE_CALB_TBL	1		//remain current CalibTable
	#define COMPARE_CALB_TBL	2		//can change current CalibTable
	#define CHANGE_CALB_TBL		3

	BYTE			bMakeCalbTbl;
#endif //XL2HB


#ifdef XL2HB
	BRRTCPARAM		strBrRTCParam;		//for low4cFB
#else //XL2HB
	BRCMODEPARAM	strBrCModeParam;	//for low4c
#endif //XL2HB
	BRCMMPARAM		strBrCmmParam;		//for low4c

	BYTE			*pbSubLUT;			// Sub Look up Table Buffer
	//	M-LOW4C-613	2004/2/13 Y.Miyata Start
#define	LUT_NAME_MAX	100
#ifdef XL2HB
	CHAR			szLutName[LUT_NAME_MAX + 1];
#else
	CHAR			szLutNameVi[LUT_NAME_MAX + 1];
	CHAR			szLutNameMM[LUT_NAME_MAX + 1];
#endif //XL2HB
	//	M-LOW4C-613	2004/2/13 Y.Miyata End
	CHAR			*CMYKbuffer;		// halftoned CMYK buffer 
	LPVOID			LUTpointer;			// Current Document LUT pointer
	short			CurTblMedia;		// Current media type for LUT Table
	short			CurTblReso;			// Current resolution for LUT Table
	BYTE			CurTblMatch;		// Current color matching for LUT Table
	BYTE			CurTblDoc;			// Current document type for LUT table
	BYTE			epMode;				// GRXFLG flag 1 when Draw surface, send text.
	BYTE			epModeNow;			// judge color command is sent or not.
	short			SeedNo;				// Seed No.
	BYTE			RasSent;			// raster data is already sent? in pclcolor.c
										// use combined flag in aptdump.c
	BYTE			CMYBufID;			// CMY flag currently used.
	short			DumpPageHeight;			
	LPVOID			phalftonerun;		// **
//add 
    USHORT			cxDither;			//
    USHORT			cyDither;			//
	BYTE			jBCCStatus;			// Bitmap Color Convert Status
	#define	BCC_UNDEF	0x00			//  0:undefine
	#define	BCC_TEXT	0x01			//  1:Text define
	#define	BCC_GRAPH	0x02			//  2:Graph define
	#define	BCC_PHOTO	0x03			//  3:Photo define

	CHAR			epText;				// -1:not set Print Model Commad 0: set Print Model Commad
	WORD			epwRopOutput;		// Last Rop command output value keep area		1996/12/06_m2
	#define	SRC_TRANS_N		0x01		// bit0:Source Transparency flag
	#define	PAT_TRANS_O		0x02		// bit1:Pattern Transparency flag
	BYTE			fPMOutput;			// bit0:1(SourceTrans=Opaque)   0:(SourceTrans=Transparent)
										// bit1:1(PatternTrans=Opaque)  0:(PatternTrans=Transparent)
	#define	G_INTERSECTION	0x00		// 0:Grid Intersection (default)
	#define G_CENTERED		0x01		// 1:Grid Centered (Windows)
	#define G_ACT_CENTERED	0x02		// 2:Actual Grid Centered (ignore)
	BYTE			bPPStatus;			// Pixel Placement status (ESC*l#R : PP command) #=0,1
	PVOID			pPenInfo;			// set RGB Pen Color/Width for each PEN
	WORD			fPenSelect;			// selected pen No. keep work
#endif	//COLOR_DRV
#ifdef HPGL2
	BYTE			bNowMode;			//PCL(0)<->GL/2(1)
	BYTE			bNewMode;			//PCL(0)<->GL/2(1)
	BYTE			bSavePos;			// 1: save position
	BYTE			bClipObj;			// 1: is clipped.
	CHAR		   *GLPattern;			// save current user pattern
#endif //HPGL2

#ifdef NewCalFunc		//2001/11/09_m2_add
	int				iCmyGammaTblSel;
	short			ReMakeGammaTblReg;
	LPSTR			lpCAdj_TblC_CUR;
	LPSTR			lpCAdj_TblM_CUR;
	LPSTR			lpCAdj_TblY_CUR;
  #ifdef NewCalFunc2	//2001/11/20_m2_add
	CADJPARAM		CmyGammaParams;
  #endif //NewCalFunc2 2001/11/20_m2_add
#endif //NewCalFunc		//2001/11/09_m2_add

#ifndef USE_DM_SCALE
	double		fScale;
#endif	//USE_DM_SCALE

//=== add members for PCLXL =====================================================
	
	XLGS			strXLGS;
	ULONG			iClipUniq;
	BOOL			isClipExist;

	BOOL			bBeginChar;			//for PCLXL Download Chracter Command
	WORD			*pDLCode;			//for PCLXL Download Coracter Code Table
	DWORD			dwDLCodeTotal;		//pDLCode array total

#if (KERNEL_CAPS & MAKE_WMARK)
	//DrvEnablePDEV() set WMARK_FLG_ON bit to wWaterMarkWork according to devmode member
	//For the other setting mode flags, use the devmode members.
	//WaterMarkMode is dm.dmPrivate.WaterMarkFlag
	//else settings is dm.dmPrivate.splOptions.splWaterMark


	#define WMARK_OBJECT		0x0100	//Before just call text function for Watermark std Text
	#define WMARK_CALL_OUTTXT	0x0200	//Before just call text function for Watermark Outline Text
//	M-LCF-186	2005/4/5 Y.Miyata	Start
	#define WMARK_CALL_OUTTXT_T	0x0600	//Before just call text function for Watermark Outline Text & Transparent
//	M-LCF-186	2005/4/5 Y.Miyata	End

	//the following flags are used to make the transparent pattern watermark
	#define	WMARK_CALL_AND_SOLIDTXT	0x0010
	#define	WMARK_CALL_AND_BMP		0x0020

	#define WMARK_CALL_FLAGS	( WMARK_OBJECT	\
								| WMARK_CALL_OUTTXT	\
								| WMARK_CALL_OUTTXT_T	\
								| WMARK_CALL_AND_SOLIDTXT \
								| WMARK_CALL_AND_BMP \
								)

	#define WMARK_WORK_FLAGS	(WMARK_FLG_ON | WMARK_CALL_FLAGS)

	WORD			wWaterMarkWork;

#endif //(KERNEL_CAPS & MAKE_WMARK)

//	SPLSTATUS		SplStatus;


//	ENG_TIME_FIELDS Tm;					//use for Date&Time

#ifdef XL2HB
	BOOL			bSendBeginImage;
	BYTE			bExpandBrush;
#endif //XL2HB

//end ===========================================================================
	
#ifdef FILE_OPERATION
	DWORD			dwPageHeader;
	TCHAR			tmpFileName[MAX_PATH];
	BYTE			bOutput;
	BOOL			bFile;
	BOOL			bFileExist;
	BOOL			bPageStart;
	BOOL			bCollate;
	DWORD			dwFilePageCounter;

	//Manual Duplex
	BOOL			bManualDuplex;
	BOOL			bManualDuplexCollate;
	BOOL			bChangeBlock;
	BOOL			bFailWriteFile;
	BOOL			bSepaFinished;

	//Booklet
	BOOL			bBooklet;
	BOOL			bCollateBook;
	short			bookletSide;
	DWORD			dwStartPageBook;
	DWORD			dwBookletCount;

	//Booklet & Manual Duplex
	TCHAR			tmpFileNameBook[MAX_PATH];
	BOOL			bFileExistBook;
	DWORD			dwBeginPage;
#endif //FILE_OPERATION

//05/03/20 M-LCF-142 Date&Time by Kernel DRV Textout to Load Strings from LangDLL
#if (KERNEL_CAPS & MAKE_DATE_TIME)
	#define			DATE_TIME_LEN 64
#ifdef DATE_TIME_BY_LANGDLL

	TCHAR			DateTimeStrings[DATE_TIME_LEN];
#endif //MAKE_DATE_TIME
#endif
//05/03/20 M-LCF-142 end

//end ===========================================================================

    WRITEBUF        writebuf;           // write buffer
    DWORD           dwEndPDEV;          // end of pdev signature.

	PJLCOMMANDLIST	PJLarray;		// added by liubin 2005.7.26

} DEVDATA;
typedef DEVDATA *PDEVDATA;
/****************************************/
/* paper selections */
#define DMPAPER_FIRST                DMPAPER_LETTER
#define DMPAPER_LETTER               1  /* Letter 8 1/2 x 11 in               */
#define DMPAPER_LETTERSMALL          2  /* Letter Small 8 1/2 x 11 in         */
#define DMPAPER_TABLOID              3  /* Tabloid 11 x 17 in                 */
#define DMPAPER_LEDGER               4  /* Ledger 17 x 11 in                  */
#define DMPAPER_LEGAL                5  /* Legal 8 1/2 x 14 in                */
#define DMPAPER_STATEMENT            6  /* Statement 5 1/2 x 8 1/2 in         */
#define DMPAPER_EXECUTIVE            7  /* Executive 7 1/4 x 10 1/2 in        */
#define DMPAPER_A3                   8  /* A3 297 x 420 mm                    */
#define DMPAPER_A4                   9  /* A4 210 x 297 mm                    */
#define DMPAPER_A4SMALL             10  /* A4 Small 210 x 297 mm              */
#define DMPAPER_A5                  11  /* A5 148 x 210 mm                    */
#define DMPAPER_B4                  12  /* B4 (JIS) 250 x 354                 */
#define DMPAPER_B5                  13  /* B5 (JIS) 182 x 257 mm              */
#define DMPAPER_FOLIO               14  /* Folio 8 1/2 x 13 in                */
#define DMPAPER_QUARTO              15  /* Quarto 215 x 275 mm                */
#define DMPAPER_10X14               16  /* 10x14 in                           */
#define DMPAPER_11X17               17  /* 11x17 in                           */
#define DMPAPER_NOTE                18  /* Note 8 1/2 x 11 in                 */
#define DMPAPER_ENV_9               19  /* Envelope #9 3 7/8 x 8 7/8          */
#define DMPAPER_ENV_10              20  /* Envelope #10 4 1/8 x 9 1/2         */
#define DMPAPER_ENV_11              21  /* Envelope #11 4 1/2 x 10 3/8        */
#define DMPAPER_ENV_12              22  /* Envelope #12 4 \276 x 11           */
#define DMPAPER_ENV_14              23  /* Envelope #14 5 x 11 1/2            */
#define DMPAPER_CSHEET              24  /* C size sheet                       */
#define DMPAPER_DSHEET              25  /* D size sheet                       */
#define DMPAPER_ESHEET              26  /* E size sheet                       */
#define DMPAPER_ENV_DL              27  /* Envelope DL 110 x 220mm            */
#define DMPAPER_ENV_C5              28  /* Envelope C5 162 x 229 mm           */
#define DMPAPER_ENV_C3              29  /* Envelope C3  324 x 458 mm          */
#define DMPAPER_ENV_C4              30  /* Envelope C4  229 x 324 mm          */
#define DMPAPER_ENV_C6              31  /* Envelope C6  114 x 162 mm          */
#define DMPAPER_ENV_C65             32  /* Envelope C65 114 x 229 mm          */
#define DMPAPER_ENV_B4              33  /* Envelope B4  250 x 353 mm          */
#define DMPAPER_ENV_B5              34  /* Envelope B5  176 x 250 mm          */
#define DMPAPER_ENV_B6              35  /* Envelope B6  176 x 125 mm          */
#define DMPAPER_ENV_ITALY           36  /* Envelope 110 x 230 mm              */
#define DMPAPER_ENV_MONARCH         37  /* Envelope Monarch 3.875 x 7.5 in    */
#define DMPAPER_ENV_PERSONAL        38  /* 6 3/4 Envelope 3 5/8 x 6 1/2 in    */
#define DMPAPER_FANFOLD_US          39  /* US Std Fanfold 14 7/8 x 11 in      */
#define DMPAPER_FANFOLD_STD_GERMAN  40  /* German Std Fanfold 8 1/2 x 12 in   */
#define DMPAPER_FANFOLD_LGL_GERMAN  41  /* German Legal Fanfold 8 1/2 x 13 in */
#if(WINVER >= 0x0400)
#define DMPAPER_ISO_B4              42  /* B4 (ISO) 250 x 353 mm              */
#define DMPAPER_JAPANESE_POSTCARD   43  /* Japanese Postcard 100 x 148 mm     */
#define DMPAPER_9X11                44  /* 9 x 11 in                          */
#define DMPAPER_10X11               45  /* 10 x 11 in                         */
#define DMPAPER_15X11               46  /* 15 x 11 in                         */
#define DMPAPER_ENV_INVITE          47  /* Envelope Invite 220 x 220 mm       */
#define DMPAPER_RESERVED_48         48  /* RESERVED--DO NOT USE               */
#define DMPAPER_RESERVED_49         49  /* RESERVED--DO NOT USE               */
#define DMPAPER_LETTER_EXTRA        50  /* Letter Extra 9 \275 x 12 in        */
#define DMPAPER_LEGAL_EXTRA         51  /* Legal Extra 9 \275 x 15 in         */
#define DMPAPER_TABLOID_EXTRA       52  /* Tabloid Extra 11.69 x 18 in        */
#define DMPAPER_A4_EXTRA            53  /* A4 Extra 9.27 x 12.69 in           */
#define DMPAPER_LETTER_TRANSVERSE   54  /* Letter Transverse 8 \275 x 11 in   */
#define DMPAPER_A4_TRANSVERSE       55  /* A4 Transverse 210 x 297 mm         */
#define DMPAPER_LETTER_EXTRA_TRANSVERSE 56 /* Letter Extra Transverse 9\275 x 12 in */
#define DMPAPER_A_PLUS              57  /* SuperA/SuperA/A4 227 x 356 mm      */
#define DMPAPER_B_PLUS              58  /* SuperB/SuperB/A3 305 x 487 mm      */
#define DMPAPER_LETTER_PLUS         59  /* Letter Plus 8.5 x 12.69 in         */
#define DMPAPER_A4_PLUS             60  /* A4 Plus 210 x 330 mm               */
#define DMPAPER_A5_TRANSVERSE       61  /* A5 Transverse 148 x 210 mm         */
#define DMPAPER_B5_TRANSVERSE       62  /* B5 (JIS) Transverse 182 x 257 mm   */
#define DMPAPER_A3_EXTRA            63  /* A3 Extra 322 x 445 mm              */
#define DMPAPER_A5_EXTRA            64  /* A5 Extra 174 x 235 mm              */
#define DMPAPER_B5_EXTRA            65  /* B5 (ISO) Extra 201 x 276 mm        */
#define DMPAPER_A2                  66  /* A2 420 x 594 mm                    */
#define DMPAPER_A3_TRANSVERSE       67  /* A3 Transverse 297 x 420 mm         */
#define DMPAPER_A3_EXTRA_TRANSVERSE 68  /* A3 Extra Transverse 322 x 445 mm   */
#endif /* WINVER >= 0x0400 */
#define	DMPAPER_A6				70  /* A6 105 x 148 mm				 */
#define	DMPAPER_JENV_CHOU3		73  /* Japanese Envelope Chou #3		 */
#define	DMPAPER_JENV_YOU4 		91  /* Japanese Envelope You #4		 */
//sei
#define	DMPAPER_USERP			DMPAPER_USER		// add Honda
#define	DMPAPER_ORGJ			DMPAPER_USER+1		// add Honda
#define	DMPAPER_ORGK			DMPAPER_USER+2		// add Honda
#define	DMPAPER_ORGL			DMPAPER_USER+3		// add Honda
#define	DMPAPER_ORGM			DMPAPER_USER+4		//1999/11/11_m2_add
#define	DMPAPER_3X5				DMPAPER_USER+5		//1999/11/11_m2_add
#define	DMPAPER_13X19			DMPAPER_USER+6		// (269) 1999/11/11_m2_add
//  #define	DMPAPER_A4LONG			DMPAPER_USER+11		//1999/11/11_m2_add

#define	DMPAPER_LEF_MODE		DMPAPER_USER+768	//256+768=1024
#define DMPAPER_USER                256


#ifdef HL3400C_DRV
#define PLANEBUFFSIZE 600*13/8		//CMYK plane 1rater buffer size
#else //HL3400C_DRV
#define PLANEBUFFSIZE 720		//CMYK plane 1rater buffer size
#endif //HL3400C_DRV

#define	CMYKBUFSIZE1	 PLANEBUFFSIZE*4	//720dpi * 16 raster * 4plane
//bytemp
#ifdef XL2HB
	//use for RGB ==> CMYK table
	#define	RGB2CMYK_1PLANE_TBLSIZE	(PLANEBUFFSIZE*8)									//1 pixel 8bit
#if 0
	#define	RGB2CMYK_RANLEN_TBLSIZE	(PLANEBUFFSIZE*8*sizeof(WORD))						//Pixel * WORD size
	#define	RGB2CMYK_TOTALSIZE		(RGB2CMYK_1PLANE_TBLSIZE*4+RGB2CMYK_RANLEN_TBLSIZE)	//C/M/Y/K
#else
	#define	RGB2CMYK_TOTALSIZE		(RGB2CMYK_1PLANE_TBLSIZE*4)							//C/M/Y/K
#endif

	//Dithering or CAPT Buffer
	#define SEEDBUF_1PLANE			(PLANEBUFFSIZE*4)									//1 pixel 4bit for CAPT
	#define SEEDBUF_TOTALSIZE		(SEEDBUF_1PLANE*4)									//C/M/Y/K

	//Compress Buffer
	#define COMPRRESBUF_1PLANE		32768L
	#define COMPRRESBUF_TOTALSIZE	(COMPRRESBUF_1PLANE*4)								//C/M/Y/K

	//Total Buffer
	#define	CMYKBUFSIZE	 (RGB2CMYK_TOTALSIZE + SEEDBUF_TOTALSIZE + COMPRRESBUF_TOTALSIZE)

#else //XL2HB
#define	CMYKBUFSIZE	 PLANEBUFFSIZE*8*18	//600dpi * 8bit * (4 raster * 4plane + 2raster(NULL))
#endif //XL2HB

//added by zhangshumin. 2005.06.14
#ifndef NULL
#define NULL 0
#endif

// added by liubin 2005.6.22
#ifdef MULTIPAGE
#define PAGE_1IN1 0
#define PAGE_2IN1 2
#define PAGE_4IN1 4
#define PAGE_9IN1 9
#define PAGE_16IN1 16
#define PAGE_25IN1 25
#endif //MULTIPAGE


// added by liubin 2005.6.22
#define UNREFERENCED_PARAMETER(P)      {   (P) = (P);   }

// added by liubin 2005.6.22
/* bin selections */
#define DMBIN_FIRST         DMBIN_UPPER
#define DMBIN_UPPER         1
#define DMBIN_ONLYONE       1
#define DMBIN_LOWER         2
#define DMBIN_MIDDLE        3
#define DMBIN_MANUAL        4
#define DMBIN_ENVELOPE      5
#define DMBIN_ENVMANUAL     6
#define DMBIN_AUTO          7
#define DMBIN_TRACTOR       8
#define DMBIN_SMALLFMT      9
#define DMBIN_LARGEFMT      10
#define DMBIN_LARGECAPACITY 11
#define DMBIN_CASSETTE      14
#define DMBIN_FORMSOURCE    15
#define DMBIN_LAST          DMBIN_FORMSOURCE

#define DMBIN_USER          256     /* device specific bins start here */

#define WORDTOWORD(P)      (((P) & 0x00ff) << 8) | (((P) & 0xff00) >> 8) 
#define DWORDTODWORD(P)    (((P) & 0x000000ff) << 24) | (((P) & 0x0000ff00) << 8) | (((P) & 0x00ff0000) >> 8) | (((P) & 0xff000000) >> 24)

#endif
