# ! /usr/bin

echo "Ready to make LPRng RPM Packages......"
cd  lprng/release/english/dpkg/
rm -fr linux-2.6-intel/
./makePackarm_rpm
BACKUP=RPM_`date '+%y%m%d_%H%M%S'`
mkdir ../../../../installer/rpm/$BACKUP
mv -f ../../../../installer/rpm/*.rpm ../../../../installer/rpm/$BACKUP
mv -f /usr/src/rpm/RPMS/i386/*.rpm ../../../../installer/rpm/
echo "*****************************"

cd ../../../../installer/rpm
echo Please get the deb Packages in the folder \"installer/dpkg\"
ls -l *.rpm
