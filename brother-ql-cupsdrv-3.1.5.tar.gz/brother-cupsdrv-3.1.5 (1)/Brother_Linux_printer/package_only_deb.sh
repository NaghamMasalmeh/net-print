# ! /usr/bin

#1. Ready to make LPRng RPM Packages...
echo "1. Ready to make LPRng Debian Packages......"
cd lprng/release/english/dpkg/
rm -fr linux-2.6-intel/
./makePackageMFC_deb
BACKUP=Deb_`date '+%y%m%d_%H%M%S'`
mkdir ../../../../installer/deb/$BACKUP
mv -f ../../../../installer/deb/*lpr*.deb ../../../../installer/deb/$BACKUP
cp -f linux-2.6-intel/*.deb ../../../../installer/deb/
echo "*****************************"

#1. Ready to make CUPSWrapper RPM Packages...
echo "2. Ready to make CUPSWrapper deb Packages......"
cd ../../../../cupswrapperfilter/release/dpkg/
rm -fr linux-2.6-intel/
./makePackageMFC_debian

mv -f ../../../installer/deb/*cupswrapper*.deb ../../../installer/deb/$BACKUP
mv -f linux-2.6-intel/english/*.deb ../../../installer/deb/
echo "*****************************"

cd ../../../installer/deb
echo Please get the deb Packages in the folder \"installer/deb\"
ls -l *.deb
