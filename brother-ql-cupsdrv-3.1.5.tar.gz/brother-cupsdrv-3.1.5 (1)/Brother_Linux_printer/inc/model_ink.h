/* $Id: model_ink.h,v 1.2 2005/06/21 11:50:00 cvs Exp $ */

/*=================================================================================*
*FileName:     	model_INK.h
*Description:	model functions for model YL
*Revision:     	1.0									
*Date:         	2003.09.08						
*Author:       	Chenxujin , SteadyBJ 									
*Histroy:      	1.Chenxujin , Create
*==================================================================================*/
#ifndef _MODEL_YL_H_
#define _MODEL_YL_H_

#include "pd.h"	/* ���̥إå� */

#ifdef _cplusplus
extern "C" {
#endif/*_cplusplus*/

extern short MInitJob_INK(prn_model model, send_buffer* send_buf, SENDPARAM* sParam);
extern short MExitJob_INK(send_buffer* send_buf);

extern short MBeginJob_INK(SENDPARAM* sParam);
extern short MEndJob_INK();

extern short MBeginPage_INK();
extern short MEndPage_INK();

extern short MSendBandData_INK(int nWidth, int nHeight, send_buffer* send_buf, SENDPARAM* sParam, unsigned char* pBandBuf);

#ifdef _cplusplus
}
#endif/*_cplusplus*/

#endif/*_MODEL_YL_H_*/
