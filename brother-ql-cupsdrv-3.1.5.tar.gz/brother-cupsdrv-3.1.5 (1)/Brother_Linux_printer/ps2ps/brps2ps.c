/*
	brps2ps
	argv[0]	- brps2ps
	argv[1]	- left (float 72 dpi)
	argv[2]	- top (float 72 dpi)
	argv[3]	- right (float 72 dpi)
	argv[4]	- bottom (float 72 dpi)
	argv[5]	- tape width (300 dpi)
	argv[6]	- tape height (300 dpi)
	argv[7]	- "pstops" command path
	argv[8]	- input ps file (float 72 dpi)
	argv[9]	- output ps file (float 72 dpi)
	argv[10]	- temporary information file
*/

#include <stdlib.h>
#include <stdlib.h>
#include <stdio.h>
#define PARAMS_COUNT	11
//#define _MM_TO_INCH_	25.43859649
#define _MM_TO_INCH_	25.4
#define PSCOMMAND "PSCOMMAND=%s"
size_t fread_line_string(char *ptr, FILE *stream);
int main(int argc, char** argv)
{
	double left, top, right, bottom, tape_w, tape_h;
	char lp[1024];
    char lpline[1024];
	FILE* psfile;
	char *ptr;
	float ps_w = 0, ps_h = 0;
	
	double xshift, yshift;

	if(argc != PARAMS_COUNT)
	{
		return 0;
	}

	left = atof(argv[1]);
	top = atof(argv[2]);
	right = atof(argv[3]);
	bottom = atof(argv[4]);
	tape_w = atof(argv[5]);
	tape_h = atof(argv[6]);

	
	memset(lp, 0, 1024);

	psfile = fopen(argv[10],"rb");
	if(psfile == NULL)
	{
		fprintf(stderr, "ERROR:brps2ps terminates.\n");
       	return 0;
	}
	while(fread_line_string(lpline, psfile) > 0)
	{
		if(strstr(lpline, "PageSize") == NULL)
		{
			break;
		}
		strncpy(lp, lpline, strlen(lpline));
		lp[strlen(lpline)] = 0;
	}
	fclose(psfile);

	ptr = strstr(lp, "[");
	if( ptr != NULL)
	{
		char *ptr1;
		ptr++;
		ptr1 = strstr(ptr, "]");
		if(ptr1 != NULL)
		{
			*ptr1 = 0;
//			printf("%s\n", ptr);
		       sscanf(ptr, "%f %f", &ps_w, &ps_h);
//			printf("[%f, %f]\n", ps_w, ps_h);
		}
	}

	if( ps_w == 0.0  && ps_h == 0.0 )
	{
		sprintf(lp, "PSCOMMAND=cp\nCMDARGV=-f %s %s",
			argv[8],
			argv[9]);
/*
		// If no width and height in ps, printing it directly.   <- Liu Bin 2006.1.19
		
		xshift = -left / 72.0;
		yshift = tape_h / 300.0 - bottom / 72.0;
		sprintf(lp, "\"%s\" \"1:0@1.0(%fin,%fin)\" \"%s\" \"%s\"",
			argv[7],
			xshift,
			yshift,
			argv[8],
			argv[9]);
*/	}
	else
	{
		xshift = -0.06;
		yshift = tape_h / 300.0 - ps_h / 72.0 + 3.0 / _MM_TO_INCH_;
		sprintf(lp, "PSCOMMAND=%s\nCMDARGV=-w%f -h%f 1:0@1.0(%fin,%fin) %s %s",
			argv[7],
			ps_w,
			ps_h,
			xshift,
			yshift,
			argv[8],
			argv[9]);
	}

	printf(lp);	// write lp to output
//	system(lp);
	
	return 0;
}

//
// fread_line_string(char *ptr, FILE *stream)
//
size_t fread_line_string(char *ptr, FILE *stream)
{
	size_t count = 0;
	while(fread(ptr + count, 1, 1, stream) > 0)
	{
		if(*(ptr + count) == '\n')
		{
			count++;
			break;
		}
		count++;
	}
	ptr[count] = 0;
	return count;
}
