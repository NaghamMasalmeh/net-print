/*=================================================================================*
*FileName:     	rastertobrother.c
*Description:	definitions for main functions
*Revision:     	1.0									
*Date:         	2003.08.28							
*Author:       	Chenxujin , SteadyBJ 									
*Histroy:      	1.Chenxujin , Create
*			2.Chenxujin , Modify , 2003 . 09 . 02
*			3.Liu Bin , Modify , 2005 . 09 . 04
*			4.Liu Bin , Modify , 2006.02.27
*==================================================================================*/

/*
 * Include necessary headers...
 */
#include <string.h>
#include <cups/ppd.h>
#include <cups/cups.h>
#include <cups/raster.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <errno.h>
#include "rastertobrother.h"
#include "Models.h"
//#include "compress.h"
//#include "halftone.h"
#include "modelfunctions.h"
//#include "option.h"
#include "Message.h"
//#include "command.h"
#include "coloreffect.h"
#include "send.h"
#include "paper.h"
#include "../common/debugtool.h"//added by MSat

#define _LINUX_STD_
#define _SPLIT_SIZE_

#ifdef _SPLIT_SIZE_
#define _SPLIT_X2_ "X2"
#define _SPLIT_X3_ "X3"
#define _SPLIT_X4_ "X4"

int* g_is_backend_usb_QL = NULL;

long ReadRasPix(FILE* fp, unsigned char* lp, long pixelcount);
#endif
int	main( int  argc,	char *argv[] ) ;

#ifdef _LPR_
short	SendRasterDoc(	BR_LPR_INPUT_PARAMS *pInParam) ;
#else
short	SendRasterDoc(	cups_raster_t *			ras , 		\
				ppd_file_t * 			ppd 		) ;
#endif

#ifdef _LPR_
short	BeginPageData( BR_LPR_INPUT_PARAMS *pInParam, int iPage	) ;
short	SendPageData( BR_LPR_INPUT_PARAMS *pInParam, int iPage ) ;
#else
short	BeginPageData(	ppd_file_t *			ppd , 		\
						cups_page_header_t *		header , 	\
						int					iPage		) ;
short	SendPageData(	cups_raster_t *			ras , 		\
				ppd_file_t *			ppd , 		\
				cups_page_header_t *		header , 	\
				int					iPage		) ;
#endif
short	EndPageData( short sLastPage ) ;

void	CancelJob( int sig ) ;			/* I - Signal */

#ifndef _LINUX_STD_
void setSParam(	ppd_file_t			*	ppd ,	\
				cups_page_header_t	*	header, \
				LPPTPARAM				sParam ) ;
#endif

#ifdef _LPR_  //QL720NW

/* Function added for  trim the data  functionality */
void trimrasterdata(BR_LPR_INPUT_PARAMS *pInParam, int iPage );
unsigned int checkSameDataByte(unsigned char* srcData, unsigned int dataSize, unsigned int  value);

#endif //QL720NW



#ifdef	_LINUX_STD_

#define	_SPLIT_PAGE_DATA_ 	"/var/tmp/_brsplit_page_tmp_"

/* Temporary file for trim data */
#define	_TRIM_PAGE_DATA_ 	"/var/tmp/_trim_page_tmp_%d" //QL720NW

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include  "define.h"


#ifdef _PTOUCH_
#include "brerror.h"
#include "brresource.h"
#include "brfiletool.h"
extern BR_RESOURCE_INFO	g_rcInfo;
#endif

TJobData g_jobdata;

//#S1
//extern const unsigned char		kQLCmdSwitchDefault[ 4 ];
extern const unsigned char kQLCmdInitialize[ 2 ];

int initialize_share_memory();
void release_share_memory();

int initialize_share_memory()
{
//	sleep(1);
//	int fd = open(STATUSINFO, O_RDWR);
	int tmp = 0;
	int fd = open(STATUSINFO, O_RDWR | O_CREAT, 00777);
	if(fd == -1)
	{
		fprintf(stderr, "ERROR:Failed to create %s\n", STATUSINFO);
		return - 1;
	}
	write(fd, &tmp, sizeof(int));
	g_is_backend_usb_QL = (int*)mmap(0, sizeof(int), PROT_WRITE | PROT_READ, MAP_SHARED, fd, 0);
	close(fd);
	if (access(STATUSINFO, F_OK) == 0) {
        	if (chmod(STATUSINFO, 0666) != 0) {
            	fprintf(stderr, "safe_chmod: Failed to chmod %s: %s\n", STATUSINFO, strerror(errno));
        	} else {
            	fprintf(stderr, "safe_chmod: Permissions set to 0666 for %s\n", STATUSINFO);
        	}
    	} 
	
	if(g_is_backend_usb_QL == NULL)
	{
		fprintf(stderr, "ERROR: rastertobrotherpt1 initialized failed!\n");
		release_share_memory();
		return -1;
	}
	else
	{
		*g_is_backend_usb_QL = 0;
	}

	sleep(1);
	return 0;
}

void release_share_memory()
{
	if(g_is_backend_usb_QL)
		munmap(g_is_backend_usb_QL, sizeof(int));

	remove(STATUSINFO);
}

#endif

/*
*Global variables
*/
unsigned short	model_index		= 0 ;					/*      Index in model list      */
pt_model		model_series	= MODEL_UNKNOWN ;	/*	1 = QL , 2 = YL dumb, 3 = 1030 dumb	*/
//
MFUNTABLE	fun_table = { NULL , NULL , NULL , NULL , NULL , NULL };	/* Function table for models */

/*
	Global variables used for copies		Added by Chenxujin , SteadyBJ , 2004.08.19
*/
char			tempFilename[1024] = { '\0' };		/*	temp file full name	*/
int				fdPageData = -1 ;					/*	Temporary file , used to store raster data of one page	*/
int				nCopies = 1 ;						/*	Copy number	*/
int				nCollate = 1;						// 	Collate flag 2006.02.23 added by Liu Bin
int				iCopy	= 0 ;						/*	Copy index	*/

char Planes[4][720] ;


PTPARAM	ptParam = { "" , 0 , NULL , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 } ;

/* Gloabal variable  added  for trim data functionality  */
FILE *fppage; /* temp file name */	//QL720NW
/* Varialble added  for gui trim data functionality ON or OFF */
short		 trim = 0;	//QL720NW


/*
*Main function for rastertobrother filter
*/
int	main( int  argc,	char *argv[] )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	int				fd;				/* File descriptor */
	cups_raster_t	*ras;			/* Raster stream for printing */
	ppd_file_t		*ppd;			/* PPD file */

	short			sRet = 1 ;
	BR_LPR_INPUT_PARAMS	inParam = { 0 };
//        int                             i ;

 /*
  * Make sure status messages are not buffered...
  */
//	{
#ifdef _MY_DEBUG_
		fprintf(stderr, "ERROR:filter pid = %d\n", getpid());
#endif
//		fprintf(stderr, "ERROR:filter pid = %d\n", getpid());
//		sleep( 300 ) ;		//for debug
//	}

	setbuf(stderr, NULL);



//#ifdef _LINUX_STD_
#if 0
	if(initialize_share_memory() == -1)
	{
		perror("ERROR: Unable to create temporary memory.");
		return sRet;
	}
#endif




#ifdef _PTOUCH_

	
	sRet = InterpretParameters( argc, argv, &inParam );
	if( sRet != 0 ){
		release_share_memory();
		return sRet;
	}

	sRet = PrepareLPRngPrint( &ptParam, &inParam );
	if( sRet != 0 ){
		return sRet;
	}
    //copy inParam <=sParam 2016
	inParam.sParam = &ptParam;
	sRet = SendRasterDoc( &inParam );
#ifdef _LINUX_STD_
	release_share_memory();
#endif

//	sRet = SendRasterDoc( &inParam ) ;


#else

	int fd =0; // declared but never assigned/opened

	ras = cupsRasterOpen(fd, CUPS_RASTER_READ);
	if( NULL == ras ){
		fprintf( stderr , "%s%s" , kError , kFailedOpenRasterFile ) ;
#ifdef _LINUX_STD_
		release_share_memory();
#endif		
		return sRet ;
	}

 /*
  * Initialize the print device...
  */
	ppd = ppdOpenFile(getenv("PPD"));
	if( NULL == ppd ){
		fprintf( stderr ,  "%s%s" , kError , kFailedOpenPPDFile ) ;
		cupsRasterClose(ras);
		if (fd != 0)
			close(fd);
#ifdef _LINUX_STD_
		release_share_memory();
#endif			
		return sRet ;
	}

/*
*Parse options
*/
	ParseOptions( argv[ 5 ] ) ;
	SetThisPPD( ppd ) ;

/*
*Send Raster Data
*/
	sRet = SendRasterDoc( ras , ppd ) ;

#ifdef _LINUX_STD_
	release_share_memory();
#endif

/*
*Free options
*/
	FreeOptions() ;

/*
*Close the PPD file
*/
	if (ppd)
		ppdClose(ppd);

 /*
  * Close the raster stream...
  */
	cupsRasterClose(ras);
	if (fd != 0)
		close(fd);

#endif
	return sRet ;
}

/*-------------------------------------------------------------------------------------
*Name 		: SendRasterDoc
*Description 	: Send a opened raster file to the printer
*Parameters :
*		ras	: raster data file.
*		ppd	: ppd file.
*Precondition	: ras != NULL , ppd != NULL
*Operation 	: Translate and send raster data to the target printer.
*Postcondition 	: The raster file is printed.
*Return 	:
*		0 	: Succeeded ; otherwise , Failed.
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/
#ifdef _LPR_
short	SendRasterDoc(	BR_LPR_INPUT_PARAMS *pInParam) 
#else
short	SendRasterDoc(	cups_raster_t * ras , ppd_file_t * ppd )
#endif
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	short				sRet 	 = 1 ;
//	cups_page_header_t	header ;
	char *			pstrShortNickName = NULL ;
	int				iPage = 0 ;
	int fPageLoop = 1;
	
	int i_is_used_usb_QL = 0;
#ifdef _LPR_
	if( NULL == pInParam ){
#else
	if( NULL == ras || NULL == ppd ){
#endif
		fprintf( stderr , "%s%s", kError , kInvalidParameter ) ;
		return sRet ;
	}

/* Checking the Functanility is set ON or OFF */
#if 0
	if (ptParam.Trimtape == 1)		//QL720NW
	{
		trim = 1;
	}
	else 
	{
		trim = 0;	

	}
#endif
#if 1 
	if (pInParam->sParam->Trimtape == 1)
	{
		trim = 1;
	}
	else 
	{
		trim = 0;	

	}
#endif

/*
*The Get model and language from the short nickname.
*/
#ifdef _LPR_

#ifdef _QL500_650TD_
 //for next model 2016
	model_series  = MODEL_UNKNOWN;

	pInParam->sParam->pszNamePrinter=pInParam->pszNamePrinter;

	if( MODEL_UNKNOWN == GetModel( pInParam->pszNamePrinter ) ){
		fprintf( stderr , "%s%s" , kError , kUnknownModel ) ;
		return sRet ;
	}

#else
	model_series  = MODEL_QL;
#endif

#else
	pstrShortNickName = ppd->shortnickname ;

	if( NULL == pstrShortNickName ){
		fprintf( stderr , "%s%s" , kError , kFailedNickName ) ;
		return sRet ;
	}

	pstrShortNickName = strchr( pstrShortNickName , ' ' ) ;
	if( NULL == pstrShortNickName ){
		fprintf( stderr , "%s%s" , kError , kInvalidFormatNickName ) ;
		return sRet ;
	}

	pstrShortNickName++ ;

	if( MODEL_UNKNOWN == GetModel( pstrShortNickName ) ){
		fprintf( stderr , "%s%s" , kError , kUnknownModel ) ;
		return sRet ;
	}
#endif
	sRet = SetFunctionTable() ;
	if( sRet ){
		fprintf( stderr , "%s%s" , kError , kFailedFunctionTable ) ;
		return sRet ;
	}

/*
* Create send buffer for 128 lines
*/
	CreateSendBuf( model_series ) ;

#ifdef _LINUX_STD_
	g_jobdata.page_temp.iPageCount = 0;
	g_jobdata.page_temp.error = FALSE;

/*	
       if(LoadMediaType(MEDIA_TYPE_FILE) == -1)
       {
		return sRet;
	}
*/
#endif
/*
*Page loop
*/
	iPage = 0 ;
#ifdef _LINUX_STD_
//fr	sprintf(g_jobdata.page_temp.lpbuf, _TEMP_FILE_,pInParam->sParam->pszNamePrinter, g_jobdata.page_temp.iPageCount);
	sprintf(g_jobdata.page_temp.lpbuf, _TEMP_FILE_,getpid() , g_jobdata.page_temp.iPageCount);
	//umask(00666);
	g_jobdata.page_temp.pfile  = fopen(g_jobdata.page_temp.lpbuf, "w+b");
	if( g_jobdata.page_temp.pfile == NULL)
	{
		g_jobdata.page_temp.error = TRUE;
//		FreeMediaType();
		return sRet;
	}
#ifdef _PTOUCH_
	while(fPageLoop > 0 && g_jobdata.page_temp.error == FALSE)
	{
		sRet = ReadPpmFileHeader( pInParam->pFileInput, iPage );
		switch( sRet ){
		case -1:
			/* é¡ŒÈ¯8 */
			sRet = BrError( BR_ERROR_PRTFAIL, NULL );
			break;
		case 0 :
			/* 5EœÉ€ßœÐ€ */
			break;
		case 1 :
			/* Î» */
			sRet = 0;
			fPageLoop = 0;
			break;
		}
		if(fPageLoop == 0)
		{
			break;
		}

#else
	while( cupsRasterReadHeader( ras , &header ) && g_jobdata.page_temp.error == FALSE){
#endif
#else
	while( cupsRasterReadHeader( ras , &header )){
#endif

		iPage++ ;

		DEBUGMSG( stderr , "Page = %d\n" , iPage ) ;

		/*					By chenxujin , SteadyBJ , 2004.08.18
			header.NumCopies has different values on different OS
			*On Mac OS X 10.3.x, header.NumCopies is always 1 on every page header
			*On Mac OS X 10.4.0 Preview,if header.Collate = 1 , header.NumCopies is always 1 on every page header.
			*							if header.Collate = 0 , header.NumCopies is the set copies on the first page header,
			*													and it is 0 on all left page headers.
			*For a printer that has a command for Copies number,there is no problem.
			*For a printer that hasn't a such command,there is a little matter.
			*	Because the field,ras->fd,can't be repositioned!
			*	In order to solve this problem,a temporary file is created to store the raster data of one page.The temporary file can be repositioned.
			*	When printing,raster data for the first copy of one page will be gotten from the field,ras->fd.
			*	and raster data for the left copies of one page will be gotten from the temporary,fdPageData.
			*	There are several steps as below to implement copies when nocollate is set.
			*		1.Create a temporary file before the process of sending page data.
			*		2.Store page data into the temporary file when the first copy is being printed.
			*		3.After a copy is finished,reposition the temporary file to the beginning of the file.
			*		4.Get raster data from the ras->fd for the first copy.
			*		5.Get raster data from the temporary for all left copies
			*		6.After all copies are finished.
			*		7.Close and remove the temporary file.
			* [NOTE]	: this solution works well on both OS X 10.3.x and OS X 10.4.0 Preview.
		*/
		if( iPage == 1 ){/*	On OS 10.4.0 Preview, header.NumCopies is just set on the header of the first page	*/
#ifdef _LPR_
			nCopies  = pInParam->nCopies ;
			nCollate	= pInParam->nCollate ;	// 2006.02.23
			if( nCollate > 0 )
			{
				nCopies = 1;
			}
#else
			nCopies  = header.NumCopies ;
#endif

			/* If collate is set , header.NumCopies is always 1 */
			/* If just 1 copy is set , it doesn't need a temporary file*/
			/*	Because the mode9 and 1030 has a copy command , the nCopies is sent to the printer by command */
//			if( header.Collate == 1 || nCopies <= 1 || ((model_series != MODEL_YL) && (model_series != MODEL_FAX)) ){
//				nCopies = 1 ;
//			}
		}

        DEBUGMSG( stderr , "Copies = %d\n" , nCopies ) ;

		for( iCopy = 0 ; iCopy < nCopies ; iCopy++ ){
			ptParam.iPage = ( iPage - 1) * nCopies + iCopy + 1 ;
			if( ptParam.iPage > 1 ){
				EndPageData( 0 ) ;
#ifdef _LINUX_STD_
				if(g_jobdata.page_temp.pfile != NULL)
				{
					fclose(g_jobdata.page_temp.pfile);
					if (access(g_jobdata.page_temp.pfile, F_OK) == 0) {
							if (chmod(g_jobdata.page_temp.pfile, 0666) != 0) {
						    	fprintf(stderr, "safe_chmod: Failed to chmod %s: %s\n", g_jobdata.page_temp.pfile, strerror(errno));
							} else {
						    	fprintf(stderr, "safe_chmod: Permissions set to 0666 for %s\n", g_jobdata.page_temp.pfile);
							}
					    	}
					g_jobdata.page_temp.iPageCount++;
				}
//FR		      		sprintf(g_jobdata.page_temp.lpbuf, _TEMP_FILE_,pInParam->sParam->pszNamePrinter, g_jobdata.page_temp.iPageCount);
		      	sprintf(g_jobdata.page_temp.lpbuf, _TEMP_FILE_, getpid() , g_jobdata.page_temp.iPageCount);
				//umask(00666);
				g_jobdata.page_temp.pfile  = fopen(g_jobdata.page_temp.lpbuf, "w+b");
				if( g_jobdata.page_temp.pfile == NULL)
				{
					g_jobdata.page_temp.error = TRUE;
					break;
				}
#endif
			}

			/*  Call the  function for trim page data  */
			if(trim == 1)		//QL720NW
			{

			 	trimrasterdata( pInParam, ( iPage - 1) * nCopies + iCopy + 1 );
			}
			
			/*
				Create temp file to store the page data
			*/
#ifdef _LPR_
			if( nCollate == 0 && nCopies > 1 ){ // Modified by Liu Bin 2006.02.23
#else
			if( header.Collate == 0 && nCopies > 1 ){
#endif
				if( iCopy == 0 ){/* If it the first copy,create the temp file first */
#ifdef _LPR_
					fdPageData = myTempFd( tempFilename , sizeof( tempFilename ) ) ;
#else
					fdPageData = cupsTempFd( tempFilename , sizeof( tempFilename ) ) ;
#endif
					if( fdPageData < 0 ){
						fprintf( stderr , "ERROR: Unable to create a temporay file\n" ) ;
					}else{
						DEBUGMSG(stderr ,"DEBUG: Temporary file is created successfully! fd=%d , filename = %s\n", fdPageData , tempFilename ) ;
					}
				}else{/* If it not the first copy , reposition the offset to the beginning of the temporary file*/
					if( fdPageData >= 0 ){
						lseek( fdPageData , 0 , SEEK_SET ) ;
#ifdef _LINUX_STD_
         					iPage++ ;	// Added by Liu Bin 2005.11.23
#endif						
					}
				}
			}

			DEBUGMSG( stderr , "iPage = %d , iCopy = %d , Copies = %d\n" , iPage , iCopy , nCopies ) ;

			/*
			*Prepare the printer for the current job(when first page) and the current page
			*The number of current printing page = ( iPage - 1) * nCopies + iCopy + 1
			*/
#ifdef _LPR_
			sRet = BeginPageData( pInParam , ( iPage - 1) * nCopies + iCopy + 1 ) ;
#else
			sRet = BeginPageData( ppd , &header , ( iPage - 1) * nCopies + iCopy + 1 ) ;
#endif
			if( sRet ){
#ifdef _LINUX_STD_
				fclose(g_jobdata.page_temp.pfile);
				if (access(g_jobdata.page_temp.pfile, F_OK) == 0) {
					if (chmod(g_jobdata.page_temp.pfile, 0666) != 0) {
						fprintf(stderr, "safe_chmod: Failed to chmod %s: %s\n", g_jobdata.page_temp.pfile, strerror(errno));
					} else {
						fprintf(stderr, "safe_chmod: Permissions set to 0666 for %s\n", g_jobdata.page_temp.pfile);
					}
				}
				g_jobdata.page_temp.pfile = NULL;
				g_jobdata.page_temp.error = TRUE;
#endif
				break ;
			}

			/*
			*Send a Page
			*/
#ifdef _LPR_
			sRet = SendPageData( pInParam, ( iPage - 1) * nCopies + iCopy + 1 ) ;
#else
			sRet = SendPageData( ras , ppd , &header , ( iPage - 1) * nCopies + iCopy + 1 ) ;
#endif

			/*
			*End a page
			*/
//			EndPageData( 0 ) ;
			if( sRet ){
				break ;
			}

			/* All copies of one page are printed, then, close and remove the temp file */
#ifdef _LINUX_STD_
			if( nCollate == 0 && nCopies > 1 && iCopy == nCopies - 1 ){	// Modified by Liu Bin 2006.02.23
#else
			if( header.Collate == 0 && nCopies > 1 && iCopy == nCopies - 1 ){
#endif
				if(fdPageData >= 0 ){
					close( fdPageData ) ;
					remove( tempFilename ) ;
					fdPageData = -1 ;
				}
			}
		}
		if( sRet ){
#ifdef _LINUX_STD_
			fclose(g_jobdata.page_temp.pfile);
			if (access(g_jobdata.page_temp.pfile, F_OK) == 0) {
					if (chmod(g_jobdata.page_temp.pfile, 0666) != 0) {
						fprintf(stderr, "safe_chmod: Failed to chmod %s: %s\n", g_jobdata.page_temp.pfile, strerror(errno));
					} else {
						fprintf(stderr, "safe_chmod: Permissions set to 0666 for %s\n", g_jobdata.page_temp.pfile);
					}
				}
			g_jobdata.page_temp.pfile = NULL;
			g_jobdata.page_temp.error = TRUE;
#endif
			break ;
		}

#ifndef _LINUX_STD_
		if(g_jobdata.page_temp.pfile != NULL)
		{
//			fflush(g_jobdata.page_temp.pfile);
			fclose(g_jobdata.page_temp.pfile);
			if (access(g_jobdata.page_temp.pfile, F_OK) == 0) {
					if (chmod(g_jobdata.page_temp.pfile, 0666) != 0) {
						fprintf(stderr, "safe_chmod: Failed to chmod %s: %s\n", g_jobdata.page_temp.pfile, strerror(errno));
					} else {
						fprintf(stderr, "safe_chmod: Permissions set to 0666 for %s\n", g_jobdata.page_temp.pfile);
					}
				}
			g_jobdata.page_temp.iPageCount++;
		}
#endif                                                              
	}

/*
*End the job
*/
	if( iPage ){
#ifndef _LINUX_STD_
		// remove fflush
		fflush( stdout ) ;
#endif
		EndPageData( 1 ) ;		
#ifdef _LINUX_STD_
		if(g_jobdata.page_temp.pfile != NULL && g_jobdata.page_temp.error == FALSE)
		{
//			fflush(g_jobdata.page_temp.pfile);
			fclose(g_jobdata.page_temp.pfile);
			if (access(g_jobdata.page_temp.pfile, F_OK) == 0) {
					if (chmod(g_jobdata.page_temp.pfile, 0666) != 0) {
						fprintf(stderr, "safe_chmod: Failed to chmod %s: %s\n", g_jobdata.page_temp.pfile, strerror(errno));
					} else {
						fprintf(stderr, "safe_chmod: Permissions set to 0666 for %s\n", g_jobdata.page_temp.pfile);
					}
				}
			g_jobdata.page_temp.pfile = NULL;
			g_jobdata.page_temp.iPageCount++;
		}
#endif
		fun_table.lpfnMEndJob() ;
//		fwrite( kQLCmdPrintFeeding , sizeof(kQLCmdPrintFeeding),1,stdout) ;
	}

/*
*Destroy send buffer
*/
	DestroySendBuf() ;
#ifndef _LINUX_STD_
	FreeMediaType();
#endif
	

	
#ifndef _LINUX_STD_
//fr	g_jobdata.page_temp.pfile  = fopen(_TEMP_INIT_FILE_, "w+b");
		sprintf(g_jobdata.initfile, _TEMP_INIT_FILE_ ,getpid());
		g_jobdata.page_temp.pfile = fopen(g_jobdata.initfile, "w+b");
		if(g_jobdata.page_temp.pfile == NULL)
		{
			return sRet;
		}
/* #S1
		//* Command mode switch /
		if( CheckModel( USE_MODESWITCH_PREC ) )
		{
	  		if( fwrite( kQLCmdSwitchDefault , sizeof(kQLCmdSwitchDefault) , 1 , g_jobdata.page_temp.pfile ) < 1 )
	    		{
			  	fclose(g_jobdata.page_temp.pfile);
				chmod(g_jobdata.page_temp.pfile, 00666);
				fprintf(stderr , "ERROR: Send command failed.\n" ) ;
				return sRet ;
			}
		}
*/
		/* Initialize */
		if( fwrite( kQLCmdInitialize , sizeof(kQLCmdInitialize) , 1 , g_jobdata.page_temp.pfile ) < 1 )
		{
			fclose(g_jobdata.page_temp.pfile);
			if (access(g_jobdata.page_temp.pfile, F_OK) == 0) {
					if (chmod(g_jobdata.page_temp.pfile, 0666) != 0) {
						fprintf(stderr, "safe_chmod: Failed to chmod %s: %s\n", g_jobdata.page_temp.pfile, strerror(errno));
					} else {
						fprintf(stderr, "safe_chmod: Permissions set to 0666 for %s\n", g_jobdata.page_temp.pfile);
					}
				}
			fprintf(stderr , "ERROR: Send command failed.\n" ) ;
			return sRet ;
		}
		fclose(g_jobdata.page_temp.pfile);
		if (access(g_jobdata.page_temp.pfile, F_OK) == 0) {
					if (chmod(g_jobdata.page_temp.pfile, 0666) != 0) {
						fprintf(stderr, "safe_chmod: Failed to chmod %s: %s\n", g_jobdata.page_temp.pfile, strerror(errno));
					} else {
						fprintf(stderr, "safe_chmod: Permissions set to 0666 for %s\n", g_jobdata.page_temp.pfile);
					}
				}
		fprintf(stderr , "ERROR: init file OK, files count is %d.\n" , g_jobdata.page_temp.iPageCount);
#endif

/*
*Reset the function table
*/	
	ResetFunctionTable() ;	

	if (iPage == 0){
		fprintf( stderr , "%s%s", kError , kNoPage );
		sRet = 1 ;
	}else{
		sRet = 0 ;
		fprintf( stderr , "%s%s", kInfo , kPrintReady );			
	}
#ifdef _LINUX_STD_
		if(g_jobdata.page_temp.error == TRUE)
		{
			return sRet;
		}
		// Judge whether usb_QL have been called.
		if(g_is_backend_usb_QL != NULL)
		{
			if(*g_is_backend_usb_QL == 1)
			{
				i_is_used_usb_QL = 1;
			}
		}
#ifdef _LPR_
		if (i_is_used_usb_QL == 1 && pInParam->pFileOutput == NULL )
#else
		if (i_is_used_usb_QL == 1)
#endif
		{
			// tell backend page count
			fwrite(&g_jobdata.page_temp.iPageCount, 1, sizeof(int), stdout);
		}
		else
		{
			int ii = -1;
			for(ii = -1; ii  < g_jobdata.page_temp.iPageCount; ii++)
			{
				long lr_size = 0, lw_size = 0;
				char lpbuf[_MAX_BUF_], *ptr = NULL;
				if(ii == -1)
				{
//Fr				sprintf(g_jobdata.page_temp.lpbuf, "%s", _TEMP_INIT_FILE_);
					sprintf(g_jobdata.page_temp.lpbuf, _TEMP_INIT_FILE_ ,getpid());
				}
				else
				{
//FR					sprintf(g_jobdata.page_temp.lpbuf, _TEMP_FILE_,pInParam->sParam->pszNamePrinter, ii);
					sprintf(g_jobdata.page_temp.lpbuf, _TEMP_FILE_, getpid() , ii);
				}
#ifdef _LPR_
			// unnecessary to send data
				//umask(00666);
				g_jobdata.page_temp.pfile = fopen(g_jobdata.page_temp.lpbuf, "r+b");

				if( NULL == g_jobdata.page_temp.pfile)
				{
					fprintf(stderr, "ERROR: Send data failed.\n");
					break;
				}
				while( (lr_size = fread(lpbuf, 1, _MAX_BUF_, g_jobdata.page_temp.pfile)) > 0)
				{
					ptr = lpbuf;
					while( lr_size > 0)
					{
						if(pInParam->pFileOutput == NULL)
						{
							lw_size = fwrite(lpbuf, 1, lr_size, stdout);
						}
						else
						{
							lw_size = fwrite(lpbuf, 1, lr_size, pInParam->pFileOutput);
						}
						ptr += lw_size;
						lr_size -= lw_size;
					}
                      	}
				fclose(g_jobdata.page_temp.pfile);
#endif
				remove(g_jobdata.page_temp.lpbuf);
			}
		}
		if(pInParam->pFileOutput == NULL)
		{
			fflush(stdout);
		}
		else
		{
			fclose(pInParam->pFileOutput);
		}
		sleep(2);
#endif			
	return sRet ;
}

/*-------------------------------------------------------------------------------------
*Name 		: BeginPageData
*Description 	: Initialize the printer for a page
*Parameters : 
*		ppd		: ppd file.
*		header	: raster page header.
*		iPage		: Page number
Precondition	: ppd != NULL , header != NULL
*Operation 	: Send commands to initialize the target printer for a page.
*Postcondition 	: The printer is initialized.
*Return 	:
*		0 	: Succeeded ; otherwise , Failed.
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/
#ifdef _LPR_
short	BeginPageData(	BR_LPR_INPUT_PARAMS *pInParam, int iPage)
#else
short	BeginPageData(	ppd_file_t			*	ppd , \
						cups_page_header_t *	header , \
						int						iPage	)
#endif
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	short		sRet = 0 ;
//	int			i ;

#if defined( HAVE_SIGACTION )&&!defined( HAVE_SIGSET )
	struct sigaction	action ;
#endif/* HAVE_SIGACTION &&!HAVE_SIGSET */
	
#ifdef HAVE_SIGSET /* Use System V signals over POSIX to avoid bugs */
	sigset(SIGTERM, CancelJob);
#elif defined(HAVE_SIGACTION)
	memset(&action, 0, sizeof(action));
	
	sigemptyset(&action.sa_mask);
	action.sa_handler = CancelJob;
	sigaction(SIGTERM, &action, NULL);
#else
	signal(SIGTERM, CancelJob);
#endif /* HAVE_SIGSET */

#ifndef _LPR_
	if( NULL == header || NULL == ppd ){
		/*Error: Invalid parameters!*/
		return sRet ;
	}
#endif

/*
*Initialize the printer for a new job
*/
#ifdef _LINUX_STD_
	if( iPage == 1 ){
		/* Send blank data at the beginning of a job. */
//		for( i = 0 ; i < kNumBlankData ; i++ ){
//			putchar( '\0' ) ;
//		}

		/* Set the Ptouch Param structure */
#ifndef _LPR_
		setSParam( ppd , header , &ptParam ) ;
#endif
	}

	//umask(00666);
//Fr	g_jobdata.pInitfile = fopen(_TEMP_INIT_FILE_, "w+b");
	sprintf(g_jobdata.initfile, _TEMP_INIT_FILE_ ,getpid());
	g_jobdata.pInitfile = fopen(g_jobdata.initfile, "w+b");
	if( g_jobdata.page_temp.pfile == NULL)
	{
		return sRet;
	}

#ifdef _LPR_
       sRet = fun_table.lpfnMBeginJob( &ptParam ) ;
#else
	sRet = fun_table.lpfnMBeginJob( header , &ptParam ) ;
#endif
	
	fclose(g_jobdata.pInitfile);
	if (access(g_jobdata.pInitfile, F_OK) == 0) {
					if (chmod(g_jobdata.pInitfile, 0666) != 0) {
						fprintf(stderr, "safe_chmod: Failed to chmod %s: %s\n", g_jobdata.pInitfile, strerror(errno));
					} else {
						fprintf(stderr, "safe_chmod: Permissions set to 0666 for %s\n", g_jobdata.pInitfile);
					}
				}
	g_jobdata.pInitfile = NULL;

	if( sRet ){
		fprintf( stderr , "%s%s" , kError , kFailedInitJob ) ;
		return sRet ;
	}	
#else
	if( iPage == 1 ){
		/* Send blank data at the beginning of a job. */
		for( i = 0 ; i < kNumBlankData ; i++ ){
			putchar( '\0' ) ;
		}
		
		/* Set the Ptouch Param structure */
		setSParam( ppd , header , &ptParam ) ;
		sRet = fun_table.lpfnMBeginJob( header , &ptParam ) ;

		if( sRet ){
			fprintf( stderr , "%s%s" , kError , kFailedInitJob ) ;
			return sRet ;
		}
	}
#endif
/*
*Initialize the printer for a new page
*/
#ifdef _LPR_
       sRet = fun_table.lpfnMBeginPage( iPage ) ;
#else
	sRet = fun_table.lpfnMBeginPage( header , iPage ) ;
#endif

	/* Begin a Page */

	if( sRet ){
		fprintf( stderr , "%s%s" , kError , kFailedInitPage ) ;
		return sRet ;
	}

/*
*Alloc memory for the page
*/
	//lSourceLen =  ( header->cupsWidth + 7 )/8 ;
//#ifndef SEND_BAND
//	lSourceLen = (short)((( header->cupsWidth + 7) >> 3) + 3) & 0x0fffc;	//2004/10/07 R.Tarao
//#endif

//	iNumPlane = 1 ;									/* the filter just supports a mono printer at present */

	ResetSendBuf() ;								/* Reset Send buffer*/
//#ifdef SEND_BAND
//	CreateCompressBuf( model_series , header->cupsWidth , header->cupsHeight ) ;					/* memory for compression */
//#else
//	CreateCompressBuf( model_series , lSourceLen , header->cupsHeight ) ;					/* memory for compression */
//	CreateLineBuf(  header->cupsBytesPerLine , iNumPlane ) ;	/* memory for one line raster data */
//#endif

//	SetHalftoneMatrix( ppd, header ) ;					/* Set halftone matrix */
	return sRet ;
}

/*-------------------------------------------------------------------------------------
*Name 		: SendPageData
*Description 	: Send one page raster data to the printer
*Parameters : 
*		ras		: raster stream pointer
*		ppd		: ppd file.
*		header	: raster page header.
*		iPage		: Page number
Precondition	: ras != NULL , ppd != NULL , header != NULL
*Operation 	: Send one page data.
*Postcondition 	: Data are sent to the printer.
*Return 	:
*		0 	: Succeeded ; otherwise , Failed.
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/
#ifdef _LPR_
short	SendPageData( BR_LPR_INPUT_PARAMS *pInParam, int iPage)
#else                                             
short	SendPageData(	cups_raster_t *			ras , 		\
				ppd_file_t *			ppd , 		\
				cups_page_header_t *		header , 	\
				int					iPage		)
#endif
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	short		sRet = 0 ;
	int		iLine	= 0 ;
	unsigned int	remaining = 0 ;
	int				bytes = 0 ;
	unsigned char	*p = NULL ;
	
	unsigned char	* pSource = NULL ;
	int				nDataSize = 0 ;
	
	LPPTPARAM		sParam = &ptParam ;

	char lp_page_header[_MAX_BUF_] = {0};
	long l_page_header_size = 0;
	FILE* fp_page_header = NULL;
	int isplit_block = 0;

	FILE* fpPagefile ;
       int split_block_count  = 1;
	long var;	   //QL720NW
	//fprintf( stderr , "ERROR:my debug ptParam->sSourceHeight is %d \n",sParam->sSourceHeight) ;//MSat

#ifdef _LINUX_STD_
	// To fix Feed value 2005.12.5

//s	int		line_low = sParam->sTapeMargin - MM2DOT(3);
	int		line_low = 0;
	int		line_top = sParam->sSourceHeight - line_low;
	int		line_cur = 0;
	//fprintf( stderr , "ERROR:The line_low is %d and the sParam->sTapeMargin is %d\n",line_low,sParam->sTapeMargin) ;//MSat
    	//fprintf( stderr , "ERROR:The line_top is %d and the sParam->sSourceHeight is %d \n",line_top,sParam->sSourceHeight) ;//MSat
#endif

#ifdef _LPR_
	if( NULL == pInParam ){
		return 1 ;
	}
#else
	if( NULL == ras || NULL == header || NULL == ppd ){
		return 1 ;
	}
#endif

/*
*Line Loop for raster data
*/
#ifdef _LPR_
	pSource = malloc( sParam->sSourceWidthBytes * kBandSize ) ;
#else
	pSource = malloc( header->cupsBytesPerLine * kBandSize ) ;
#endif
	if( pSource == NULL ){
		fprintf( stderr , "ERROR: Allocate memory failed.\n") ;
		return 1 ;
	}
	
	
	sParam->bandNum			  = 0 ;
#ifdef _LPR_
	sParam->sSourceWidthBytes = sParam->sSourceWidth ;
#else
	sParam->sSourceWidthBytes = header->cupsBytesPerLine ;	
#endif
#ifdef _MY_DEBUG_	
	fprintf( stderr , "ERROR: header->cupsBytesPerLine = %d\n", sParam->sSourceWidth ) ;
#endif	
	sParam->pBandData		  = pSource ;

#ifdef _SPLIT_SIZE_
#ifdef _MY_DEBUG_       
       fprintf( stderr, "ERROR: sParam->pTape->ID = %s\n", sParam->pTape->ID);
#endif       
	if( strstr(sParam->pTape->ID, _SPLIT_X2_) )
	{
		split_block_count  = 2;
	}
	else if( strstr(sParam->pTape->ID, _SPLIT_X3_) )
	{
		split_block_count  = 3;
	}
	else if( strstr(sParam->pTape->ID, _SPLIT_X4_) )
	{
		split_block_count  = 4;
	}

	

	//
	// get page header information	added by liu bin 2006.3.17
	// Begin
	//
	if( split_block_count > 1 )	// split size
	{
		fp_page_header = fopen(_TEMP_FILE_HEADER_, "rb");
		if( fp_page_header != NULL)
		{
			long lr_size = 0, lw_size = 0;
			fseek(fp_page_header, 0L, SEEK_END);
			l_page_header_size = ftell(fp_page_header);
			if( l_page_header_size <= _MAX_BUF_  && l_page_header_size > 0)
			{
				fseek(fp_page_header, 0L, SEEK_SET);
				fread(lp_page_header, 1, l_page_header_size, fp_page_header);
			}
			fclose(fp_page_header);
		}
	}
	//
	// end
	//
	


#ifdef _MY_DEBUG_
	fprintf( stderr, "ERROR:  split_block_count= %d\n", split_block_count);
#endif	

	// store page data to a tempory file for split printing
	fpPagefile = fopen(_SPLIT_PAGE_DATA_, "w+b");
	if(fpPagefile == NULL)
	{
		fprintf( stderr , "ERROR: Failed to continue split printing!\n" ) ;
		close( fdPageData ) ;
		remove( tempFilename ) ;
		fdPageData = -1;
		return 1;
	}


	for(isplit_block = 0; isplit_block < split_block_count; isplit_block ++)
	{
		// Add page header to the split_size_printing page data.
		if( isplit_block > 0 )
		{
			lp_page_header[11] = 1;	// {n9} must be "1"
                     fwrite(lp_page_header, l_page_header_size, 1, g_jobdata.page_temp.pfile);
		}
		

		// initialize each variable
		iLine	= 0;
		remaining = 0 ;
		bytes = 0 ;
		sParam->bandNum			  = 0 ;
//		sParam->sSourceWidthBytes = sParam->sSourceWidth ;
		sParam->pBandData		  = pSource ;
		fseek(fpPagefile, 0, SEEK_SET);
#endif

	/* open the temporary file fo trim data functionality */
	if(trim == 1)		//QL720NW
	{
		sprintf(g_jobdata.page_temp.trimbuf,_TRIM_PAGE_DATA_,getpid() );

		fppage = fopen(g_jobdata.page_temp.trimbuf, "rb");
//		fppage = fopen(_TRIM_PAGE_DATA_, "rb");
	
		if (fppage == NULL)
			fprintf( stderr, "Error: Failed to  open the temporary file \n" );
	}


	for(sParam->bandline = 0 ; sParam->bandline < sParam->sSourceHeight ; sParam->bandline += kBandSize )
	{
		/* Get Band Height */
		if( sParam->bandNum < sParam->bandTotal - 1 ){
			sParam->bandHeight = kBandSize ;
		}else{
			sParam->bandHeight = sParam->lastBandH ;
		}

		nDataSize = sParam->sSourceWidthBytes * (int)(sParam->bandHeight) ;

		/*
		*Send page percent message.
		*/
		if( ( sParam->bandline & 127 ) == 0 || kBandSize > 127 ){
			fprintf( stderr , kIPrintingProgress_dd5 , iPage , 100 * sParam->bandline/sParam->sSourceHeight ) ;
		}

		/*
		*Read a line of raster data
		*/
#ifdef _SPLIT_SIZE_
		if(isplit_block > 0)
		{
			if(fread(pSource, 1, nDataSize, fpPagefile) < nDataSize)
			{
				fprintf( stderr , "ERROR: Failed to continue split printing!\n" ) ;
				close( fdPageData ) ;
				remove( tempFilename ) ;
				fdPageData = -1;
				fclose(fpPagefile);
				fpPagefile = NULL;
				isplit_block = -1;
				break;
			}
		}
		else
		{
#endif			
			int iscan_line;
			
			if( iCopy == 0 ){			/*	First copy of the page	*/			//Added by Chenxujin , SteadyBJ , 2004.08.19
			/*
				Get raster data from the raster data file for the first copy.
				And we have to store the raster data into the temp file
			*/

#ifdef _LPR_
			if(trim == 1)
			{
 				var = fread(pSource,nDataSize,1,fppage); 

			}
			else
			{
//				if( ReadRasPix( pInParam->pFileInput, pSource , nDataSize  ) < 1 ){

				var = ReadRasPix( pInParam->pFileInput, pSource , nDataSize );

			}
			if (var < 1){
#else
				if( cupsRasterReadPixels( ras , pSource , nDataSize ) < 1 ){
#endif
#ifdef _LINUX_STD_
         				isplit_block = -1;
#endif
					break ;
				}

#ifdef _LINUX_STD_
				// To fix Feed value 2005.12.5
#ifdef _MY_DEBUG_
				fprintf(stderr, "ERROR: line_low = %d, line_top = %d\n", line_low, line_top);
#endif
				for(iscan_line = 0; iscan_line < sParam->bandHeight; iscan_line++)
				{
					if( (line_cur + iscan_line) < line_low || (line_cur + iscan_line) > line_top)
					{
						memset(pSource + (iscan_line * sParam->sSourceWidthBytes), 0, sParam->sSourceWidthBytes);
					}
				}
				line_cur += sParam->bandHeight;
#endif
				

			/*
			*	Write data to the temporary file
			*/
				if( fdPageData >= 0 ){
					if( write( fdPageData , pSource , nDataSize ) < nDataSize ){
					/*
					*[NOTE],if the writing process failed,the temporary will be closed and removed,but the printing process will go on!
					*In this case,just one copy will be printed.
					*/
						fprintf( stderr , "ERROR: Writing raster data to temporary file failed,just ONE copy will be printed!\n" ) ;
						close( fdPageData ) ;
						remove( tempFilename ) ;
						fdPageData = -1 ;
					}
				}
			}else{				/* Copies after the FIRST one,read raster data from the temporary file ,NOT from the ras->fd       */
				if( fdPageData < 0 ){	/*	No temporary is created, just break	*/
					sRet = 1 ;
#ifdef _LINUX_STD_
         				isplit_block = -1;
#endif					
					break ;
				}else{			/*	The temporary is created , read raster data from it	*/

					p = pSource ;

					remaining = nDataSize ;

					while( remaining > 0 ){
						bytes = read( fdPageData , p , nDataSize ) ;
						if( bytes <=0 ){
							if( errno != EAGAIN && errno != EINTR ){
								fprintf( stderr , "ERROR: Reading raster data from temporary file failed!\n" ) ;
								sRet = 1 ;
#ifdef _LINUX_STD_
			         				isplit_block = -1;
#endif								
								break ;
							}else{
								continue ;
							}
						}

						remaining -= bytes;
						p += bytes ;
					}
				}
			}
#ifdef _LINUX_STD_
#ifdef _SPLIT_SIZE_
			if( fwrite(pSource, 1, nDataSize, fpPagefile) < (int)nDataSize )
			{
				fprintf( stderr , "ERROR: Failed to continue split printing!\n" ) ;
				close( fdPageData ) ;
				remove( tempFilename ) ;
				fclose(fpPagefile);
				fpPagefile = NULL;
				fdPageData = -1 ;
      				isplit_block = -1;
			}
#endif
		}
#endif		

		/*
		*Reading or writing raster data failed.
		*/
		if( sRet ){
#ifdef _LINUX_STD_
			isplit_block = -1;
#endif			
			break ;
		}


//		p = (Planes[0]) ;
//		for(x = 0 ; x < header->cupsBytesPerLine/2 ; x++ ){
//			chTmp = p[x];
//			p[x]=p[header->cupsBytesPerLine-x-1];
//			p[header->cupsBytesPerLine-x-1]=chTmp;
//		}
//		for( x =0 ; x < header->cupsBytesPerLine ; x++ ){
//			if( DitherMatrix[x%4][iLine%4] <= p[ x ]){
//				Buf[(x0+/*header->cupsBytesPerLine-*/x)/8] |= aBitMask[(x0+/*header->cupsBytesPerLine-*/x)%8] ;
//			}
//		}
//
//		fwrite(kQLCmdRasterHeader,sizeof(kQLCmdRasterHeader),1,stdout) ;
//		fwrite(Buf,sizeof(Buf),1,stdout) ;
//		memset( Buf , 0x00 , 90 ) ;
		/*
		*Send the line
		*/

//		if( 8 == header->cupsBitsPerColor ){		/*Gray*/
//			DEBUGMSG( stderr , "DEBUG: SendPageData()	HalftonePixMap\n") ;
//			sRet = HalftonePixMap( ReadLine, Planes[ 0 ] , header->cupsWidth);
//			if(sRet){
//				fprintf( stderr , kEFailedSendLine_d2 , iLine ) ;
//				break ;
//			}
//		#ifdef Dither1200600
//			if( ( header->HWResolution[ 0 ] == QLTY_TOP ) && !FindOptions( ppd, kOptionResolution ) ) {	// support 1200*600dpi , select 1200*600dpi
//				Trans2x2to2x1(Planes[ 0 ], header->cupsWidth, ReadLine);
//			}
//		#endif
//		}else if( 1 == header->cupsBitsPerColor ){	/*Mono*/
//	//		copyData( Planes[ 0 ] , compData.source ,  header->cupsBytesPerLine*ReadLine ) ;
//	//		compData.sLen = len ;
//	//		send_buf.dataExist = 1;
//		}else{
//			fprintf( stderr , "%s%s" , kError , kUnsupportedFormat ) ;
//			return sRet ;
//		}



//#ifdef SEND_BAND
////		sRet = fun_table.lpfnMSendLine( header , iPage , ReadLine , ( Planes[ 0 ] ) , header->cupsBytesPerLine , ppd) ;
//#else
#ifdef _SPLIT_SIZE_

              	if (isplit_block > 0)
	              {
				int irow;
				/* example : slipt size = 4
				| print area | <----------- not be printed ---------->|
				-----------------------------------------------------------------
				| block 0    |  block 1   |  block 2   |  block 3   | <- line 0
				| block 0    |  block 1   |  block 2   |  block 3   | <- line 1
				| block 0    |  block 1   |  block 2   |  block 3   | <- line 2
				| block 0    |  block 1   |  block 2   |  block 3   | <- line 3
				......
				| block 0    |  block 1   |  block 2   |  block 3   | <- line n
				-----------------------------------------------------------------
				move block data to print area.
				*/

				// prevent memory overflow
				int iLength = sParam->pTape->usPrintAreaWidth;
				if( (sParam->pTape->usPrintAreaWidth * (isplit_block + 1)) > sParam->sSourceWidthBytes)
				{
					iLength = sParam->sSourceWidthBytes - sParam->pTape->usPrintAreaWidth * isplit_block;
				}

				// Move the page data out of printing area to the printing area.
#ifdef _MY_DEBUG_
				fprintf(stderr, "ERROR:iLength=%d, sParam->pTape->usPrintAreaWidth = %d\n", iLength, sParam->pTape->usPrintAreaWidth);
#endif
				for( irow = 0; irow < sParam->bandHeight; irow++)
				{
					memcpy(	sParam->pBandData + sParam->sSourceWidthBytes * irow,
							sParam->pBandData + sParam->sSourceWidthBytes * irow + sParam->pTape->usPrintAreaWidth * isplit_block,
							iLength);
					if(iLength < sParam->pTape->usPrintAreaWidth)
					{
					      memset(
						sParam->pBandData + sParam->sSourceWidthBytes * irow + iLength,
					       0, sParam->sSourceWidthBytes - iLength);
					}
				}

			}
			
			sRet = fun_table.lpfnMSendBand( sParam ) ;
#else
		sRet = fun_table.lpfnMSendBand( sParam ) ;
#endif
//#endif
		if( sRet ){
			fprintf( stderr , kEFailedSendLine_d2 , iLine ) ;
			break ;
		}

		sParam->bandNum++ ;
	}

	if(trim == 1)		//QL720NW
	{
		fclose(fppage);	
	}
		
#ifdef _SPLIT_SIZE_
		if( isplit_block < split_block_count  - 1 && isplit_block >= 0)
		{
			EndPageData( 0 ) ;

	        	if(g_jobdata.page_temp.pfile != NULL)
			{
				fclose(g_jobdata.page_temp.pfile);
				chmod(g_jobdata.page_temp.pfile, 00666);
				g_jobdata.page_temp.iPageCount++;
			}

//FR		       sprintf(g_jobdata.page_temp.lpbuf, _TEMP_FILE_, pInParam->sParam->pszNamePrinter , g_jobdata.page_temp.iPageCount);
		       sprintf(g_jobdata.page_temp.lpbuf, _TEMP_FILE_, getpid()  , g_jobdata.page_temp.iPageCount);
			//umask(00666);
			g_jobdata.page_temp.pfile  = fopen(g_jobdata.page_temp.lpbuf, "w+b");
			if( g_jobdata.page_temp.pfile == NULL)
			{
				g_jobdata.page_temp.error = TRUE;
				break;
			}

			if(fun_table.lpfnMBeginJob( &ptParam ) != 0)
			{
				g_jobdata.page_temp.error = TRUE;
				break;
			}
				
		}
#endif
	}

#ifdef _SPLIT_SIZE_
    if (g_jobdata.page_temp.trimbuf)
		remove(g_jobdata.page_temp.trimbuf);
	if(fpPagefile != 0)
		fclose(fpPagefile);
	remove(_SPLIT_PAGE_DATA_);
	remove(_TEMP_FILE_HEADER_);
#endif
	return sRet ;
}

/*-------------------------------------------------------------------------------------
*Name 		: EndPageData
*Description 	: End a page printing
*Parameters 	: N/A
Precondition	: ppd != NULL , header != NULL
*Operation 	: Send commands to end a page.
*Postcondition 	: A page is printed
*Return 	:
*		0 	: Succeeded ; otherwise , Failed.
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/					 
short	EndPageData( short sLastPage )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	short		sRet = 0 ;

#if defined(HAVE_SIGACTION) && !defined(HAVE_SIGSET)
	struct sigaction action;	/* Actions for POSIX signals */
#endif /* HAVE_SIGACTION && !HAVE_SIGSET */

/*
*Send remained data to the printer
*/
	/* After the page is finished , 
	 * left data in send_buf should be flushed 
	 * before the page is fed 
	 */
	sRet = FlushBuf() ;		/* Flush left data in send_buf to the printer  --  Chenxujin , 2005.06.09 */


/*
*Send commands to end data and feed the page
*/
	sRet = fun_table.lpfnMEndPage( sLastPage ) ;

	
//	fwrite(kQLCmdPrint,sizeof(kQLCmdPrint),1,stdout) ;

	if( sRet ){
		return sRet ;
	}
#ifndef _LINUX_STD_
	fflush(stdout) ;
#endif	

	/*
	* Unregister the signal handler...
	*/
	
#ifdef HAVE_SIGSET /* Use System V signals over POSIX to avoid bugs */
	sigset(SIGTERM, SIG_IGN);
#elif defined(HAVE_SIGACTION)
	memset(&action, 0, sizeof(action));
	
	sigemptyset(&action.sa_mask);
	action.sa_handler = SIG_IGN;
	sigaction(SIGTERM, &action, NULL);
#else
	signal(SIGTERM, SIG_IGN);
#endif /* HAVE_SIGSET */

/*
*free memory for page
*/
//	DestroyCompressBuf() ;					/* Free the compression buffer */
#ifndef SEND_BAND
//	DestroyLineBuf() ;						/* Free the line buffer */
#endif
	return 0 ;
}


/*-------------------------------------------------------------------------------------
*Name 		: CancelJob
*Description 	: Cancel job callback function
*Parameters : 
*		sig	: signal.
Precondition	: N/A
*Operation 	: Cancel the current job.
*Postcondition 	: Current job is terminated and the process exits.
*Return 		: N/A
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/					 
void	CancelJob( int sig )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	int i ;
#if defined(HAVE_SIGACTION) && !defined(HAVE_SIGSET)
	struct sigaction action;	/* Actions for POSIX signals */
#endif /* HAVE_SIGACTION && !HAVE_SIGSET */

	for(i=0; i< 600; i++){
		putchar(0);
	}

#ifdef HAVE_SIGSET /* Use System V signals over POSIX to avoid bugs */
	sigset(SIGTERM, SIG_IGN);
#elif defined(HAVE_SIGACTION)
	memset(&action, 0, sizeof(action));
	
	sigemptyset(&action.sa_mask);
	action.sa_handler = SIG_IGN;
	sigaction(SIGTERM, &action, NULL);
#else
	signal(SIGTERM, SIG_IGN);
#endif /* HAVE_SIGSET */

//	DestroyCompressBuf() ;					/* Free the compression buffer */
#ifndef SEND_BAND
//	DestroyLineBuf() ;						/* Free the line buffer */
#endif

//	fun_table.lpfnMEndJob() ;
#ifndef _LINUX_STD_
	// removed fflush
	fflush( stdout ) ;
#endif	
/*
*free memory for page
*/
	DestroySendBuf() ;

#ifdef _LINUX_STD_
/*
	fprintf(stderr, "ERROR: cancel this job\n")
	for(i = 0; i < g_jobdata.page_temp.iPageCount; i++)
	{
		sprintf(g_jobdata.page_temp.lpbuf, _TEMP_FILE_, i);
		remove(g_jobdata.page_temp.lpbuf);
	}
	remove(_TEMP_INIT_FILE_);
  */
#endif	
	
	exit( 0 ) ;
}

#ifndef _LPR_
void setSParam(	ppd_file_t * ppd , cups_page_header_t * header , LPPTPARAM sParam )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	char *	pstrShortNickName = NULL ;
	const char *	pstrVal = NULL ;
	int		len , n ;
	char *	pURI = NULL ;

	/* Get Ptouch Name */
	memset( &(sParam->PTName[0]) , 0 , sizeof( sParam->PTName ) ) ;
	pstrShortNickName = ppd->shortnickname ;
	
	if( NULL != pstrShortNickName ){
		pstrShortNickName = strchr( pstrShortNickName , ' ' ) ;
		
		if( NULL != pstrShortNickName ){
			pstrShortNickName++ ;
			
			len = strlen( pstrShortNickName ) ;
			
			if( len < 0 )	len = 0 ;
			if( len > ( sizeof( sParam->PTName ) - 1 ) ){
				len = sizeof( sParam->PTName ) - 1 ;
			}
			
			strncpy( sParam->PTName , pstrShortNickName , len ) ;
		}
	
	}
	
	sParam->model = 1 ;
	sParam->compress = 0 ;	//default , no compression
	if( CheckModel(USE_SERIAL_PREC) ){
		pURI = getenv( "DEVICE_URI" ) ;
		if( NULL != pURI ){
			if( strstr(pURI , "serial:/") ){
				sParam->compress = 1 ;
			}
		}
	}
#ifdef _MY_DEBUG_
	fprintf( stderr , "ERROR: Device URI = %s\n" , pURI ) ;
#endif	
	fprintf(stderr , "DEBUG: Device URI = %s\n" , pURI ) ;
		
	/* Get Tape */
	
	/* Get the paper name set in PPD files */
/*
 * The paper set in PPD file may be the paper 
 */
	pstrVal = GetOption( kMedia ) ;
	if( NULL == pstrVal ){
		pstrVal = GetOption( kPageSize ) ;
	}
#ifdef _MY_DEBUG_	
	fprintf( stderr , "ERROR: PageSize = %s\n" , pstrVal ) ;
#endif	
	sParam->pTape = checkSetTape( pstrVal , header->cupsWidth , header->cupsHeight ) ;
	
	/* Get Orientation */

	sParam->orientation = 1 ;
	pstrVal = GetOption( kOrientation ) ;
	fprintf( stderr , "%s%s = %s\n" , "DEBUG: " , kOrientation , pstrVal ) ;
	if( pstrVal ){
		sParam->orientation = atoi( pstrVal ) ;
	}
	
	/* Get Set Length */
	pstrVal = GetOption( kTapeLength ) ;
	if( pstrVal ){
		sParam->sTapeLength = ( short )( atoi(pstrVal)) ;
	}else{
		sParam->sTapeLength = kCTapeMaxLength ;
	}
	
	/* Get Tape Margin */
	pstrVal = GetOption( kMargin ) ;
	if( pstrVal ){
		sParam->sTapeMargin = ( short )(MM2DOT( atof(pstrVal) )) ;
	}else{
		sParam->sTapeMargin = kCTapeMinMargin ;
	}
	
	/* Adjust length and margins for continuous tapes */
	if( sParam->pTape->ubTapeType == CONTINUOUS_TAPE ){
		if( sParam->sTapeLength < kCTapeMinLength ){
			sParam->sTapeLength = kCTapeMinLength ;
		}
		
		if( sParam->sTapeLength > kCTapeMaxLength ){
			sParam->sTapeLength = kCTapeMaxLength ;
		}

		if( sParam->sTapeMargin < kCTapeMinMargin ){
			sParam->sTapeMargin = kCTapeMinMargin ;
		}
		
		if( sParam->sTapeMargin > kCTapeMaxMargin ){
			sParam->sTapeMargin = kCTapeMaxMargin ;
		}
	}else{
		sParam->sTapeLength = 0 ;
		sParam->sTapeMargin = 0 ;
	}

	/* Auto Tape Cut */
/*	pstrVal = GetOption( kAutoTapeCut ) ;
	sParam->sAutoCut = 1 ;	// Defautl , On 
	if( pstrVal && (strcmp(pstrVal , kOff ) == 0) ){
		sParam->sAutoCut = 0 ;
	} */


 /* Satyam added Cut At End for QL570 */
        pstrVal = GetOption( kCutAtEnd ) ;
        sParam->sCutAtEnd = 1 ;  // Defautl , On
        if( pstrVal && (strcmp(pstrVal , kOff ) == 0) ){
                sParam->sCutAtEnd = 0 ;
        }

 // Satyam added Cut Label for QL570 
        pstrVal = GetOption( CutLabel) ;
        sParam->CutLabel = 1 ;  // Defautl , ON
        if( pstrVal && (strcmp(pstrVal , kOff ) == 0) ){
                sParam->CutLabel = 0 ;
        }
//sParam->CutLabel)

	/* Mirror Printing */
	pstrVal = GetOption( kMirrorPrinting ) ;
	sParam->sMirrorPrinting = 0 ;	/* Defautl , Off */
	if( pstrVal && (strcmp(pstrVal , kOn ) == 0) ){
		sParam->sMirrorPrinting = 1 ;
	}

	/* Print Priority */
	pstrVal = GetOption( kPriority ) ;
	sParam->sPriority = 0 ;	/* Defautl , Give priority to print speed */
	if( pstrVal && (strcmp(pstrVal , kPriority_Quality ) == 0) ){
		sParam->sPriority = 1 ;
	}

	/* Halftone pattern */
	pstrVal = GetOption( kHalftonePattern ) ;
	sParam->sHalftonePattern = HALFTONE_ERRORDIFFUSION ;	/* Defautl , Error Diffusion */
	if( pstrVal ){
		if( (strcmp(pstrVal , kHalftonePattern_Binary ) == 0) ){
			sParam->sHalftonePattern = HALFTONE_BINARY ;
		}else if( (strcmp(pstrVal , kHalftonePattern_Dither ) == 0) ){
			sParam->sHalftonePattern = HALFTONE_DITHER ;
		}else if( (strcmp(pstrVal , kHalftonePattern_ErrorDiffusion ) == 0) ){
			sParam->sHalftonePattern = HALFTONE_ERRORDIFFUSION ;
		}
	}

	/* Brightness */
	pstrVal = GetOption( kBrightness ) ;
	sParam->sBrightness = 0 ;	/* Defautl , 0 */
	if( pstrVal ){
		sParam->sBrightness = atoi( pstrVal ) ;
	}
	
	if( sParam->sBrightness < kMinBrightnessAdj ){
		sParam->sBrightness = kMinBrightnessAdj ;
	}

	if( sParam->sBrightness > kMaxBrightnessAdj ){
		sParam->sBrightness = kMaxBrightnessAdj ;
	}
	sParam->sBrightness = -sParam->sBrightness ;

	/* Contrast */
	pstrVal = GetOption( kContrast ) ;
	sParam->sContrast = 0 ;	/* Defautl , 0 */
	if( pstrVal ){
		sParam->sContrast = atoi( pstrVal ) ;
	}
	
	if( sParam->sContrast < kMinContrastAdj ){
		sParam->sContrast = kMinContrastAdj ;
	}

	if( sParam->sContrast > kMaxContrastAdj ){
		sParam->sContrast = kMaxContrastAdj ;
	}
	
	/* Init color effect */
	setEffect( EFFECT_BRIGHTNESS , sParam->sBrightness ) ;
	setEffect( EFFECT_RED , 0 ) ;
	setEffect( EFFECT_GREEN , 0 ) ;
	setEffect( EFFECT_BLUE , 0 ) ;
	setEffect( EFFECT_CONTRAST , sParam->sContrast ) ;
	setEffect( EFFECT_WEIGHT_RED , 77 ) ;
	setEffect( EFFECT_WEIGHT_GREEN , 150 ) ;
	setEffect( EFFECT_WEIGHT_BLUE , 28 ) ;

	
	/* Set data member */
	/* For the raster data */
	sParam->sSourceWidth	= header->cupsWidth ;
	sParam->sSourceHeight	= header->cupsHeight ;

	n = sParam->sSourceHeight / kBandSize ;
	len = sParam->sSourceHeight - kBandSize*n;
	if (len){   // the number of band
		sParam->bandTotal  = n + 1;
		sParam->lastBandH  = (short)len;
	}else{
		sParam->bandTotal  = n;
		sParam->lastBandH  = sParam->bandHeight;
	}

	sParam->iPage		= 0 ;
	sParam->bandNum		= 0 ;
	sParam->bandline	= 0 ;
	sParam->bandHeight	= 0 ;
	sParam->pBandData	= NULL ;
	sParam->sSourceWidthBytes = 0 ;

	sParam->sDestWidth = header->cupsWidth ;
#ifdef _MY_DEBUG_	
	fprintf(stderr, "ERROR: sParam->cupsWidth = %d, sParam->pTape->usPrintAreaWidth = %d\n",
		header->cupsWidth, sParam->pTape->usPrintAreaWidth);
#endif		
	if( header->cupsWidth > sParam->pTape->usPrintAreaWidth ){
		sParam->sDestWidth = sParam->pTape->usPrintAreaWidth ;
	}

	sParam->sDestHeight = header->cupsHeight ;
	fprintf(stderr, "ERROR: sParam->cupsHeight = %d, sParam->pTape->usPrintAreaHeight = %d\n",
		header->cupsHeight, sParam->pTape->usPrintAreaHeight);//added by MSat
#ifdef _MY_DEBUG_	
	fprintf(stderr, "ERROR: sParam->cupsHeight = %d, sParam->pTape->usPrintAreaHeight = %d\n",
		header->cupsHeight, sParam->pTape->usPrintAreaHeight);
#endif		
	if( sParam->pTape->ubTapeType == CONTINUOUS_TAPE ){
		if( header->cupsHeight > (int)sParam->sTapeLength ){
			sParam->sDestHeight = sParam->sTapeLength ;
		}
	}else{
		if( header->cupsHeight > sParam->pTape->usPrintAreaHeight ){
			sParam->sDestHeight = sParam->pTape->usPrintAreaHeight ;
		}
	}

	return ;
}
#endif

#ifdef _PTOUCH_
/*-------------------------------------------------------------------------------------
*Name           : InterpretParameters                      ReadPpmFileHeader
*Description    :
*Parameters     :
*          argc :
*          argv :
*      pInParam : LPR
*Precondition	: []: <Inputfile> [-pi PaperinfoFile] [-rc ResourceFile]
*Return         :
*             0 : 5
*--------------------------------------------------------------------------------------*/
int
InterpretParameters( int argc, char *argv[], BR_LPR_INPUT_PARAMS *pInParam )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	int		nResult = 0;
	int		nCnt;
	int		fOpened = 0;

	pInParam->pFileInput = stdin;
	pInParam->pszNamePaperinf = NULL;
	pInParam->pszNameResource = NULL;
	pInParam->nSerial = 0;

	pInParam->pFileOutput = NULL;


#ifdef _STDBJ_LINUX_
    pInParam->pszNamePrinter = NULL;
#endif

	for( nCnt = 1; nCnt < argc; nCnt++ ){
#ifdef _STDBJ_LINUX_		// Added by liubin 2005.7.27
//		fprintf(stderr, "ERROR: argv[%d]- %s\n", nCnt, argv[nCnt]);
			// 2006.3.23	Liu Bin for serial
		if( strcmp(argv[nCnt], BR_PRT_CMD_PRINTERNAME) == 0 ){
			nCnt++;
			pInParam->pszNamePrinter = argv[nCnt];
		}
		else if( strcmp(argv[nCnt], BR_PRT_CMD_PORT) == 0 ){
			nCnt++;
//			fprintf(stderr, "ERROR: argv[%d]- %s\n", nCnt, argv[nCnt]);
			if( strcmp(argv[nCnt], "SERIAL") == 0)
				pInParam->nSerial = 1;
			else
				pInParam->nSerial = 0;
		}
		else if( strcmp(argv[nCnt], BR_PRT_CMD_PAPERINFO) == 0 ){
#else
		if( strcmp(argv[nCnt], BR_PRT_CMD_PAPERINFO) == 0 ){
#endif
			nCnt++;
			pInParam->pszNamePaperinf = argv[nCnt];
		}
		else if( strcmp(argv[nCnt], BR_PRT_CMD_RESOURCE) == 0 ){
			nCnt++;
			pInParam->pszNameResource = argv[nCnt];
		}
/*	set output file		*/
		else if ( strcmp(argv[nCnt], BR_PRT_CMD_OUTPUT ) == 0){
			nCnt++;
			if( strcmp(argv[nCnt], "cat") == 0)
			{
				pInParam->pFileOutput == NULL;
			}
			else
			{
				pInParam->pFileOutput = fopen( argv[nCnt], "wb" );
				if( pInParam->pFileOutput == NULL ){
					return BrError( BR_ERROR_FILEOPEN, argv[nCnt] );
				}
			}
		}
		else{
			if( fOpened == 0 ){
				fOpened = 1;
				pInParam->pFileInput = fopen( argv[nCnt], "rb" );
				if( pInParam->pFileInput == NULL ){
					return BrError( BR_ERROR_FILEOPEN, argv[nCnt] );
				}
			}
			else{
				return BrError( BR_ERROR_OPTION, argv[nCnt] );
			}
		}
	}

	if( pInParam->pszNameResource == NULL || pInParam->pszNamePaperinf == NULL ){
		nResult = BrError( BR_ERROR_OPTION, NULL );
	}
	return nResult;
}


/*-------------------------------------------------------------------------------------
*Name           : PrintMainLPRng
*Description    :
*Parameters     :
*      pInParam : LPR
*Return         :
*             0 : 5
*--------------------------------------------------------------------------------------*/
int
PrintMainLPRng( BR_LPR_INPUT_PARAMS *pInParam )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	send_buffer		send_buf;
//	PRTJOB_PARAM	pjParam;
//	PTPARAM		sParam;
	pt_model		model;
	short			sRet;
	int				nRet;
#ifndef LPR_COPIES
	int				nCnt;
#endif/* LPR_COPIES */
	int				nResult = 0;
	int				fPageLoop;
	int				nPageSize;
	unsigned char	*pBandBuf;

	nRet = PrepareLPRngPrint( &ptParam, pInParam );
	if( nRet != 0 ){
		return nRet;
	}


	nRet = SendRasterDoc( pInParam );
	fprintf(stderr, "***** DEBUG TEST ****\n");


#if 0
	/* SENDPARAM*/
	sRet = PrepareSendParam( &sParam );
	if( sRet != 0 ){
		FreeAllMemory();
		return sRet;
	}
#endif

#ifndef _PTOUCH_
#ifdef _STDBJ_LINUX_
	LoadInitPJL(pInParam,  &sParam );
#endif
#endif

	SetFunctionTable( model );
#ifndef _PTOUCH_
	/* SENDPARAM(LPRng) */
	SetSendParam( &sParam, &pjParam, 1 );
#endif

#if 0  /* SENDPARAM */
Debug_printf( "-----------------------------------------\n" );
Debug_printf( "SENDPARAM.mode             = %d\n", sParam.mode );
Debug_printf( "SENDPARAM.paperWidth       = %d\n", sParam.paperWidth );
Debug_printf( "SENDPARAM.paperHeight      = %d\n", sParam.paperHeight );
Debug_printf( "SENDPARAM.pagewidth        = %d\n", sParam.pagewidth );
Debug_printf( "SENDPARAM.bandTotal        = %d\n", sParam.bandTotal );
Debug_printf( "SENDPARAM.lastBandH        = %d\n", sParam.lastBandH );
Debug_printf( "SENDPARAM.bandHeight       = %d\n", sParam.bandHeight );
Debug_printf( "SENDPARAM.bandNum          = %d\n", sParam.bandNum );
Debug_printf( "SENDPARAM.graySLen         = %d\n", sParam.graySLen );
Debug_printf( "SENDPARAM.margin           = %d\n", sParam.margin );
Debug_printf( "SENDPARAM.offset           = %d\n", sParam.offset );
Debug_printf( "SENDPARAM.tempOrApple      = %d\n", sParam.tempOrApple );
Debug_printf( "SENDPARAM.tray             = %d\n", sParam.tray );
Debug_printf( "SENDPARAM.colorOrMono      = %d\n", sParam.colorOrMono );
Debug_printf( "SENDPARAM.grayBitWidth     = %d\n", sParam.grayBitWidth );
Debug_printf( "SENDPARAM.graySAddress     = 0x%08x\n", sParam.graySAddress );
Debug_printf( "SENDPARAM.grayHandle       = 0x%08x\n", sParam.grayHandle );
Debug_printf( "SENDPARAM.grayHandle2      = 0x%08x\n", sParam.grayHandle2 );
Debug_printf( "SENDPARAM.real_ColorOrMono = %d\n", sParam.real_ColorOrMono );
Debug_printf( "SENDPARAM.feed             = %d\n", sParam.feed );
Debug_printf( "SENDPARAM.pPrint->prTop           = %d\n", sParam.pPrint->prTop );
Debug_printf( "SENDPARAM.pPrint->prLeft          = %d\n", sParam.pPrint->prLeft );
Debug_printf( "SENDPARAM.pPrint->prStl           = %d\n", sParam.pPrint->prStl );
Debug_printf( "SENDPARAM.pPrint->prInfo.iVRes    = %d\n", sParam.pPrint->prInfo.iVRes );
Debug_printf( "SENDPARAM.pPrint->prInfo.iHRes    = %d\n", sParam.pPrint->prInfo.iVRes );
Debug_printf( "SENDPARAM.pPrint->prInfo.pgRight  = %d\n", sParam.pPrint->prInfo.pgRight );
Debug_printf( "SENDPARAM.pPrint->prInfo.ppBottom = %d\n", sParam.pPrint->prInfo.ppBottom );
Debug_printf( "SENDPARAM.pPrint->printX[0]       = 0x%04x\n", sParam.pPrint->printX[0] );
Debug_printf( "SENDPARAM.pPrint->printX[1]       = 0x%04x\n", sParam.pPrint->printX[1] );
Debug_printf( "SENDPARAM.pPrint->printX[2]       = 0x%04x\n", sParam.pPrint->printX[2] );
Debug_printf( "SENDPARAM.pPrint->printX[3]       = 0x%04x\n", sParam.pPrint->printX[3] );
Debug_printf( "SENDPARAM.pPrint->printX[4]       = 0x%04x\n", sParam.pPrint->printX[4] );
Debug_printf( "SENDPARAM.pPrint->printX[5]       = 0x%04x\n", sParam.pPrint->printX[5] );
Debug_printf( "SENDPARAM.pPrint->printX[6]       = 0x%04x\n", sParam.pPrint->printX[6] );
Debug_printf( "SENDPARAM.pPrint->printX[7]       = 0x%04x\n", sParam.pPrint->printX[7] );
Debug_printf( "SENDPARAM.pPrint->printX[8]       = 0x%04x\n", sParam.pPrint->printX[8] );
Debug_printf( "SENDPARAM.pPrint->printX[9]       = 0x%04x\n", sParam.pPrint->printX[9] );
Debug_printf( "SENDPARAM.pPrint->printX[10]      = 0x%04x\n", sParam.pPrint->printX[10] );
Debug_printf( "SENDPARAM.pPrint->printX[11]      = 0x%04x\n", sParam.pPrint->printX[11] );
Debug_printf( "SENDPARAM.pPrint->printX[12]      = 0x%04x\n", sParam.pPrint->printX[12] );
Debug_printf( "SENDPARAM.pPrint->printX[13]      = 0x%04x\n", sParam.pPrint->printX[13] );
Debug_printf( "SENDPARAM.pPrint->printX[14]      = 0x%04x\n", sParam.pPrint->printX[14] );
Debug_printf( "SENDPARAM.pPrint->printX[15]      = 0x%04x\n", sParam.pPrint->printX[15] );
Debug_printf( "SENDPARAM.pPrint->printX[16]      = 0x%04x\n", sParam.pPrint->printX[16] );
Debug_printf( "SENDPARAM.pPrint->printX[17]      = 0x%04x\n", sParam.pPrint->printX[17] );
Debug_printf( "SENDPARAM.pPrint->printX[18]      = 0x%04x\n", sParam.pPrint->printX[18] );
Debug_printf( "-----------------------------------------\n" );
#endif
#if 0
#ifdef LPR_PRINTING_SPEED_UP
	nPageSize = inputBytesPerLine * ( pjParam.pageHeight + marginTop + marginBottom );
#else
	nPageSize = pjParam.bytePerLine * pjParam.pageHeight;
#endif

	sRet = InitJob( model, &send_buf, &sParam );
	if( sRet != 0 ){
		FreeAllMemory();
		return BrError( BR_ERROR_PRTFAIL, NULL );
	}

	pBandBuf = CreateBandBuf( pjParam.bytePerLine, kBandSize );
	if( pBandBuf == NULL ){
		return BrError( BR_ERROR_MEMORY, NULL );
	}
	EntryMemoryCtrl( pBandBuf );

  DEBUGPRINT( "pjParam.copies = %d\n", pjParam.copies) ;
	fPageLoop = 1;
	while( fPageLoop ){
		/*--------------------*/
    nResult = ReadPpmFileHeader( pInParam->pFileInput );
		switch( nResult ){
		case -1:
			nResult = BrError( BR_ERROR_PRTFAIL, NULL );
			break;
		case 0 :
			break;
		case 1 :
			/* Î» */
			nResult = 0;
			fPageLoop = 0;
			break;
		}
		/*--------------------*/
#ifndef LPR_COPIES
		for( nCnt = 0; nCnt < pjParam.copies; nCnt++ ){
			if( nCnt != 0 ){
				fseek( pInParam->pFileInput, -nPageSize, SEEK_CUR );
			}
#endif/* LPR_COPIES */
			/*-------------*/
			/* 1Ú¡ */
			/*-------------*/
			sRet = PrintPageData( pInParam->pFileInput, &sParam, &pjParam, &send_buf, pBandBuf );
			switch( sRet ){
			case -1 :
				nResult = BrError( BR_ERROR_PRTFAIL, NULL );
				break;
			case 0 :
				break;
			case 1 :
				nResult = 0;
				fPageLoop = 0;
				break;
			}
#ifndef LPR_COPIES
		}
#endif/* LPR_COPIES */

		if( nResult != 0 ){
			fPageLoop = 0;
			break;
		}
	}

	FreeCtrlMemory( pBandBuf );

	sRet = EndPrintJob();
	if( sRet != 0 ){
		nResult = BrError( BR_ERROR_PRTFAIL, NULL );
	}

	sRet = ExitJob( &send_buf );
	if( sRet != 0 ){
		nResult = BrError( BR_ERROR_PRTFAIL, NULL );
	}

	ResetFunctionTable();

	nRet = EndLPRngPrint( pInParam );
	if( sRet != 0 ){
		nResult = BrError( BR_ERROR_PRTFAIL, NULL );
	}
	FreeAllMemory();
#endif
	return nResult;
}


/*-------------------------------------------------------------------------------------
*Name           : PrepareLPRngPrint
*Description    :
*Parameters     :
*       pjParam :
*      pInParam : LPR
*Return         :
*             0 : 5
*--------------------------------------------------------------------------------------*/
int
PrepareLPRngPrint( LPPTPARAM	psParam, BR_LPR_INPUT_PARAMS *pInParam )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	int		nRet;

	nRet = LoadRcFile( pInParam->pszNameResource, &g_rcInfo);
	pInParam->nCopies = g_rcInfo.aParams[BR_PARAM_ID_COPIES].nValue;
       // 2006.02.23 added by Liu Bin
	pInParam->nCollate = g_rcInfo.aParams[BR_PARAM_ID_QL_Collate].nIndex;
	// 2006.02.23 end
	if( nRet == 0 ){
		nRet = ConvertRc2Pjp( psParam, &g_rcInfo, pInParam );
	}

	return nRet;
}


/*-------------------------------------------------------------------------------------
*Name           : ConvertRc2Pjp
*Description    :
*Parameters     :
*       pjParam :
*       pRcInfo :
*      pInParam : LPR
*Return         :
*             0 : 5
*--------------------------------------------------------------------------------------*/
int
ConvertRc2Pjp( LPPTPARAM	psParam, BR_RESOURCE_INFO *pRcInfo, BR_LPR_INPUT_PARAMS *pInParam )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	int		nResult;
	char	szValue[A_VALUE_BUF] ;
	long n;
	long len;


	strcpy( psParam->PTName, pRcInfo->szPrinterName );

	nResult = GetPaperInf( pInParam->pszNamePaperinf, psParam, pRcInfo );
//        Debug_printf("*****************  tset ************ %d \n",nResult);
	if( nResult != 0 ){
		return nResult;
	}
	

	psParam->model = 1 ;

	if( pInParam->nSerial == 0 )
		psParam->compress = 0 ;	//default , no compression
	else
		psParam->compress = 1 ;	//TIFF compression

	if( CheckModel(USE_SERIAL_PREC) ){
		char *pURI = getenv( "DEVICE_URI" ) ;
		if( NULL != pURI ){
			if( strstr(pURI , "serial:/") ){
				psParam->compress = 1 ;
			}
		}
	}


/*
 * The paper set in PPD file may be the paper
 */


	/* Get Orientation */
	psParam->orientation = 1;
#if 0
	pstrVal = GetOption( kOrientation ) ;
	fprintf( stderr , "%s%s = %s\n" , "DEBUG: " , kOrientation , pstrVal ) ;
	if( pstrVal ){
		sParam->orientation = atoi( pstrVal ) ;
	}
#endif

	/* Get Set Length */
	psParam->sTapeLength = psParam->sSourceHeight;

	// Get Tape Margin
	psParam->sTapeMargin = ( short )(MM2DOT( pRcInfo->aParams[BR_PARAM_ID_QL_Feed].nValue) );
//    Debug_printf("sTapeMargin = %d \n",psParam->sTapeMargin);

	/* Adjust length and margins for continuous tapes */

//	Debug_printf("TapeNo = %x \n",psParam->pTape->ubTapeType);
	if( psParam->pTape->ubTapeType == CONTINUOUS_TAPE ){
		if( psParam->sTapeLength < kCTapeMinLength ){
			psParam->sTapeLength = kCTapeMinLength ;
		}

		if( psParam->sTapeLength > kCTapeMaxLength ){
			psParam->sTapeLength = kCTapeMaxLength ;
		}

		if( psParam->sTapeMargin < kCTapeMinMargin ){
			psParam->sTapeMargin = kCTapeMinMargin ;
		}

		if( psParam->sTapeMargin > kCTapeMaxMargin ){
			psParam->sTapeMargin = kCTapeMaxMargin ;
		}
//    Debug_printf("1sTapeMargin = %d \n",psParam->sTapeMargin);
	}else{
		psParam->sTapeLength = 0 ;
		psParam->sTapeMargin = 0 ;
//    Debug_printf("2sTapeMargin = %d \n",psParam->sTapeMargin);
	}


	// Get Brightness
	psParam->sBrightness = pRcInfo->aParams[BR_PARAM_ID_QL_Brightness].nValue;
	if( psParam->sBrightness < kMinBrightnessAdj ){
		psParam->sBrightness = kMinBrightnessAdj ;
	}

	if( psParam->sBrightness > kMaxBrightnessAdj ){
		psParam->sBrightness = kMaxBrightnessAdj ;
	}
	psParam->sBrightness = -psParam->sBrightness ;

       // Get Contrast
	psParam->sContrast = pRcInfo->aParams[BR_PARAM_ID_QL_Contrast].nValue;
	if( psParam->sContrast < kMinContrastAdj ){
		psParam->sContrast = kMinContrastAdj ;
	}

	if( psParam->sContrast > kMaxContrastAdj ){
		psParam->sContrast = kMaxContrastAdj ;
	}

	/* Init color effect */
	setEffect( EFFECT_BRIGHTNESS , psParam->sBrightness ) ;
	setEffect( EFFECT_RED , 0 ) ;
	setEffect( EFFECT_GREEN , 0 ) ;
	setEffect( EFFECT_BLUE , 0 ) ;
	setEffect( EFFECT_CONTRAST , psParam->sContrast ) ;
	setEffect( EFFECT_WEIGHT_RED , 77 ) ;
	setEffect( EFFECT_WEIGHT_GREEN , 150 ) ;
	setEffect( EFFECT_WEIGHT_BLUE , 28 ) ;


	// Get AutoCut
       //psParam->sAutoCut = GetPjpInnerValue( BR_PARAM_ID_QL_AutoCut, pRcInfo );


	// Get Cut At End  -  added for QL570
       psParam->sCutAtEnd = GetPjpInnerValue( BR_PARAM_ID_QL_CutAtEnd, pRcInfo );

	// Trim Tape --  added for QL720NW
	psParam->Trimtape = GetPjpInnerValue( BR_PARAM_ID_QL_Trimtape, pRcInfo );

	// Get MirrorPrinting
	psParam->sMirrorPrinting = GetPjpInnerValue( BR_PARAM_ID_QL_MirrorPrinting, pRcInfo );

	// Get Halftone
	psParam->sPriority = GetPjpInnerValue( BR_PARAM_ID_QL_Quality, pRcInfo );
	psParam->sHalftonePattern = GetPjpInnerValue( BR_PARAM_ID_QL_Halftone, pRcInfo );
	switch(psParam->sHalftonePattern)
	{
	case 1:
		psParam->sHalftonePattern = HALFTONE_BINARY ;	/* Defautl , Error Diffusion */
		break;
	case 2:
		psParam->sHalftonePattern = HALFTONE_DITHER ;	/* Defautl , Error Diffusion */
		break;
	default:
		psParam->sHalftonePattern = HALFTONE_ERRORDIFFUSION;
		break;
	}


	n = psParam->sSourceHeight / kBandSize ;
	len = psParam->sSourceHeight - kBandSize*n;
	if (len){   // the number of band
		psParam->bandTotal  = n + 1;
		psParam->lastBandH  = (short)len;
	}else{
		psParam->bandTotal  = n;
		psParam->lastBandH  = psParam->bandHeight;
	}

	psParam->iPage		= 0 ;
	psParam->bandNum		= 0 ;
	psParam->bandline	= 0 ;
	psParam->bandHeight	= 0 ;
	psParam->pBandData	= NULL ;
	psParam->sSourceWidthBytes = psParam->sSourceWidth;

	psParam->sDestWidth = psParam->sSourceWidth;

	if( psParam->sSourceWidth > psParam->pTape->usPrintAreaWidth ){
		psParam->sDestWidth = psParam->pTape->usPrintAreaWidth ;
	}

	psParam->sDestHeight = psParam->sSourceHeight;
	if( psParam->pTape->ubTapeType == CONTINUOUS_TAPE ){
		if( psParam->sSourceHeight > (int)psParam->sTapeLength ){
			psParam->sDestHeight = psParam->sTapeLength ;
		}
	}else{
		psParam->Trimtape = 0 ;//QL-800 add no CONTINUOUS_TAPE then no Trim
		if( psParam->sSourceHeight > psParam->pTape->usPrintAreaHeight ){
			psParam->sDestHeight = psParam->pTape->usPrintAreaHeight ;
		}
	}


//#ifdef	_QL1050_
	// Satyam added Cut labels for QL570
	psParam->CutLabel = GetPjpInnerValue( BR_PARAM_ID_QL_CutLabel, pRcInfo );

//#S1
	// Satyam added Compress/Start Printing for QL720NW
	psParam->compress = GetPjpInnerValue( BR_PARAM_ID_QL_Compress, pRcInfo );

	return nResult;
}


/*-------------------------------------------------------------------------------------
*Name           : GetPaperInf
*Parameters     :
*   pszFilename :
*       pRcInfo :
*Return         :
*             0 : 5
*--------------------------------------------------------------------------------------*/
int
GetPaperInf( char *pszFilename, LPPTPARAM psParam, BR_RESOURCE_INFO *pRcInfo )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	FILE	*fp;
	int		nResult;
	int		iLen = 0 ;
	BR_PARAM_INFO	*pParam;
	char	szLine[LINE_BUFFER+1];
	char	*pszWid;
	char	*pszHei;
	char	*pszPt;

	char	szMedia[LINE_BUFFER];

	pParam = &(pRcInfo->aParams[BR_PARAM_ID_QL_MediaSize]);

//	Debug_printf("-------------%s-----------%s-------%d \n", pParam->paCmdItemList[pParam->nIndex], pParam->paRcItemList[pParam->nIndex],pParam->nIndex);
#ifdef _CUSTOM_TAPE_
	if( pParam->nIndex == -1 )
	{
		sprintf(szMedia, "%s", pRcInfo->tapeid);
	}
	else
	{
		sprintf(szMedia, "%s/%s", pParam->paCmdItemList[pParam->nIndex], pParam->paRcItemList[pParam->nIndex]);
	}
#else
	sprintf(szMedia, "%s/%s", pParam->paCmdItemList[pParam->nIndex], pParam->paRcItemList[pParam->nIndex]);
#endif
	pszPt  = szMedia;

	iLen = strlen( pszPt ) ;

	if( (fp = fopen( pszFilename, "r" )) == NULL ){
		return BrError( BR_ERROR_FILEOPEN, pszFilename );
	}

	nResult = BR_ERROR_NOTFOUND;

	while( ReadLine( szLine, LINE_BUFFER, fp ) != NULL ){
#ifdef _CUSTOM_TAPE_
		if( strncmp( pszPt, szLine, iLen ) == 0 )
		{
                     if( pParam->nIndex == -1 )
			{
				char lp[10] = {0};
				int iStrLen;
				memcpy(lp, pszPt + 3, 2);	// 3 - "BrL" length
				lp[2] = 0;
				sscanf(lp, "%X", &iStrLen);
				iLen += iStrLen + 1;	// ID length + Name length + '/' (1)
			}

			if(szLine[iLen] == ':' ){/* Exactly the same paper name*/
#else
		if( strncmp( pszPt, szLine, iLen ) == 0 && szLine[iLen] == ':' ){/* Exactly the same paper name*/
#endif
			/* [<tab>Width<tab>Height] */
			pszWid = strchr( szLine, '\t' );
			pszHei = strchr( pszWid+1, '\t' );

			if( pszWid == NULL || pszHei == NULL ){
				nResult = BR_ERROR_PAPERINF;
				break;
			}

			pszWid++;
			(*pszHei++) = '\0';
			psParam->sSourceWidth  = (short)atoi( pszWid );
			psParam->sSourceHeight = (short)atoi( pszHei );
			nResult = 0;
			break;
			}
		}
	}

	fclose(fp);

	if( nResult != 0 ){
		BrError( nResult, pszPt );
	}
#ifdef _CUSTOM_TAPE_
//	Debug_printf("-------------%d-----------%d-------\n", psParam->sSourceWidth , psParam->sSourceHeight);
	if(pParam->nIndex > -1)
	{
		psParam->pTape = checkSetTape( pParam->paCmdItemList[pParam->nIndex], psParam->sSourceWidth , psParam->sSourceHeight ) ;
	}
	else
	{
		psParam->pTape = checkSetTape( pRcInfo->tapeid, psParam->sSourceWidth , psParam->sSourceHeight ) ;
	}
#else
	psParam->pTape = checkSetTape( pParam->paCmdItemList[pParam->nIndex], psParam->sSourceWidth , psParam->sSourceHeight ) ;
#endif
	return nResult;
}


long ReadRasPix(FILE* fp, unsigned char* lp, long pixelcount)
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	long lr = 0;
	char* ptr ;
	long lsize = pixelcount * PIXELBYTE;
	long l;
	int iR = 0;
	unsigned char *lpbuf = malloc(pixelcount * PIXELBYTE);
       if(lpbuf == NULL)
	{
		return -1;
	}

	 ptr = lpbuf;
	while(lsize > 0)
	{
		lr = fread(ptr, 1, lsize, fp);
		if(lr < 0)
		{
			free(lpbuf);
			return -1;
		}
		lsize -= lr;
		ptr += lr;
	}
		
	

       for(l = 0; l < pixelcount; l++)
	{
		if(PIXELBYTE > 1)
		{
			lp[l] = 255 - (double)(lpbuf[PIXELBYTE * l] * 0.11 + (double)lpbuf[PIXELBYTE * l + 1] * 0.59 + (double)lpbuf[PIXELBYTE * l + 2] * 0.3);
//			lp[l] = 255 - RGBTOGRAY(lpbuf[PIXELBYTE * l], lpbuf[PIXELBYTE * l + 1], lpbuf[PIXELBYTE * l + 2]);
		}
		else
		{
			lp[l] = lpbuf[l];
		}

	}

	free(lpbuf);

	return pixelcount;
}

#endif
/********************** MSat added Trim Tape for QL720NW... ************************************************/
/* Function to calcualate the blank lines */
unsigned int checkSameDataByte(unsigned char* srcData, unsigned int dataSize, unsigned int  value)
{
	unsigned int	bytecount = 0;
	int	value32 = 0;
	

	memset(&value32, value, sizeof(int));
	

	while(dataSize > 3){
		if(value32 == *((int*)srcData)){
			bytecount += sizeof(int);
			dataSize -= sizeof(int);
			srcData += sizeof(int);
		}
		else	break;
	}
	
	if(dataSize == 0){
		goto EXIT_err;	
	}
	
	while(value == *srcData && dataSize > 0){
		bytecount += sizeof(char);
		dataSize -= sizeof(char);
		srcData += sizeof(char);
	}
	
EXIT_err:
	return bytecount;
}


// Function to trim the data 	//QL720NW
#if 0
void trimrasterdata(BRLPR_INPUT_PARAMS *pInParam, int iPage)
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);

	//DEBUGMSG( stderr," In function trimrasterdata, file rastertobrother.c", NULL) ;//added by MSat
short 		line = 0;
short 		blkSpaceLines = 0;	
unsigned char   *currentLine = NULL;
unsigned int 	destBytesPerLine = 0;
short           dataLength;

static short Def_SourceHeight = 0, Def_DestHeight = 0;

int  data_page = 0 ,data_bytes = 0;
char * pSource_page;
long n =0 , len = 0;

/* Store the value for all pages */
if (iPage == 1)
{
	Def_SourceHeight = ptParam.sSourceHeight;
	Def_DestHeight = ptParam.sSourceHeight;
}

/* Reinitialize the source and dest height */
ptParam.sSourceHeight = Def_SourceHeight;
ptParam.sDestHeight = Def_DestHeight;


/* Allocate memory for a page */
pSource_page  = malloc( ptParam.sSourceWidth * ptParam.sSourceHeight ) ;

if (pSource_page == NULL)
{
	DEBUGMSG( stderr," Failed to allocate memory ", NULL) ;
}		

	/* Open a temporary file to copy the data */
	fppage = fopen(_TRIM_PAGE_DATA_, "wb");

	/* Unable to open the file */
	if(fppage == NULL)
	{
		/* error condition */
		fprintf(stderr, "ERROR: Could not open the temporary file for  \n");
	}

	/* no of bytes in a page */
	data_page = (ptParam.sSourceWidth *ptParam.sSourceHeight);


	ReadRasPix( pInParam->pFileInput, pSource_page , data_page);

		/* Number of bytes in a line */
		destBytesPerLine = ptParam.sSourceWidthBytes;

		/* pointer to the last line */
		currentLine = (pSource_page + data_page) - ptParam.sSourceWidthBytes;

				
		/* Calculation of the number of blank lines */
		for(line = ptParam.sSourceHeight; line > 150; line--)
		{
		
 			dataLength = checkSameDataByte(currentLine, destBytesPerLine, 0x00); 

			if (dataLength != destBytesPerLine)
			{
				break; 
			}						
			else
			{
 				blkSpaceLines++;
				currentLine -= destBytesPerLine;
			}

		}		

 /*  remove the blank bytes in a page */
data_page = data_page - (ptParam.sSourceWidthBytes * blkSpaceLines);

/* Store the date back in file */		
  if ( fwrite(pSource_page, data_page, 1,fppage) < 1 );
     {	
	DEBUGMSG( stderr,"Error : Writing raster data to temp file failed \n ");
     }	


/*  Reduce all the parameters relaeated to the data */ 
	ptParam.sDestHeight  = ptParam.sDestHeight - blkSpaceLines;
	ptParam.sSourceHeight  = ptParam.sSourceHeight - blkSpaceLines;


	/* change the number of band */
	n = ptParam.sSourceHeight / kBandSize ;


	len = ptParam.sSourceHeight - kBandSize*n;

	if (len){   // the number of band
		ptParam.bandTotal  = n + 1;
		ptParam.lastBandH  = (short)len;
	}else{
		ptParam.bandTotal  = n;
		ptParam.lastBandH  = kBandSize;
//		ptParam.lastBandH  = ptParam.bandHeight;
	}

fclose(fppage);

free(pSource_page);

}
#endif	//0
#if 1
void trimrasterdata(BR_LPR_INPUT_PARAMS *pInParam, int iPage)
{

	short 		line=0,line1 = 0;
	short 		blkSpaceLines=0,blkSpaceLines1 = 0;	
	unsigned char   *currentLine = NULL,*currentLine1 = NULL;
	unsigned int 	destBytesPerLine = 0;
	short           dataLength;
	static short Def_SourceHeight = 0, Def_DestHeight = 0;
	int  data_page = 0 ,data_bytes = 0;
	char * pSource_page;
	long n =0 , len = 0;

	/* Store the value for all pages */
	if (iPage==1)
	{	
		Def_SourceHeight = pInParam->sParam->sSourceHeight;
		Def_DestHeight = pInParam->sParam->sSourceHeight;
	}
	/* Reinitialize the source and dest height */
	pInParam->sParam->sSourceHeight = Def_SourceHeight;
	pInParam->sParam->sDestHeight = Def_DestHeight;
	
	/* Allocate memory for a page */
	pSource_page  = malloc( pInParam->sParam->sSourceWidth * pInParam->sParam->sSourceHeight ) ;

	
	if (pSource_page == NULL)
	{
		DEBUGMSG( stderr," Failed to allocate memory ", NULL) ;
	}		

	/* Open a temporary file to copy the data */
//	fppage = fopen(_TRIM_PAGE_DATA_, "wb");
	sprintf(g_jobdata.page_temp.trimbuf,_TRIM_PAGE_DATA_,getpid() );

	fppage = fopen(g_jobdata.page_temp.trimbuf, "wb");

	/* Unable to open the file */
	if(fppage == NULL)
	{
		/* error condition */
		fprintf(stderr, "ERROR: Could not open the temporary file for  \n");
	}
	
	/* no of bytes in a page */
	data_page = (pInParam->sParam->sSourceWidth *pInParam->sParam->sSourceHeight);
	ReadRasPix( pInParam->pFileInput, pSource_page , data_page);
	
	/* Number of bytes in a line */
	destBytesPerLine = pInParam->sParam->sSourceWidthBytes;

	/* pointer to the last line */
	currentLine = (pSource_page + data_page) - pInParam->sParam->sSourceWidthBytes;
				
	/* Calculation of the number of blank lines */
	for(line = pInParam->sParam->sSourceHeight; line > 150 ; line--)
	{
 		dataLength = checkSameDataByte(currentLine, destBytesPerLine, 0x00); 
		if (dataLength != destBytesPerLine)
		{
			break; 
		}						
		else
		{	
 			blkSpaceLines++;
			currentLine -= destBytesPerLine;
		}
		
	}		

	currentLine1 = (pSource_page );

	/* Calculation of the number of blank lines */
	for(line1 = 0;line1<pInParam->sParam->sSourceHeight - 150 ; line1++)
	{
 		dataLength = checkSameDataByte(currentLine1, destBytesPerLine, 0x00); 
		if (dataLength != destBytesPerLine)
		{
			break; 
		}						
		else
		{	
 			blkSpaceLines1++;
			currentLine1 += destBytesPerLine;
		}
		
	}		

	if (line1 > line)//no data
	{
		 /*  remove the blank bytes in a page */
		data_page = data_page - (pInParam->sParam->sSourceWidthBytes * blkSpaceLines);

		/* Store the date back in file */		
		if ( fwrite(pSource_page, data_page, 1,fppage) < 1 );
		{	
			DEBUGMSG( stderr,"Error : Writing raster data to temp file failed \n ");
		}	
		//memset(&pSource_page,'0',sizeof(pSource_page));
		/*  Reduce all the parameters relaeated to the data */ 
		pInParam->sParam->sDestHeight  = pInParam->sParam->sDestHeight - blkSpaceLines;
		pInParam->sParam->sSourceHeight  = pInParam->sParam->sSourceHeight - blkSpaceLines;

		/* change the number of band */
		n = pInParam->sParam->sSourceHeight / kBandSize ;
		len = pInParam->sParam->sSourceHeight - kBandSize*n;

		if (len)
		{   // the number of band
			pInParam->sParam->bandTotal  = n + 1;
			pInParam->sParam->lastBandH  = (short)len;
		}
		else
		{
			pInParam->sParam->bandTotal  = n;
			pInParam->sParam->lastBandH  = kBandSize;
		}
	}else{

		 /*  remove the blank bytes in a page */
		data_page = data_page - (pInParam->sParam->sSourceWidthBytes * (blkSpaceLines + blkSpaceLines1));

		/* Store the date back in file */		
		if ( fwrite(pSource_page+( blkSpaceLines1*pInParam->sParam->sSourceWidthBytes ), data_page, 1,fppage) < 1 );
		{	
			DEBUGMSG( stderr,"Error : Writing raster data to temp file failed \n ");
		}	
		//memset(&pSource_page,'0',sizeof(pSource_page));
		/*  Reduce all the parameters relaeated to the data */ 
		pInParam->sParam->sDestHeight  = pInParam->sParam->sDestHeight - blkSpaceLines - blkSpaceLines1;
		pInParam->sParam->sSourceHeight  = pInParam->sParam->sSourceHeight - blkSpaceLines - blkSpaceLines1;

		/* change the number of band */
		n = pInParam->sParam->sSourceHeight / kBandSize ;
		len = pInParam->sParam->sSourceHeight - kBandSize*n;

		if (len)
		{   // the number of band
			pInParam->sParam->bandTotal  = n + 1;
			pInParam->sParam->lastBandH  = (short)len;
		}
		else
		{
			pInParam->sParam->bandTotal  = n;
			pInParam->sParam->lastBandH  = kBandSize;
		}
	}
	//memset(pSource_page,0,pInParam->sParam->sSourceWidth *pInParam->sParam->sSourceHeight);
	fclose(fppage);
	free(pSource_page);
}
#endif
/********************** ...MSat added Trim Tape for QL720NW ***************************************/

