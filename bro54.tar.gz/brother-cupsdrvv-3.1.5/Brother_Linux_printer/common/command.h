#ifndef	__COMMAND_H__
#define	__COMMAND_H__

#ifdef _cplusplus
extern "C" {
#endif/*_cplusplus*/

/* 
* Ptouch QL commands 
*/

/*
* Ptouch QL commands
*/

/* Blank command : NULL */
const unsigned char kQLCmdBlank[ 400 ] = { '\x00' } ;	/* MSat Added for QL720NW */

/* Invalid command : NULL */
const unsigned char kQLCmdInvalid[ 1 ] = { '\x00' } ;

/* Print command : FF */
const unsigned char kQLCmdPrint[ 1 ] = { '\x0C' } ;


/* Print command with feeding : Control-Z */
const unsigned char kQLCmdPrintFeeding[ 1 ] = { '\x1A' } ;


/* Initialize : ESC + @ */
const unsigned char kQLCmdInitialize[ 2 ] = { '\x1B' , '\x40' } ;


const unsigned char kQLCmdstatus[ 4 ] = { '\x1B' , '\x69' ,'\x21' , '\x01'} ;

/* Status information request : ESC + i + S */
const unsigned char kQLCmdStatusRequest[ 3 ] = { '\x1B' , '\x69' , '\x53' } ;

/* Set each mode : ESC + i + M + {n} */
/* n bit specifications:
*  0 --|
*  1 --|
*  2 --|--- Not used
*  3 --|
*  4 --|
*  5 -- Not defined
*  6 -- Auto cut(QL-550/650TD only) , 1 : Auto cut ; 0 : No auto cut
*  7 -- Not used
*/
const unsigned char kQLCmdAutocut_On[ 4 ]  = { '\x1B' , '\x69' , '\x4D' , '\x40' } ; //uncommented to test cutlabel
const unsigned char kQLCmdAutocut_Off[ 4 ] = { '\x1B' , '\x69' , '\x4D' , '\x00' } ;

/* Set margin amount (feed amount) : ESC + i + d + {n1} + {n2} */
/* Margin amount(dots) = n1 + 256 * n2 */

unsigned char		kQLCmdSetMargin[ 5 ] = {  '\x1B' , '\x69' , '\x64' , '\x00' , '\x00' } ;

/* Print information command */
/* : ESC + i + z + {n1} + {n2} + {n3} + {n4} + {n5} + {n6} + {n7} + {n8} + {n9} + {n10} */
unsigned char		kQLCmdPrintInfo[ 13 ] = { '\x1B' , '\x69' , '\x7A' , '\x00' , '\x00' ,\
											  '\x00' , '\x00' , '\x00' , '\x00' ,\
											  '\x00' , '\x00' , '\x00' , '\x00' } ;
/*
*{n1}:Valid flag; specifies which values are valid
*/

/*
*{n2}:Paper Type
*/

/*
*{n3}: Paper width;units:mm
*{n4}: Paper length;units:mm
*/

/*
*{n5~n8}: Raster number= {n8}*256*256*256 + {n7}*256*256 + {n6}*256 + {n5}
*/

/*
*Note : If the media is not correctly loaded into the P-touch when the valid flag for PI_KIND,
*		PI_WIDTH and PI_LENGTH are set to "ON",and error status is returned
*		(Bit 0 of "error information 2" is set to "ON" )
*/

/*
*{n9}: Starting Page : 0; Other pages : 1
*/


/*
*{n10}: Fixed to 0
*/

/* Raster graphics transfer
 * g + {s} + {n} + {d1} +...+ {dn}
*/
const unsigned char		kQLCmdRasterHeader[ 3 ] = {  '\x67' , '\x00' , '\x5A' } ;
const unsigned char		kQLCmdRasterStop[ 3 ]   = {  '\x67' , '\xFF' , '\x5A' } ;

//#S1
/* Command mode switch
 * ESC + i + a + {n}
*/
//const unsigned char		kQLCmdSwitchNormal[ 4 ]  = { '\x1B' , '\x69' , '\x61' , '\x00' } ;
//const unsigned char		kQLCmdSwitchDefault[ 4 ] = { '\x1B' , '\x69' , '\x61' , '\x01' } ;
//const unsigned char		kQLCmdSwitchText[ 4 ] 	 = { '\x1B' , '\x69' , '\x61' , '\x02' } ;

/* MSat Added for QL720NW... */
const unsigned char	kQLCmdSwitchNormal[ 4 ]  = { '\x1B' , '\x69' , '\x61' , '\x00' } ;
const unsigned char	kQLCmdSwitchDefault[ 4 ] = { '\x1B' , '\x69' , '\x61' , '\x01' } ;
const unsigned char	kQLCmdSwitchText[ 4 ] 	 = { '\x1B' , '\x69' , '\x61' , '\x02' } ;
const unsigned char	kQLCmdSwitchPTouch[ 4 ]  = { '\x1B' , '\x69' , '\x61' , '\x03' } ;
/* ...MSat Added for QL720NW */

// Satyam commented for QL570
//const unsigned char		kQLCmdSwitchTemplate[ 4 ] = { '\x1B' , '\x69' , '\x61' , '\x03' } ;  // ptouch mode
//const unsigned char		kQLCmdSwitchTemplate[ 4 ] = { '\x1B' , '\x69' , '\x61' , '\x00' } ;  // normal mode
unsigned char		kQLCmdCutLabel[ 4 ] = { '\x1B' , '\x69' , '\x41' , 1 } ;
#define	SetCmdCutLabel( pagecount )	kQLCmdCutLabel[3] = pagecount;
/* Baud rate setting
 * ESC + i + B + {n1} + {n2}
 */
const unsigned char		kQLCmdBaudRate96  [ 5 ]	= { '\x1B' , '\x69' , '\x42' , '\x60' , '\x00' } ;
const unsigned char		kQLCmdBaudRate576 [ 5 ]	= { '\x1B' , '\x69' , '\x42' , '\x40' , '\x02' } ;
const unsigned char		kQLCmdBaudRate1152[ 5 ] = { '\x1B' , '\x69' , '\x42' , '\x80' , '\x04' } ;

/* Compression mode selection
 * M + {n}
 */
const unsigned char		kQLCmdCompression_Non[2]  = { '\x4D' , '\x00' } ;
//#S1
const unsigned char		kQLCmdCompression_TIFF[2]  = { '\x4D' , '\x02' } ;	/* Enabled only with serial interface */
//Satyam added CutAtEnd command for QL570
const unsigned char             kQLCmdCutAtEnd_ON[ 4 ] = { '\x1B' , '\x69' , '\x4B' , '\x08' };
const unsigned char             kQLCmdCutAtEnd_OFF[ 4 ] = { '\x1B' , '\x69' , '\x4B' , '\x00' };


const unsigned char	kQLCmdHighSpeedPrint[ 4 ]  = { '\x1B' , '\x69' , '\x4A' , '\x01' } ;	/* MSat Added for QL720NW */



#define SetCmdMargin( kQLCmdSetMargin , n )	kQLCmdSetMargin[3]= (unsigned char)(n&0xFF);\
											kQLCmdSetMargin[4]= (unsigned char)((n>>8)&0xFF);\

/* Print information command */
/* : ESC + i + z + {n1} + {n2} + {n3} + {n4} + {n5} + {n6} + {n7} + {n8} + {n9} + {n10} */
//extern unsigned char		kQLCmdPrintInfo[ 13 ] ;
#define	ResetCmdPrintInfo( kQLCmdPrintInfo )	memset( &(kQLCmdPrintInfo[3]) , 0 , 10 ) ;\
												kQLCmdPrintInfo[ 4 ] = 0x80 ;
/*
*{n1}:Valid flag; specifies which values are valid
*/
#define	PI_KIND			(0x02)			/* Paper Type */
#define	PI_WIDTH		(0x04)			/* Paper width */
#define	PI_LENGTH		(0x08)			/* Paper length */
#define	PI_QUALITY		(0x40)			/* Give priority to print quality */
#define	PI_RECOVER		(0x80)			/* Always ON */

#define	SetCmdPrintInfoFlag( kQLCmdPrintInfo , flag )	kQLCmdPrintInfo[3] |= flag ;

/*
*{n2}:Paper Type
*/
#define	PT_CONTINUOUS	(0x0A)			/* Continuous length tape */
#define PT_DIE_CUT		(0x0B)			/* Die-cut Labels */

#define	SetCmdPrintInfoPaperType( kQLCmdPrintInfo , type )	kQLCmdPrintInfo[4] = type ;

/*
*{n3}: Paper width;units:mm
*{n4}: Paper length;units:mm
*/
#define	SetCmdPrintInfoPaperWidth( kQLCmdPrintInfo , width )	kQLCmdPrintInfo[5] = width ;
#define	SetCmdPrintInfoPaperLength( kQLCmdPrintInfo , height )	kQLCmdPrintInfo[6] = height ;

/*
*{n5~n8}: Raster number= {n8}*256*256*256 + {n7}*256*256 + {n6}*256 + {n5}
*/
#define	SetCmdPrintInfoRasterNumber( kQLCmdPrintInfo , raster )	\
									kQLCmdPrintInfo[7] = (unsigned char)( raster & 0x0FF ) ;\
									kQLCmdPrintInfo[8] = (unsigned char)( (raster>>8) & 0x0FF ) ;\
									kQLCmdPrintInfo[9] = (unsigned char)( (raster>>16) & 0x0FF ) ;\
									kQLCmdPrintInfo[10] = (unsigned char)( (raster>>24) & 0x0FF ) ;
/*
*Note : If the media is not correctly loaded into the P-touch when the valid flag for PI_KIND,
*		PI_WIDTH and PI_LENGTH are set to "ON",and error status is returned
*		(Bit 0 of "error information 2" is set to "ON" )
*/

/*
*{n9}: Starting Page : 0; Other pages : 1
*/
#define	SetCmdPrintInfoPage( kQLCmdPrintInfo , flag )	kQLCmdPrintInfo[11] = flag ;
/*
*{n10}: Fixed to 0
*/

//Satyam added for QL570
#define	SetCmdPrintInfoPage( kQLCmdPrintInfo , flag )	kQLCmdPrintInfo[11] = flag ;

#ifdef _cplusplus
}
#endif/*_cplusplus*/

#endif/* __COMMAND_H__ */

