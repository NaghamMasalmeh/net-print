#ifndef _MODELS_H_
#define _MODELS_H_

#ifdef _cplusplus
extern "C" {
#endif/* _cplusplus */

//----- 'Check Model Index -----
typedef	enum ModelCheckNumber{
	USE_MODESWITCH_PREC	= 0 ,
	USE_COMPRESSION_PREC	,
	USE_AUTOCUT_PREC		,
	USE_SERIAL_PREC			,
	
	/* Add new check number here */
		
} model_check_num ;

extern	unsigned short	model_index ;		//	index in the supported printer list , base 1
extern	pt_model		model_series ;		//	1 = QL

extern	unsigned short	GetModel( const unsigned char * pstrShortNickName ) ;	//Get model index and language from model name
extern	short	CheckModel( model_check_num checkNumber ) ;						//Check supportion for specific check number

#ifdef _cplusplus
}
#endif/* _cplusplus */

#endif/* _MODELS_H_ */

