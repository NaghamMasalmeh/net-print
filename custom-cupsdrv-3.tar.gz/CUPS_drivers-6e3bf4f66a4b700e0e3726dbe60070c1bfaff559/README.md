# CUSTOM CUPS DRIVERS

In this repository you'll find a collection of open source CUPS drivers developed by Custom S.p.A. for some of its own printers

The list is not exhaustive because not all the drivers have been open sourced

You can find additional information on [Custom4U](https://www.custom4u.it)
