# /bin/sh

PRINTER=$1
CMD=$2

if [ $CMD = -n ]; then
echo "brpapertool -P $PRINTER $CMD Standard\ Address\ Label	 -w 29 -h 42"
brpapertool -P $PRINTER $CMD Standard\ Address\ Label	 -w 29 -h 42

echo "brpapertool -P $PRINTER $CMD Standard\ Address\ Label	 -w 29 -h 90"
brpapertool -P $PRINTER $CMD Standard\ Address\ Label	 -w 29 -h 90

echo "brpapertool -P $PRINTER $CMD Large\ Address\ Label	-w 38 -h 90"
brpapertool -P $PRINTER $CMD Large\ Address\ Label	-w 38 -h 90

echo "brpapertool -P $PRINTER $CMD Small\ Address\ Label	-w 62 -h 29"
brpapertool -P $PRINTER $CMD Small\ Address\ Label	-w 62 -h 29

echo "brpapertool -P $PRINTER $CMD Return\ Address\ Label	-w 17 -h  54"
brpapertool -P $PRINTER $CMD Return\ Address\ Label	-w 17 -h  54

echo "brpapertool -P $PRINTER $CMD Shipping\ Label	-w 62 -h  100"
brpapertool -P $PRINTER $CMD Shipping\ Label	-w 62 -h  100

echo "brpapertool -P $PRINTER $CMD Visitor\ Name\ Badge\ Label	-w 62 -h  100"
brpapertool -P $PRINTER $CMD Visitor\ Name\ Badge\ Label	-w 62 -h  100

echo "brpapertool -P $PRINTER $CMD CD/DVD\ Label	-w 58 -h  58"
brpapertool -P $PRINTER $CMD CD/DVD\ Label	-w 58 -h  58

echo "brpapertool -P $PRINTER $CMD File\ Folder\ Label	-w 17 -h  87"
brpapertool -P $PRINTER $CMD File\ Folder\ Label	-w 17 -h  87

echo "brpapertool -P $PRINTER $CMD Hanging\ File\ Forlder\ Label	-w 17 -h  54"
brpapertool -P $PRINTER $CMD Hanging\ File\ Forlder\ Label	-w 17 -h  54

echo "brpapertool -P $PRINTER $CMD 1/2\\\"\ Round\ Label	-w 12 -h 12"
brpapertool -P $PRINTER $CMD 1/2\"\ Round\ Label	-w 12 -h 12

echo "brpapertool -P $PRINTER $CMD 1\\\"\ Round\ Label -w 24 -h 24"
brpapertool -P $PRINTER $CMD 1\"\ Round\ Label -w 24 -h 24

echo "brpapertool -P $PRINTER $CMD 1/2\\\"\ Square\ Label        -w 23 -h 23"
brpapertool -P $PRINTER $CMD 1/2\"\ Square\ Label        -w 23 -h 23

echo "brpapertool -P $PRINTER $CMD Floppy\ Disk	-w 62 -h  50"
brpapertool -P $PRINTER $CMD Floppy\ Disk	-w 62 -h  50

echo "brpapertool -P $PRINTER $CMD Compact\ Flash\ \(TM\)	-w 12 -h  36"
brpapertool -P $PRINTER $CMD Compact\ Flash\ \(TM\)	-w 12 -h  36

echo "brpapertool -P $PRINTER $CMD Smart\ Media\ \(TM\)	-w 12 -h  26"
brpapertool -P $PRINTER $CMD Smart\ Media\ \(TM\)	-w 12 -h  26

echo "brpapertool -P $PRINTER $CMD Memory\ Stick\ \(TM\)	-w 12 -h  34"
brpapertool -P $PRINTER $CMD Memory\ Stick\ \(TM\)	-w 12 -h  34

echo "brpapertool -P $PRINTER $CMD MO\ -\ Face	-w 62 -h  45"
brpapertool -P $PRINTER $CMD MO\ -\ Face	-w 62 -h  45

echo "brpapertool -P $PRINTER $CMD Binder\ 1-1\/4\\\"\ -Spine	-w 29 -h  209"
brpapertool -P $PRINTER $CMD Binder\ 1-1\/4\"\ -Spine	-w 29 -h  209

echo "brpapertool -P $PRINTER $CMD Binder\ 2\\\"\ -Spine	-w 62 -h  209"
brpapertool -P $PRINTER $CMD Binder\ 2\"\ -Spine	-w 62 -h  209

echo "brpapertool -P $PRINTER $CMD 7\\\"\ Postage\ Label	-w 62 -h  184"
brpapertool -P $PRINTER $CMD 7\"\ Postage\ Label	-w 62 -h  184

echo "brpapertool -P $PRINTER $CMD 8\\\"\ Postage\ Label -w 62 -h  209"
brpapertool -P $PRINTER $CMD 8\"\ Postage\ Label	-w 62 -h  209

#echo "brpapertool -P $PRINTER $CMD 9\\\"\ Postage\ Label -w 50 -h  209"
#brpapertool -P $PRINTER $CMD 9\"\ Postage\ Label        -w 50 -h  209



fi
if [ $CMD = -d ]; then
echo "brpapertool -P $PRINTER $CMD Standard\ Address\ Label"
brpapertool -P $PRINTER $CMD Standard\ Address\ Label

echo "brpapertool -P $PRINTER $CMD Large\ Address\ Label"
brpapertool -P $PRINTER $CMD Large\ Address\ Label

echo "brpapertool -P $PRINTER $CMD Small\ Address\ Label"
brpapertool -P $PRINTER $CMD Small\ Address\ Label

echo "brpapertool -P $PRINTER $CMD Return\ Address\ Label"
brpapertool -P $PRINTER $CMD Return\ Address\ Label

echo "brpapertool -P $PRINTER $CMD Shipping\ Label"
brpapertool -P $PRINTER $CMD Shipping\ Label

echo "brpapertool -P $PRINTER $CMD Visitor\ Name\ Badge\ Label"
brpapertool -P $PRINTER $CMD Visitor\ Name\ Badge\ Label

echo "brpapertool -P $PRINTER $CMD CD/DVD\ Label"
brpapertool -P $PRINTER $CMD CD/DVD\ Label

echo "brpapertool -P $PRINTER $CMD File\ Folder\ Label"
brpapertool -P $PRINTER $CMD File\ Folder\ Label

echo "brpapertool -P $PRINTER $CMD Hanging\ File\ Forlder\ Label"
brpapertool -P $PRINTER $CMD Hanging\ File\ Forlder\ Label

echo "brpapertool -P $PRINTER $CMD 1/2\\\"\ Round\ Label"
brpapertool -P $PRINTER $CMD 1/2\"\ Round\ Label

echo "brpapertool -P $PRINTER $CMD 1\\\"\ Round\ Label"
brpapertool -P $PRINTER $CMD 1\"\ Round\ Label

echo "brpapertool -P $PRINTER $CMD Floppy\ Disk"
brpapertool -P $PRINTER $CMD Floppy\ Disk

echo "brpapertool -P $PRINTER $CMD Compact\ Flash\ \(TM\)"
brpapertool -P $PRINTER $CMD Compact\ Flash\ \(TM\)

echo "brpapertool -P $PRINTER $CMD Smart\ Media\ \(TM\)"
brpapertool -P $PRINTER $CMD Smart\ Media\ \(TM\)

echo "brpapertool -P $PRINTER $CMD Memory\ Stick\ \(TM\)"
brpapertool -P $PRINTER $CMD Memory\ Stick\ \(TM\)

echo "brpapertool -P $PRINTER $CMD MO\ -\ Face"
brpapertool -P $PRINTER $CMD MO\ -\ Face

echo "brpapertool -P $PRINTER $CMD Binder\ 1-1\/4\\\"\ -Spine"
brpapertool -P $PRINTER $CMD Binder\ 1-1\/4\"\ -Spine

echo "brpapertool -P $PRINTER $CMD Binder\ 2\\\"\ -Spine"
brpapertool -P $PRINTER $CMD Binder\ 2\"\ -Spine

echo "brpapertool -P $PRINTER $CMD 7\\\"\ Postage\ Label"
brpapertool -P $PRINTER $CMD 7\"\ Postage\ Label

echo "brpapertool -P $PRINTER $CMD 8\\\"\ Postage\ Label"
brpapertool -P $PRINTER $CMD 8\"\ Postage\ Label
fi

