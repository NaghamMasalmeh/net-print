/*
	string.c
	Created by Liu Bin 2005.12.12
*/


#include "string.h"


//
// fwrite_line_string(char *lpString, size_t length, FILE *stream)
//
size_t fwrite_line_string(const char *lpString, size_t length, FILE *stream)
{
	const char *ptr = lpString;

	int iw = 0, ir = length;
	while(ir > 0)
	{
		iw = fwrite(ptr, 1, ir, stream);
		ir -= iw;
		ptr += iw;
	}

	return length;
}


//
// fread_line_string(char *ptr, FILE *stream)
//
size_t fread_line_string(char *ptr, FILE *stream)
{
	size_t count = 0;
	while(fread(ptr + count, 1, 1, stream) > 0)
	{
		if(*(ptr + count) == '\n')
		{
			count++;
			break;
		}
		count++;
	}
	ptr[count] = 0;
	return count;
}
