/*=================================================================================*
*FileName:     	brcommon.c
*Description:	common functions 
*Revision:     	1.0									
*Date:         	2003.08.28							
*Author:       	Chenxujin , SteadyBJ 									
*Histroy:      	1.Chenxujin , Create
*==================================================================================*/

#include "brcommon.h"
#include <stdlib.h>

void	copyData(unsigned char *src, unsigned char *dst, short len) ;
void	clearData(unsigned char *dst, short len) ;
short	checkZero(unsigned char	*dat, short len) ;
void	invertData(unsigned char *src, unsigned char *dst, short len) ;
void	setCommand(char *com,unsigned char *dat,short count) ;
void	checkOptByte(char *com,short off,short cnt,unsigned short *comC) ;
int	NumericLength( long num ) ;

/*=================================================================================*
*Name:     	copyData
*Description:	copy data from source buffer to destination buffer
*Parameters:
	*unsigned char * src:	source buffer
	*unsigned char * dst: 	destination buffer
	*short len :			length to be copied
*Return:	N/A
*Revision:     	1.0									
*Date:         	2003.08.28							
*Author:       	Chenxujin , SteadyBJ 									
*Histroy:      	1.Chenxujin , Create
*[NOTE]This function is copied from escYL.c
*==================================================================================*/
void copyData(unsigned char *src, unsigned char *dst, short len)
{
	unsigned long *sl,*dl;
	unsigned char *s,*d;
	short	loop;
	
	sl = (unsigned long *)src;
	dl = (unsigned long *)dst;
	
	loop = len >> 2;
	
	while(loop--){	
		*dl++= *sl++;
	}
	
	loop = len & 0x03;
	s	 = (unsigned char *)sl;
	d	 = (unsigned char *)dl;
	
	while(loop--){
		*d++ = *s++;
	}
}

/*=================================================================================*
*Name:     	clearData
*Description:	clear data in buffer
*Parameters:
	*unsigned char * dst: 	buffer to be cleared.
	*short len :			length to clear
*Return:	N/A
*Revision:     	1.0									
*Date:         	2003.08.28							
*Author:       	Chenxujin , SteadyBJ 									
*Histroy:      	1.Chenxujin , Create
*[NOTE]This function is copied from escYL.c
*==================================================================================*/
void clearData(unsigned char *dst, short len)
{
	unsigned long *dl;
	unsigned char *d;
	short	loop;
	
	dl = (unsigned long *)dst;
	
	loop = len >> 2;
	
	while(loop--){	
		*dl++ = 0L;
	}
	
	loop = len & 0x03;
	d	 = (unsigned char *)dl;
	
	while(loop--){
		*d++ = 0;
	}
}

/*=================================================================================*
*Name:     	invertData
*Description:	get invert data from source
*Parameters:
	*unsigned char * src:  source buffer
	*unsigned char * dst: 	buffer for inverted data
	*short len :			length to invert
*Return:	N/A
*Revision:     	1.0									
*Date:         	2003.08.28							
*Author:       	Chenxujin , SteadyBJ 									
*Histroy:      	1.Chenxujin , Create
*[NOTE]This function is copied from escYL.c
*==================================================================================*/
void invertData(unsigned char *src, unsigned char *dst, short len)
{
	unsigned long *sl,*dl;
	unsigned char *s,*d;
	short	loop;
	
	sl = (unsigned long *)src;
	dl = (unsigned long *)dst;
	
	loop = len >> 2;
	
	while(loop--){	
		*dl++ = ~(*sl++);
	}
	
	loop = len & 0x03;
	s	 = (unsigned char *)sl;
	d	 = (unsigned char *)dl;
	
	while(loop--){
		*d++ = ~(*s++);
	}
}

short checkZero(unsigned char	*dat, short len)
{
	short	i;
	short	*dat1;
	
	len = len >> 1;
	dat1 = (short *)dat;
	
	for (i = 0 ; i < len ; i++){
		if (*dat1++ != 0){
			return 0 ;
		}
	}
	return 1 ;
}

void	setCommand(char *com,unsigned char *dat,short count) /***** set data to sending buffer *****/
{
	short	i;
	
	for (i = 0; i < count; i++){
		*(dat++) = com[i];
	}
}

void	checkOptByte(char *com,short off,short cnt,unsigned short *comC)
{
	*comC = 1;
	
	if (com[0] == (char)0x80){		/*----- Run length encode -----*/
		if (off < 3){
			com[0] |= (char)(off << 5);
			
		}else if (off == 3){
			com[0] |= (char)(3 << 5);
			com[(*comC)++] = 0;				/* terminal offset */
			
		}else{
			off -= 3;
			com[0] |= (char)(3 << 5);
			while ((off -= 255) >= 0){
				com[(*comC)++] = 255;			/* add optional offset */
			}
			off += 255;
			com[(*comC)++] = (char)off;		/* terminal offset */
		}
		
		cnt -= 2;
		if (cnt < 31){
			com[0] |= (char)cnt;
			
		}else if (cnt == 31){
			com[0] |= (char)31;
			com[(*comC)++] = 0;				/* terminal count */
			
		}else{
			cnt -= 31;
			com[0] |= (char)31;
			while ((cnt -= 255) >= 0){
				com[(*comC)++] = 255;			/* add optional count */
			}
			cnt += 255;
			com[(*comC)++] = (char)cnt;		/* terminal count */
		}
		
	}else{						/*----- Uncompress -----*/
		if (off < 15){
			com[0] = (char)(off << 3);
			
		}else if (off == 15){
			com[0] = (char)(15 << 3);
			com[(*comC)++] = 0;
			
		}else{
			off -= 15;
			com[0] = (char)(15 << 3);
			while ((off -= 255) >= 0){
				com[(*comC)++] = 255;
			}
			off += 255;
			com[(*comC)++] = (char)off;
		}
		
		cnt -= 1;
		if (cnt < 7){
			com[0] |= (char)cnt;
			
		}else if (cnt == 7){
			com[0] |= (char)7;
			com[(*comC)++] = 0;
			
		}else{
			cnt -= 7;
			com[0] |= (char)7;
			while ((cnt -= 255) >= 0){
				com[(*comC)++] = 255;
			}
			cnt += 255;
			com[(*comC)++] = (char)cnt;
		}
	}
}

int	NumericLength( long num ) 
{
	long temp = 0 ;
	int iLen = 0 ;

	if( num == 0 ){
	return 1 ;
	}
	
	temp = labs( num) ;
	while( temp != 0 ){
		temp /= 10 ;
		iLen++ ;
	}
	
	if( num < 0 ){
		iLen++ ;
	}
	
	return iLen ;
}

