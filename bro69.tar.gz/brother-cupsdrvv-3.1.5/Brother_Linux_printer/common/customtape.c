

#include "customtape.h"


/*
	const char* plabelname	- Tape name
	const char* plabel_id	- ID
	return:
		-1:		Failed to add
		count:	ptapelist->count (Custom tape count );
*/
int add_tape(TTapeList ptapelist, const char* plabelname, const char* plabel_id)
{
	int i;
	TTapeItem pitem;

	// check parameters
	if( strlen(plabelname) > _LABEL_MAX_ || strlen(plabel_id) > _LABEL_MAX_ )
	{
		return -1;
	}

	for( i = 0; i < ptapelist->count; i++)
	{
		if( strcmp(ptapelist->tapelist[i].tape_name, plabelname) == 0 ||
			strcmp(ptapelist->tapelist[i].tape_id, plabel_id) == 0 )
		{
			return ptapelist->count;
		}
	}

	pitem = (TTapeItem)malloc(sizeof(TapeItem) * (ptapelist->count + 1));
	if(pitem == NULL)
	{
		return -1;
	}

	if(ptapelist->count > 0)
	{
		memcpy(pitem, ptapelist->tapelist, ptapelist->count * sizeof(TapeItem));
		free(ptapelist->tapelist);
	}
	ptapelist->tapelist = pitem;
	strncpy(ptapelist->tapelist[ptapelist->count].tape_name,	plabelname,	strlen(plabelname));
	ptapelist->tapelist[ptapelist->count].tape_name[strlen(plabelname)] = 0;
	strncpy(ptapelist->tapelist[ptapelist->count].tape_id, 	plabel_id,		strlen(plabel_id));
	ptapelist->tapelist[ptapelist->count].tape_id[strlen(plabel_id)] = 0;
	ptapelist->count++;

	return ptapelist->count;
}

/*
  	return
		-1	: error
		0	: Not get name and ID
		1	: OK
		
*/
int GetLabel_name_id(const char* lpString, char* lpName, char* lpID)
{
	char *ptr;

	if(strlen(lpString) == 0)
	{
		return -1;
	}

	ptr = strstr(lpString, _LABLE_ID_HEAD_);
	if(ptr != NULL)
	{
		int iStrLen;
		// get lable name length
		char lp[100] = {0};
		memcpy(lp, ptr + strlen(_LABLE_ID_HEAD_), 2);
		lp[2] = 0;
		sscanf(lp, "%X", &iStrLen);

		// get lable name string
		if( *(ptr + 15) != '/')
		{
			return 0;
		}
		memcpy(lp, ptr + 16, iStrLen);
		lp[iStrLen] = 0;
		memcpy(lpName, lp, strlen(lp));
		lpName[strlen(lp)] = 0;

		// get lable name ID
		memcpy(lpID, ptr, 15);
		lpID[15] = 0;
		return 1;
	}

	return 0;
}

