
#include	<cups/cups.h>
#include	<cups/ppd.h>
#include	<cups/raster.h>
#include	<stdlib.h>
#include	<fcntl.h>

#ifdef		RPMBUILD

#include	<dlfcn.h>

typedef	cups_raster_t*	(*cupsRasterOpen_fndef)			(int fd,cups_mode_t mode);
typedef	unsigned		(*cupsRasterReadHeader_fndef)	(cups_raster_t *r,cups_page_header_t *h);
typedef	unsigned		(*cupsRasterReadPixels_fndef)	(cups_raster_t *r,unsigned char *p,unsigned len);
typedef	void			(*cupsRasterClose_fndef)		(cups_raster_t *r);

static	cupsRasterOpen_fndef		cupsRasterOpen_fn;
static	cupsRasterReadHeader_fndef	cupsRasterReadHeader_fn;
static	cupsRasterReadPixels_fndef	cupsRasterReadPixels_fn;
static	cupsRasterClose_fndef		cupsRasterClose_fn;

#define	CUPSRASTEROPEN			(*cupsRasterOpen_fn)
#define	CUPSRASTERREADHEADER	(*cupsRasterReadHeader_fn)
#define	CUPSRASTERREADPIXELS	(*cupsRasterReadPixels_fn)
#define	CUPSRASTERCLOSE			(*cupsRasterClose_fn)

typedef	void(*ppdClose_fndef)						(ppd_file_t*ppd);
typedef	ppd_choice_t*(*ppdFindChoice_fndef)			(ppd_option_t*o,constchar*option);
typedef	ppd_choice_t*(*ppdFindMarkedChoice_fndef)	(ppd_file_t*ppd,constchar*keyword);
typedef	ppd_option_t*(*ppdFindOption_fndef)			(ppd_file_t*ppd,constchar*keyword);
typedef	void(*ppdMarkDefaults_fndef)				(ppd_file_t*ppd);
typedef	ppd_file_t*(*ppdOpenFile_fndef)				(constchar*filename);

typedef	void(*cupsFreeOptions_fndef)	(intnum_options,cups_option_t*options);
typedef	int(*cupsParseOptions_fndef)	(constchar*arg,intnum_options,cups_option_t**options);
typedef	int(*cupsMarkOptions_fndef)		(ppd_file_t*ppd,intnum_options,cups_option_t*options);

static	ppdClose_fndefppdClose_fn;
static	ppdFindChoice_fndefppdFindChoice_fn;
static	ppdFindMarkedChoice_fndefppdFindMarkedChoice_fn;
static	ppdFindOption_fndefppdFindOption_fn;
static	ppdMarkDefaults_fndefppdMarkDefaults_fn;
static	ppdOpenFile_fndefppdOpenFile_fn;

static	cupsFreeOptions_fndefcupsFreeOptions_fn;
static	cupsParseOptions_fndefcupsParseOptions_fn;
static	cupsMarkOptions_fndefcupsMarkOptions_fn;

#define	PPDCLOSE			(*ppdClose_fn)
#define	PPDFINDCHOICE		(*ppdFindChoice_fn)
#define	PPDFINDMARKEDCHOICE	(*ppdFindMarkedChoice_fn)
#define	PPDFINDOPTION		(*ppdFindOption_fn)
#define	PPDMARKDEFAULTS 	(*ppdMarkDefaults_fn)
#define	PPDOPENFILE 		(*ppdOpenFile_fn)

#define	CUPSFREEOPTIONS 	(*cupsFreeOptions_fn)
#define	CUPSPARSEOPTIONS	(*cupsParseOptions_fn)
#define	CUPSMARKOPTIONS 	(*cupsMarkOptions_fn)

#else

#define	CUPSRASTEROPEN			cupsRasterOpen
#define	CUPSRASTERREADHEADER	cupsRasterReadHeader2
#define	CUPSRASTERREADPIXELS	cupsRasterReadPixels
#define	CUPSRASTERCLOSE			cupsRasterClose

#define	PPDCLOSE				ppdClose
#define	PPDFINDCHOICE			ppdFindChoice
#define	PPDFINDMARKEDCHOICE		ppdFindMarkedChoice
#define	PPDFINDOPTION			ppdFindOption
#define	PPDMARKDEFAULTS			ppdMarkDefaults
#define	PPDOPENFILE				ppdOpenFile

#define	CUPSFREEOPTIONS			cupsFreeOptions
#define	CUPSPARSEOPTIONS		cupsParseOptions
#define	CUPSMARKOPTIONS			cupsMarkOptions

#endif

#define	FALSE 0
#define	TRUE  (!FALSE)

#define	MAX_WIDTH	80
#define	STD_WIDTH	72

struct settings_
{
float	pageWidth;
float	pageHeight;

int		cashDrawer;
int		cashDrawerPulseWidth;

int		bytesPerScanLine;
int		bytesPerScanLineStd;
int		cutterMode;
int buzzerOption;
int formfeedType;
int printDensity;
int printSpeed;
};

struct command
{
int		length;
char*	command;
};

static const struct command printerInitializeCommand=
{2,(char[2]){0x1b,'@'}};

const struct command startPageCommand={2,(char[2]){27,'2'}};

const struct command endPageCommand={0,NULL};

const struct command endJobCommand=	{0,NULL};

const struct command PageCutCommand[3]={
{2,(char[]){0x1b,'m'}},		
{2,(char[]){0x1b,'i'}},		
{2,(char[]){0x13,'i'}}		
};
const struct command FormFeedCommand[6]={
{0,NULL},		
{1,(char[]){0x0a}},		
{2,(char[]){0x0a,0x0a}},
{3,(char[]){0x0a,0x0a,0x0a}},
{4,(char[]){0x0a,0x0a,0x0a,0x0a}},
{5,(char[]){0x0a,0x0a,0x0a,0x0a,0x0a}}			
};
const struct command BuzzerCommand[2]={
{4,(char[]){0x1a,'z',0x00,0x00}},		
{4,(char[]){0x1a,'z',0x02,0x19}}		
};
const struct command DensityCommand[7]={
{7,(char[]){0x1d,'(','K',0x02,0x00,0x31,0xfb}},
{7,(char[]){0x1d,'(','K',0x02,0x00,0x31,0xfd}},
{7,(char[]){0x1d,'(','K',0x02,0x00,0x31,0xff}},
{7,(char[]){0x1d,'(','K',0x02,0x00,0x31,0x00}},
{7,(char[]){0x1d,'(','K',0x02,0x00,0x31,0x01}},
{7,(char[]){0x1d,'(','K',0x02,0x00,0x31,0x03}},
{7,(char[]){0x1d,'(','K',0x02,0x00,0x31,0x05}}		
};
const struct command SpeedCommand[14]={
{3,(char[]){0x1a,'s',0x01}},
{3,(char[]){0x1a,'s',0x02}},
{3,(char[]){0x1a,'s',0x03}},
{3,(char[]){0x1a,'s',0x04}},
{3,(char[]){0x1a,'s',0x05}},
{3,(char[]){0x1a,'s',0x06}},
{3,(char[]){0x1a,'s',0x07}},
{3,(char[]){0x1a,'s',0x08}},
{3,(char[]){0x1a,'s',0x09}},
{3,(char[]){0x1a,'s',0x0A}},
{3,(char[]){0x1a,'s',0x0B}},
{3,(char[]){0x1a,'s',0x0C}},
{3,(char[]){0x1a,'s',0x0D}},		
{3,(char[]){0x1a,'s',0x0E}}		
};




inline void outputCommand(struct command output){
int	i;

	for(i=0;i<output.length;i++)	putchar(output.command[i]);
}

inline int getOptionChoiceIndex(const char * choiceName, ppd_file_t * ppd)
{
ppd_choice_t	*choice;
ppd_option_t	*option;

	choice=PPDFINDMARKEDCHOICE(ppd,choiceName);
	if(!choice){
		if(!(option=PPDFINDOPTION(ppd,choiceName)))				return -1;
		if(!(choice=PPDFINDCHOICE(option,option->defchoice)))	return -1;
	}
	return atoi(choice->choice);
}

void getPageWidthPageHeight(ppd_file_t * ppd, struct settings_ * settings)
{
ppd_choice_t*	choice;
ppd_option_t*	option;

char			width[20];
char			height[20];
int				Idx=0;
char*			pageSize;


enum{sINIT,sWIDTH,sHEIGHT,sCOMPLETE,sFAIL}	state=sINIT;

	choice=PPDFINDMARKEDCHOICE(ppd,"PageSize");
	if(!choice){
		option=PPDFINDOPTION(ppd,"PageSize");
		choice=PPDFINDCHOICE(option,option->defchoice);
	}

	pageSize=choice->choice;
	while(*pageSize){
		if(state==sINIT){
			if(*pageSize=='X'){
				state=sWIDTH;
				pageSize++;
				continue;
			}
		}else if(state==sWIDTH){
			if ((*pageSize>='0')&&(*pageSize<='9')){
				width[Idx++]=*pageSize++;
				continue;
			}else if(*pageSize=='D'){
				width[Idx++]='.';
				pageSize++;
				continue;
			}else if(*pageSize=='M'){
				pageSize++;
				continue;
			}else if(*pageSize=='Y'){
				state=sHEIGHT;
				width[Idx]=0;
				Idx=0;
				pageSize++;
				continue;
			}
		}else if(state==sHEIGHT){
			if((*pageSize>='0')&&(*pageSize<='9')){
				height[Idx++]=*pageSize++;
				continue;
			}else if(*pageSize=='D'){
				height[Idx++]='.';
				pageSize++;
				continue;
			}else if(*pageSize=='M'){
				height[Idx]=0;
				state=sCOMPLETE;
				break;
			}
		}
		state=sFAIL;
		break;
	}

	if(state==sCOMPLETE){
		settings->pageWidth=atof(width);
		settings->pageHeight=atof(height);
	}else
		settings->pageWidth=
		settings->pageHeight=0;
}

int initializeSettings(char * commandLineOptionSettings, struct settings_ * settings){
ppd_file_t*		ppd;
cups_option_t*	options		=NULL;
int				numOptions;

	ppd=PPDOPENFILE(getenv("PPD"));
	if(!ppd){
		fprintf(stderr,"INFO: PPD(%s) open error\n",getenv("PPD"));
		return FALSE;
	}
	PPDMARKDEFAULTS(ppd);
	numOptions=CUPSPARSEOPTIONS(commandLineOptionSettings,0,&options);
	if((numOptions!=0)&&(options!=NULL)){
		CUPSMARKOPTIONS(ppd,numOptions,options);
		CUPSFREEOPTIONS(numOptions,options);
	}
	memset(settings,0,sizeof(struct settings_));
	settings->cashDrawer			=getOptionChoiceIndex("CashDrawer"			,ppd);
	settings->cashDrawerPulseWidth	=getOptionChoiceIndex("CashDrawerPulseWidth",ppd);
	settings->cutterMode			=getOptionChoiceIndex("CutterMode"			,ppd);
	settings->buzzerOption			=getOptionChoiceIndex("BuzzerOption"		,ppd);
	settings->formfeedType			=getOptionChoiceIndex("FormFeedType"		,ppd);
	settings->printDensity			=getOptionChoiceIndex("PrintDensity"		,ppd);
	settings->printSpeed			=getOptionChoiceIndex("PrintSpeed"			,ppd);
	settings->bytesPerScanLine		=MAX_WIDTH;
	settings->bytesPerScanLineStd	=STD_WIDTH;
	getPageWidthPageHeight(ppd,settings);
	PPDCLOSE(ppd);
	return TRUE;


}

void jobSetup(struct settings_ settings){
unsigned char	pw;
	outputCommand(printerInitializeCommand);
	buzzeronoff(settings);
	prtSpeed(settings);
	density(settings);
	if((settings.cashDrawer==1)||(settings.cashDrawer==2)){
		pw=(settings.cashDrawerPulseWidth+1)*25;
		printf("\x1bp%d%c%c",settings.cashDrawer-1,pw,pw);
	}
}

void pageSetup(struct settings_ settings, cups_page_header2_t header){
	outputCommand(startPageCommand);
}

void cutPage(struct settings_ settings)
{
	switch(settings.cutterMode){
	case 3:
		outputCommand(PageCutCommand[0]);
		break;
	case 4:
		outputCommand(PageCutCommand[0]);		// Partial Cut
		break;
	case 5:
		outputCommand(PageCutCommand[1]);		// Full Cut
		break;
	case 6:
		outputCommand(PageCutCommand[2]);		// blackmark
		break;
	default:
		break;
	}
}
void formFeed(struct settings_ settings)
{
	outputCommand(FormFeedCommand[settings.formfeedType]);	
}
void prtSpeed(struct settings_ settings)
{
	outputCommand(SpeedCommand[settings.printSpeed]);	
}
void density(struct settings_ settings)
{
	outputCommand(DensityCommand[settings.printDensity]);	
}
void buzzeronoff(struct settings_ settings)
{
	outputCommand(BuzzerCommand[settings.buzzerOption]);	
}
void cutJob(struct settings_ settings)
{
	switch(settings.cutterMode){
	case 1:
		outputCommand(PageCutCommand[0]);		// Partial Cut
		break;
	case 2:
		outputCommand(PageCutCommand[1]);		// Partial Cut
		break;
	case 3:
		outputCommand(PageCutCommand[0]);		// Partial Cut
		break;	
	case 4:
		outputCommand(PageCutCommand[1]);		// Partial Cut
		break;
	case 5:
		outputCommand(PageCutCommand[1]);		// Full Cut
		break;
	case 6:
		outputCommand(PageCutCommand[2]);		// blackmark
		break;
	default:
		break;
	}
}
void endPage(struct settings_ settings)
{
	outputCommand(endPageCommand);
}
void endJob(struct settings_ settings)
{
	outputCommand(endJobCommand);
}

#define	GET_LIB_FN_OR_EXIT_FAILURE(fn_ptr,lib,fn_name)										\
{																							\
	fn_ptr=dlsym(lib,fn_name);																\
	if ((dlerror())){																		\
		fputs("ERROR: required fn not exported from dynamically loaded libary\n",stderr);	\
		if(libCupsImage)	dlclose(libCupsImage);											\
		if(libCups)			dlclose(libCups);												\
		return EXIT_FAILURE;																\
	}																						\
}

#ifdef	RPMBUILD
#define	CLEANUP 			\
{							\
	if(rasterData)			\
		free(rasterData);	\
	CUPSRASTERCLOSE(ras);	\
	if(fd)					\
		close(fd);			\
	dlclose(libCupsImage);	\
	dlclose(libCups);		\
}
#else
#define	CLEANUP 			\
{							\
	if(rasterData)			\
		free(rasterData);	\
	CUPSRASTERCLOSE(ras);	\
	if(fd)					\
		close(fd);			\
}
#endif

int main(int argc, char *argv[])
{
int 				fd;							/* File descriptor providing CUPS raster data				*/
cups_raster_t		*ras; 						/* Raster stream for printing								*/
cups_page_header2_t	header; 					/* CUPS Page header 										*/

int 				y,							/* Vertical position in page 0 <= y <=header.cupsHeight	*/
					page=0,						/* Current page		*/
					ybk,yRemain;
unsigned long		i;

unsigned char		*rasterData=NULL;			/* Pointer to raster data buffer							*/
struct settings_	settings;					/* Configuration settings									*/

#ifdef RPMBUILD
void	*libCupsImage;							/* Pointer to libCupsImage library							*/
void	*libCups;								/* Pointer to libCups library								*/

	libCups=dlopen("libcups.so",RTLD_NOW|RTLD_GLOBAL);
	if(!libCups){
		fputs("ERROR: libcups.so load failure\n",stderr);
		return EXIT_FAILURE;
	}

	libCupsImage=dlopen("libcupsimage.so",RTLD_NOW|RTLD_GLOBAL);
	if(!libCupsImage){
		fputs("ERROR: libcupsimage.so load failure\n",stderr);
		dlclose(libCups);
		return EXIT_FAILURE;
	}

	GET_LIB_FN_OR_EXIT_FAILURE(ppdClose_fn, 			libCups,	  "ppdClose"			 );
	GET_LIB_FN_OR_EXIT_FAILURE(ppdFindChoice_fn,		libCups,	  "ppdFindChoice"		 );
	GET_LIB_FN_OR_EXIT_FAILURE(ppdFindMarkedChoice_fn,	libCups,	  "ppdFindMarkedChoice"  );
	GET_LIB_FN_OR_EXIT_FAILURE(ppdFindOption_fn,		libCups,	  "ppdFindOption"		 );
	GET_LIB_FN_OR_EXIT_FAILURE(ppdMarkDefaults_fn,		libCups,	  "ppdMarkDefaults" 	 );
	GET_LIB_FN_OR_EXIT_FAILURE(ppdOpenFile_fn,			libCups,	  "ppdOpenFile" 		 );
	GET_LIB_FN_OR_EXIT_FAILURE(cupsFreeOptions_fn,		libCups,	  "cupsFreeOptions" 	 );
	GET_LIB_FN_OR_EXIT_FAILURE(cupsParseOptions_fn, 	libCups,	  "cupsParseOptions"	 );
	GET_LIB_FN_OR_EXIT_FAILURE(cupsMarkOptions_fn,		libCups,	  "cupsMarkOptions" 	 );
	GET_LIB_FN_OR_EXIT_FAILURE(cupsRasterOpen_fn,		libCupsImage, "cupsRasterOpen"		 );
	GET_LIB_FN_OR_EXIT_FAILURE(cupsRasterReadHeader_fn, libCupsImage, "cupsRasterReadHeader2" );
	GET_LIB_FN_OR_EXIT_FAILURE(cupsRasterReadPixels_fn, libCupsImage, "cupsRasterReadPixels" );
	GET_LIB_FN_OR_EXIT_FAILURE(cupsRasterClose_fn,		libCupsImage, "cupsRasterClose" 	 );
#endif
	if((argc<6)||(argc>7)){
		fputs("ERROR: rastertohwasung job-id user title copies options [file]\n",stderr);
		#ifdef RPMBUILD
			dlclose(libCupsImage);
			dlclose(libCups);
		#endif
		return EXIT_FAILURE;
	}
	if(argc==7){
		if((fd=open(argv[6],O_RDONLY))==-1){
			perror("ERROR: Unable to open raster file - ");
			sleep(1);
			#ifdef RPMBUILD
				dlclose(libCupsImage);
				dlclose(libCups);
			#endif
			return EXIT_FAILURE;
		}
	}else
		fd=0;

	if(!initializeSettings(argv[5],&settings)){
		#ifdef RPMBUILD
			dlclose(libCupsImage);
			dlclose(libCups);
		#endif
		return EXIT_FAILURE;
	}
	jobSetup(settings);
	ras=CUPSRASTEROPEN(fd,CUPS_RASTER_READ);
	while(CUPSRASTERREADHEADER(ras, &header)){
	
		if((!header.cupsHeight)||(!header.cupsBytesPerLine))	break;
		if(!rasterData){
			if(!(rasterData=malloc(header.cupsBytesPerLine))){
				CLEANUP;
				return EXIT_FAILURE;
			}
		}
	if(page > 0) formFeed(settings);
	if(page > 0) cutPage(settings);
	
		pageSetup(settings,header);
		page++;
		fprintf(stderr,"PAGE: %d %d\n",page,header.NumCopies);

		settings.bytesPerScanLine	=(header.cupsBytesPerLine<=settings.bytesPerScanLine)
									?header.cupsBytesPerLine
									:settings.bytesPerScanLineStd;

		for(yRemain=header.cupsHeight;yRemain;yRemain-=ybk){
			ybk=(yRemain>0x300)?0x2ff:yRemain;
			printf("\x1dv00");
			putchar(header.cupsBytesPerLine); putchar(header.cupsBytesPerLine>>8);
			putchar(ybk);					 	  putchar(ybk>>8);
			for(y=0;y<ybk;y++){
				i=header.cupsHeight-yRemain+y;
				if(!(i&127))
					fprintf(stderr,"INFO: Printing page %d, %ld%% complete...\n",page,(100*i/header.cupsHeight));
				if(CUPSRASTERREADPIXELS(ras,rasterData,header.cupsBytesPerLine)<1)
					break;
				for(i=0;i<header.cupsBytesPerLine;i++){
					putchar(rasterData[i]);
				}
			}
		}

		

		
	}

formFeed(settings);
		cutJob(settings);
		
	endJob(settings);
	CLEANUP;
	fputs(page?"INFO: Ready to print.\n":"ERROR: No pages found!\n",stderr);
	return(page)?EXIT_SUCCESS:EXIT_FAILURE;
}

