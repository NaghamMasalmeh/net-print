## Compile
    x64 : gcc -m64 -Wl,-rpath,/usr/lib -Wall -fPIC -O2 -o rastertohwasung rastertohwasung.c -lcupsimage -lcups
    x86 : gcc -m32 -Wl,-rpath,/usr/lib -Wall -fPIC -O2 -o rastertohwasung rastertohwasung.c -lcupsimage -lcups



