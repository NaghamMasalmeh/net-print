/*=================================================================================*
*FileName:     	send.c
*Description:	definitions for processing send buffer functions
*Revision:     	1.0									
*Date:         	2003.08.28							
*Author:       	 									
*Histroy:      	
*==================================================================================*/

//#include <cups/cups.h>
//#include <cups/raster.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>

#include"pd.h"
#include"send.h"
#include "brcommon.h"
#include "modelfunctions.h"
#include "Message.h"
#include <stdio.h>

send_buffer		send_buf = { MODEL_UNKNOWN , NULL , 0 };

short	CreateSendBuf( pt_model model ) ;
void	DestroySendBuf() ;
void	ResetSendBuf() ;
short	SaveDumb( long * pLen , unsigned char * pBuf ) ;
short	FlushBuf() ;

/*-------------------------------------------------------------------------------------
*Name 		: CreateSendBuf
*Description 	: Create buffer for compressed data
*Parameters : 
*	model	: print model.
Precondition	: N/A
*Operation 	: Allocate memory.
*Postcondition 	: buffer is ready.
*Return 	:
*		0 	: Succeeded ; otherwise , Failed.
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/
short	CreateSendBuf( pt_model model )
{
	short	sRet = 1 ;
	
	if( MODEL_UNKNOWN == model ){
		fprintf( stderr , "%s%s" , kError , kUnknownModel ) ;
		return sRet ;
	}
	
	send_buf.buffer = ( unsigned char * )malloc( DUMB_BUF_SIZE + 64 ) ;

	if( NULL == send_buf.buffer ){
		fprintf( stderr , "%s%s" , kError , kInsufficientMemory ) ;
		return sRet ;
	}

/*
*Reset other members
*/
	send_buf.model  = model ;
	send_buf.lBufByteCnt = 0 ;

	return 0 ;
}

/*-------------------------------------------------------------------------------------
*Name 		: DestroySendBuf
*Description 	: Destroy the send buffer
*Parameters 	: N/A
*Precondition	: N/A
*Operation 	: Free memory.
*Postcondition 	: buffer is freed.
*Return 		: N/A
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/
void	DestroySendBuf()
{
	if( NULL != send_buf.buffer ){
		free( send_buf.buffer ) ;
	}
    
	send_buf.model			= MODEL_UNKNOWN ;
	send_buf.buffer			= NULL ;
	send_buf.lBufByteCnt	= 0 ;
}

/*-------------------------------------------------------------------------------------
*Name 		: ResetSendBuf
*Description 	: Reset the send buffer
*Parameters 	: N/A
*Precondition	: N/A
*Operation 	: Reset member of send buffer structure.
*Postcondition 	: members of send buffer structure is reset.
*Return 		: N/A
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/
void	ResetSendBuf()
{
	send_buf.lBufByteCnt	= 0 ;
}

/*-------------------------------------------------------------------------------------
*Name 		: SaveDumb
*Description 	: Save a line data to the send buffer
*Parameters 	: 
*		pLen : Length of data to be saved to send buffer
*		pBuf : Buffer of data to be saved.
*Precondition	: pLen != NULL && pBuf != NULL  && *pLen <= DUMB_BUF_SIZE
*Operation 	: Free memory.
*Postcondition 	: buffer is freed.
*Return 		: 
*		0 	: Succeeded ; otherwise , Failed.
*History 		: 1.Created , by  , 2003.09.02
*--------------------------------------------------------------------------------------*/
short	SaveDumb( long * pLen , unsigned char * pBuf )
{
	short			sRet 			= 1 ;
	short			sLenMax 		= 0 ;			/* Length overflow flag 	     */
	unsigned char * dumbSavePtr 	= NULL ;
	
/*
*Set overflow flag
*/
	if( send_buf.lBufByteCnt + *pLen > DUMB_BUF_SIZE ){
		sLenMax = 1 ;
	}

/*
*Send Data if the data will overflow
*/
	if( sLenMax ){
		if( fun_table.lpfnMSendData ){
			if( ( sRet = fun_table.lpfnMSendData( &send_buf ) )){
				fprintf( stderr , "%s%s" , kError , kFailedSendData ) ;
				send_buf.lBufByteCnt	= 0 ;
				return sRet ;
			}
		}
	}

/*
*Copy data to the send buffer
*/
	dumbSavePtr = send_buf.buffer + send_buf.lBufByteCnt ;
//64bit	copyData( pBuf , dumbSavePtr , (short)*pLen ) ;
	memcpy( dumbSavePtr ,pBuf, (short)*pLen ) ;
	send_buf.lBufByteCnt += *pLen ;
	return 0 ;
}

/*-------------------------------------------------------------------------------------
*Name 		: FlushBuf
*Description 	: Send remained data in send buffer to the printer.
*Parameters 	: N/A
*Precondition	: N/A
*Operation 	: Send remained data.
*Postcondition 	: data is sent.
*Return 		: 
*		0 	: Succeeded ; otherwise , Failed.
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/
short	FlushBuf()
{
	return fun_table.lpfnMSendData( &send_buf ) ;
}

