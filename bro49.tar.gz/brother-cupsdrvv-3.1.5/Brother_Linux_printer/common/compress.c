/* $Id: compress.c,v 1.5 2005/07/28 13:38:30 cvs Exp $ */

/* 
* Copyright (C) 2003-2013 Brother. Industries, Ltd.
*
* This program is free software; you can redistribute it and/or modify it
* under the terms of the GNU General Public License as published by the Free
* Software Foundation; either version 2 of the License, or (at your option)
* any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
* more details.
*
* You should have received a copy of the GNU General Public License along with
* this program; if not, write to the Free Software Foundation, Inc., 59 Temple
* Place, Suite 330, Boston, MA  02111-1307  USA
*/
/*=================================================================================*
*FileName:     	compress.c
*Description:	variable and function declarations for source line data and compression
*Revision:     	1.0									
*Date:         	2003.08.28							
*Author:       	Chenxujin , SteadyBJ 									
*Histroy:      	1.Chenxujin , Create
*==================================================================================*/

#include <stdio.h>
//#include <cups/cups.h>
//#include <cups/raster.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>

#include "define.h"   //added by zhangshumin. 2005.06.06
#include"pd.h"

#ifndef _STDBJ_LINUX_
#include"Compress.h"
#else
#include "compress.h"
#endif

#include "message.h"


unsigned char *	Planes[ 4 ] ={ NULL } ;

MODE9	compData = { 0 , \
					NULL , \
					0 , \
					NULL} ;

short	CreateCompressBuf( unsigned long lSourceLen , unsigned long lSourceHeight ) ;
void	DestroyCompressBuf() ;
#ifdef _STDBJ_LINUX_        // modified by liubin 2005.6.18
unsigned char*	CreateBandBuf( unsigned long lBytesPerLine , short line ) ;
#else
short	CreateBandBuf( unsigned long lBytesPerLine , short line ) ;
#endif
void	DestroyBandBuf() ;

/*-------------------------------------------------------------------------------------
*Name 		: CreateCompressBuf
*Description 	: Create buffer for compression
*Parameters : 
*	model		: printer model
*	lSourceHeight	: source height of a page( used for PC FAX)
*Precondition	: N/A
*Operation 	: Allocate memory for compression operation
*Postcondition 	: Memory is allocated
*Return 	:
*		0 	: Succeeded ; otherwise , Failed.
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/
short	CreateCompressBuf(unsigned long lSourceLen , unsigned long lSourceHeight )
{
	short	sRet = 1 ;

	if( 0 == lSourceLen ){
		fprintf( stderr , "%s%s" , kError , kInvalidParameter ) ;
		return sRet ;
	}
	
/*
*Allocate memory for PC FAX
*lSourceHeight	: the height of a fax page
*
*compData.source	:	page data after halftone process
*compData.sLen	:	size of one line data after halftone without center adjustment
*/	
	compData.dest = (unsigned char *)malloc( MAX_FAX_BYTE * lSourceHeight * 5 + lSourceLen ) ;
	if( NULL == compData.dest ){
		fprintf( stderr , "%s%s" , kError , kInsufficientMemory ) ;
		return sRet ;
	}
	
	memset( compData.dest , 0 , MAX_FAX_BYTE * lSourceHeight * 4 + \
						  lSourceLen + \
						  MAX_FAX_BYTE * lSourceHeight  ) ;		/* whole page data after halftone process */
	compData.source	= compData.dest + MAX_FAX_BYTE * lSourceHeight * 4 	 ;
	compData.lOrginSLen = lSourceLen		;
	compData.sLen		 = 0				;
		
	return 0 ;
}

/*-------------------------------------------------------------------------------------
*Name 		: DestroyCompressBuf
*Description 	: Destroy the compression buffer
*Parameters : 
*Precondition	: N/A
*Operation 	: Free memory
*Postcondition 	: Compression buffer is freed
*Return 		: N/A
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/
void	DestroyCompressBuf()
{
	if( compData.dest ){
		free( compData.dest ) ;
	}

	compData.lOrginSLen	= 0 ;
	compData.source		= NULL ;
	compData.dest			= NULL ;
	compData.sLen			= 0 ;
}

/*-------------------------------------------------------------------------------------
*Name 		: CreateBandBuf
*Description 	: Create buffer for 1 Band(512 line) raster data
*Parameters : 
*	lBytesPerLine	: Length of one line ( in bytes)
*	line			: 1 Band = 512 line
*Precondition	: N/A
*Operation 	: Allocate memory for a 1 Band raw raster data
*Postcondition 	: 1 Band Size Memory is allocated
*Return 	:
*		0 	: Succeeded ; otherwise , Failed.
*History 		: 1.Created , by R.Tarao , BIL , 2003.01.15
*--------------------------------------------------------------------------------------*/
#ifdef _STDBJ_LINUX_        // modified by liubin 2005.6.18
unsigned char*	CreateBandBuf( unsigned long lBytesPerLine, short line )
#else
short	CreateBandBuf( unsigned long lBytesPerLine, short line )
#endif
{
	short 		sRet = 1 	;
	
        if( lBytesPerLine <= 0 ){
                fprintf( stderr , kInvalidParameter ) ;	
		return sRet ;
	}
	
/*
*Allocate 1 Band memory
*/
	 Planes[ 0 ] = (unsigned char *)malloc( lBytesPerLine*line);
#ifndef _STDBJ_LINUX_
	 if( NULL == Planes[ 0 ] ){
		fprintf( stderr , "%s%s" , kError , kInsufficientMemory ) ;
		 return sRet ;
	 }

	return 0 ;
#else
	if( NULL == Planes[ 0 ] ){
		fprintf( stderr , "%s%s" , kError , kInsufficientMemory ) ;
		 return 0 ;
	}
	
	return Planes[0] ;
	
#endif
}

/*-------------------------------------------------------------------------------------
*Name 		: DestroyBandBuf
*Description 	: Destroy the raster line data buffer
*Parameters : 
*Precondition	: N/A
*Operation 	: Free memory
*Postcondition 	: raster data buffer is freed
*Return 		: N/A
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/
void	DestroyBandBuf()
{
	if( Planes[ 0 ] ){
		free(Planes[ 0 ]) ;
	}

}
