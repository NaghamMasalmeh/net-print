/* $Id: models.h,v 1.2 2005/06/21 11:49:59 cvs Exp $ */

#ifndef _MODELS_H_
#define _MODELS_H_

#ifdef _cplusplus
extern "C" {
#endif/* _cplusplus */

extern	prn_model		model_language ;	//	1 = PCL mode9, 2 = YL dumb, 3 = 1030 dumb
//extern      unsigned short        model_index ;

extern	unsigned short	GetModel( const char * pstrShortNickName ) ;	//Get model index and language from model name

#ifdef _cplusplus
}
#endif/* _cplusplus */

#endif/* _MODELS_H_ */
