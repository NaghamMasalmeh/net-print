/*=================================================================================*
*FileName:     	rastertobrother.h
*Description:	declarations for main functions
*Revision:     	1.0									
*Date:         	2003.08.28							
*Author:       	Chenxujin , SteadyBJ 									
*Histroy:      	1.Chenxujin , Create
*			2.Liu Bin , Modify , 2005 . 09 . 04
*==================================================================================*/
#ifndef _RASTERTOBROTHER_H_
#define _RASTERTOBROTHER_H_

//#include <cups/cups.h>
//#include <cups/raster.h>

#include"pd.h"
//#include"Send.h"
//#include"Compress.h"

#include <stdio.h> 

#define _LPR_
#ifdef _LPR_
typedef struct{
	FILE	*pFileInput;		/*	���ϥե�����Υե�����ݥ���	*/
	char	*pszNamePaperinf;	/*	�ѻ����ե�����Υե�����̾	*/
	char	*pszNameResource;	/*	�꥽�����ե�����Υե�����̾	*/
	char	*pszNamePrinter;	/* printer name */
	int	nCopies;
	int	nCollate;		//2006.02.23	Added by Liu bin
	int	nSerial;		//2006.03.23	Added by Liu bin
	FILE	*pFileOutput;		/* output file */
	LPPTPARAM sParam;

} BR_LPR_INPUT_PARAMS;

#define	BR_PRT_CMD_PRINTERNAME	"-P"		/* printer name */
#define	BR_PRT_CMD_PAPERINFO	"-pi"		/*	�ѻ����ե�������ꥪ�ץ����	*/
#define	BR_PRT_CMD_RESOURCE		"-rc"		/*	�꥽�����ե�������ꥪ�ץ����	*/

#define	BR_PRT_CMD_OUTPUT		"-out"	/* out to file */
#define	BR_PRT_CMD_PORT			"-port"	/* USB/Serial */

#ifdef _LPR_
#define PIXELBYTE	(3)
//#define RGBTOGRAY(r, g, b) ((double)((r)) * 0.11 + (double)((g)) * 0.59 + (double)((b)) * 0.3))
#else
#define PIXELBYTE	(1)
#endif
typedef struct{
	char			PTName[ 32 ] ;			/* The Ptouch Name */
	short			model	 ;			/* model */
	LPPT_TAPE		pTape	 ;			/* Tape */

	short			compress ;			/* 1 : compress ; 0 : non-compress */
	short			orientation ;		/* 1 : portrait ; 2 : landscape ; 3 : reverse portrait ; 4 : reverse landscape */
	short			sTapeLength ;		/* Length set on the UI , for continuous tapes */
	short			sTapeMargin ;		/* Margin , for continuous tapes */
    short           sCutAtEnd ;         /* 1 : CutAtEnd On (Def.) ; 0 : CutAtEnd Off */
//	short			sAutoCut ;			/* 1 : Auto Cut On (Def.) ; 0 : Auto Cut Off */
	short			sMirrorPrinting ;	/* 1 : Mirror Printing ; 0 : Off (Def.) */
	short			sPriority ;			/* 0 : Give priority to print speed (Def.) ; 1 : Give priority to print quality */
    short           CutLabel;                      /* 1 : CutAtEnd On (Def.) ; 0 : CutAtEnd Off */ //Satyam added for QL570

	short			sHalftonePattern ;	/* 0 : Binary ; 1 : Dither ; 2 : Error Diffusion (Def.) */
	short			sBrightness ;		/* -50 ~ 50 */
	short			sContrast ;			/* -50 ~ 50 */

	/* For the raster data */
	short			iPage ;				/* The page number */
	short			sSourceWidth  ;		/* Width of source data , in pixel */
	short			sSourceHeight ;		/* Height of source data , in pixel */

	/* For the Source Buffer */
    short			bandTotal;			/* Number of bands */
    short			lastBandH;			/* Height of last band */

    short			bandNum;			/* the index of current band ( 0 ~ bandTotal - 1 ) */
    short			bandline;			/* the index of the first line of the current band ( 0 ~ sSourceHeight ) */
	unsigned char * pBandData ;			/* Buffer of the current band data */
	short			sSourceWidthBytes ;	/* Bytes of a line */
    short			bandHeight;			/* height of the current band */



	/* for Halftone precess */
	short			sDestWidth ;		/* Width of dest data , in Pins */
	short			sDestHeight ;		/* Height of dest data , in Pins */

} PRTJOB_PARAM;

#endif


#ifdef _cplusplus
extern "C" {
#endif/*_cplusplus*/
#ifdef _LPR_
extern	short	SendRasterDoc(	BR_LPR_INPUT_PARAMS *pInParam ) ;
extern	short	BeginPageData(	BR_LPR_INPUT_PARAMS *pInParam, 
								int					iPage		) ;
extern	short	SendPageData(	BR_LPR_INPUT_PARAMS *pInParam, 
						int					iPage		) ;
#else
extern	short	SendRasterDoc(	cups_raster_t *			ras , 		\
						ppd_file_t * ppd 				) ;
extern	short	BeginPageData(	ppd_file_t *			ppd , 		\
								cups_page_header_t *		header , 	\
								int					iPage		) ;
extern	short	SendPageData(	cups_raster_t *			ras , 		\
						ppd_file_t *			ppd , 		\
						cups_page_header_t *		header , 	\
						int					iPage		) ;
#endif
extern short	EndPageData( short sLastPage ) ;

#ifdef _cplusplus
}
#endif/*_cplusplus*/



#endif/*_RASTERTOBROTHER_H_*/

