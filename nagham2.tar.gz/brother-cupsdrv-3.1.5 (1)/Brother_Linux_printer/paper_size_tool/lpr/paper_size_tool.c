/*
	paper_size_tool.c
	created  2005.11

*/
#include <sys/time.h>
#include <errno.h>
#include "define.h"

//#define _UI_
#define _VERSION_		"v 1.0"

#define _BUF_SIZE_		1024
#define _MM_TO_INCH_	25.43859649
#define _LABEL_BUF_MAX_ 	33
#define _LABEL_MAX_ 	(_LABEL_BUF_MAX_ - 1)
#define _MAX_FEED_VALUE_ 	30
#define _MIN_FEED_VALUE_ 	3

#define _CMD_COUNT_  7
#define _CMD_PRINTER_		"-P"
#define _CMD_ADD_LABEL_	"-n"
#define _CMD_DEL_LABEL_	"-d"
#define _CMD_WIDTH_			"-w"
#define _CMD_HEIGHT_		"-h"
#define _CMD_FEED_			"-f"
#define _CMD_LABEL_ID_		"-specid"
#define _CMD_SHOW_INFO_		"-show"

#define _PPD_CUPS_FORMAT_		"/etc/cups/ppd/%s.ppd"

#ifdef _PTOUCH_UP1_ // Added 2013.05.13 for Update QL-Base
#define _LPR_FUNC_FORMAT_           "/opt/brother/PTouch/%s/inf/br%sfunc"
#define _LPR_PAPER_INF_FORMAT_      "/opt/brother/PTouch/%s/inf/paperinf%s"
#define _LPR_RC_FORMAT_             "/opt/brother/PTouch/%s/inf/br%src"
#define _CUPS_TOOL_NAME_            "/opt/brother/PTouch/%s/lpd/brpapertoolcups"
#else // _PTOUCH_UP1_
#define _LPR_FUNC_FORMAT_           "/usr/local/Brother/PTouch/%s/inf/br%sfunc"
#define _LPR_PAPER_INF_FORMAT_      "/usr/local/Brother/PTouch/%s/inf/paperinf%s"
#define _LPR_RC_FORMAT_             "/usr/local/Brother/PTouch/%s/inf/br%src"
#define _CUPS_TOOL_NAME_            "/usr/local/Brother/PTouch/%s/lpd/brpapertoolcups"
#endif // _PTOUCH_UP1_

#define _FUNC_ITEM_				"[CustomTape]"
#define _FUNC_ITEM_END_		"[CustomTapeEND]"


//efine _PPD_CUPS_FORMAT_		"%s"

#define _DEFAULT_PAGESIZE_				"*DefaultPageSize:"
#define _DEFAULT_PAGEREGION_			"*DefaultPageRegion:"
#define _DEFAULT_IMAGEAREA_			"*DefaultImageableArea:"
#define _DEFAULT_PAPERDIMENSION_		"*DefaultPaperDimension:"

#define _CLOSEUI_PAGESIZE_			"*CloseUI: *PageSize"
#define _CLOSEUI_PAGEREGION_		"*CloseUI: *PageRegion"
#define _IMAGEABLEAREA_			"*ImageableArea"
#define _PAPERDIMENSION_			"*PaperDimension"
#define _PAGESIZE_FORMAT_			"*PageSize %s/%s:\t\"<</PageSize[%.2f %.2f]/ImagingBBox null>>setpagedevice\"\n"
#define _PAGEREGION_FORMAT_		"*PageRegion %s/%s:\t	\"<</PageSize[%.2f %.2f]/ImagingBBox null>>setpagedevice\"\n"
#define _IMAGEABLEAREA_FORMAT_	"*ImageableArea %s/%s:\t\"%.2f %.2f %.2f %.2f\"\n"
#define _PAPERDIMENSION_FORMAT_	"*PaperDimension %s/%s:\t\"%.2f %.2f\"\n"
#define _CONSTRAINTS_FORMAT_		"*UIConstraints:\t*BrMargin %d\t*PageSize %s\n"
#define _LABLE_ID_HEAD_				"BrL"
#define _PAGESIZE_HEAD_			"*PageSize"

#define _CONST_TAPE_COUNT_	12

#define _DEF_NAME_				// added  2006.3.13

enum
{
	_P_ID = 0,
	_n_ID,
	_d_ID,
	_w_ID,
	_h_ID,
	_f_ID,
};

typedef struct
{
//	int	IsAdd;		// 1 - add a new label / 0 - remove one label
	char FileName[_BUF_SIZE_];
	char PrinterName[_BUF_SIZE_];			// ql500, ql550, ql570, ql650
	char InputPrinterName[_BUF_SIZE_];
	char LabelName[_LABEL_BUF_MAX_];
	char LabelID[_LABEL_BUF_MAX_];		// only for LPRng driver
	long lW_mm;
	long lH_mm;
}TParam;


size_t fread_line_string(char *ptr, FILE *stream);
size_t fwrite_line_string(const char *lpString, size_t length, FILE *stream);
int SetConstraints(FILE* ppdfile, const char* LableID, long lHeight_mm);
void DisplayHelp(TParam param)
{
char model[200]="";

	if( strstr( param.PrinterName,"ql800") )
	{
		strcpy( model, "QL800" );
	}
	else if( strstr( param.PrinterName,"ql810w") )
	{
		strcpy( model, "QL810W" );
	}
	else if( strstr(param.PrinterName,"ql820nwb") )
	{
		strcpy( model, "QL820NWB" );
	}

	printf("===========================\n");
	printf(" LPRng Paper Size Tool (%s)\tCopyright by 2005-2016\n", _VERSION_);
	printf(" Usage: brpapertoollpr_xxxx -P QL-xxxx Printer Name [-n add a Lable Format Name (<=%d bytes) -w Media Width(unit:mm) -h Media Height(unit:mm)]/[-d delete Lable Format Name]\n", _LABEL_MAX_);
	printf(" For example:\n");
	printf(" 1. Add a new Label Format with \"New Label Format\" name and 29mm width and 70mm length:\n");
	printf("\t\"brpapertoollpr_%s -P %s -n New\\ Label\\ Format -w 29 -h 70\" [enter]\n\n",param.PrinterName,model);
	printf(" 2. Remove the Label Format with \"New Label Format\" name:\n");
	printf("\t\"brpapertoollpr_%s -P %s -d New\\ Label\\ Format\" [enter]\n\n",param.PrinterName,model);
#ifdef _UI_
	printf(" 3. List all label name:\n");
	printf("\t\"brpapertoollpr_%s -P %s\" [enter]\n",param.PrinterName,model);
	printf("\t\All information is in ql720nw.list\n\n");
#endif
	printf("===========================\n");
}
int List_Lable(const char* FileName)
{
    int iLableCount = 0;
    FILE* ppdfile = fopen(FileName, "r");
    char lpString[_BUF_SIZE_], lpBuf[_BUF_SIZE_];
    FILE* listppdfile;
    
    if(ppdfile == NULL)
    {
        return -1;
    }


	sprintf(lpBuf, "%s.list", FileName);
	listppdfile = fopen(lpBuf, "w");
	if(lpBuf == NULL)
	{
		fclose(ppdfile);
		return -1;
	}


	while(fread_line_string(lpString, ppdfile) > 0)
	{
		if( strncmp(_PAGESIZE_HEAD_, lpString, strlen(_PAGESIZE_HEAD_)) == 0 )
		{
			char *ptr = strstr(lpString, _LABLE_ID_HEAD_);
			if(ptr != NULL)
			{
				// get lable name length
				char lp[100] = {0};
				int iStrLen;
				memcpy(lp, ptr + strlen(_LABLE_ID_HEAD_), 2);
				lp[2] = 0;
				sscanf(lp, "%X", &iStrLen);
//				printf("Length = %d\n", iStrLen);

				// get lable name string
				memcpy(lp, ptr + 16, iStrLen);
				lp[iStrLen] = 0;

//				printf("%s", lp);
				sprintf(lpBuf, "%s\n", lp);
				fwrite_line_string(lpBuf, strlen(lpBuf), listppdfile);

				// get width
				memcpy(lp, ptr + strlen(_LABLE_ID_HEAD_) + 2, 2);
				lp[2] = 0;
				sscanf(lp, "%X", &iStrLen);
//				printf(" [%d, ", iStrLen);
                            sprintf(lpBuf, "%d\n", iStrLen);
				fwrite_line_string(lpBuf, strlen(lpBuf), listppdfile);

				// get height
				memcpy(lp, ptr + strlen(_LABLE_ID_HEAD_) + 4, 3);
				lp[3] = 0;
				sscanf(lp, "%X", &iStrLen);
//				printf("%d]\n", iStrLen);
                            sprintf(lpBuf, "%d\n", iStrLen);
				fwrite_line_string(lpBuf, strlen(lpBuf), listppdfile);

				iLableCount++;
			}
		}
	}

	fclose(ppdfile);
	fclose(listppdfile);
	return iLableCount;
}


int Lookup_Lable(const char* FileName, const char* Lable_Name, char* Lable_ID)
{
	FILE* ppdfile = fopen(FileName, "r");
	char lpString[_BUF_SIZE_];

	if(ppdfile == NULL)
	{
		return 0;
	}

	
	while(fread_line_string(lpString, ppdfile) > 0)
	{
//		if( strncmp(_PAGESIZE_HEAD_, lpString, strlen(_PAGESIZE_HEAD_)) == 0 )
		{
			char *ptr = strstr(lpString, _LABLE_ID_HEAD_);
			if(ptr != NULL)
			{
				// get lable name length
				char lp[100] = {0};
				int iStrLen;
				memcpy(lp, ptr + strlen(_LABLE_ID_HEAD_), 2);
				lp[2] = 0;
				sscanf(lp, "%X", &iStrLen);
//				printf("Length = %d\n", iStrLen);

				// get lable name string
				memcpy(lp, ptr + 16, iStrLen);
				lp[iStrLen] = 0;

				if(strcmp(lp, Lable_Name) == 0 )
				{
					// get lable name ID
					memcpy(Lable_ID, ptr, 15);
					Lable_ID[15] = 0;
					fclose(ppdfile);
					return 1;
				}
			}
		}
	}

	fclose(ppdfile);
	return 0;
}
//
// fread_line_string(char *ptr, FILE *stream)
//
size_t fread_line_string(char *ptr, FILE *stream)
{
	size_t count = 0;
	while(fread(ptr + count, 1, 1, stream) > 0)
	{
		if(*(ptr + count) == '\n')
		{
			count++;
			break;
		}
		count++;
	}
	ptr[count] = 0;
	return count;
}

//
// fwrite_line_string(char *lpString, size_t length, FILE *stream)
//
size_t fwrite_line_string(const char *lpString, size_t length, FILE *stream)
{
	const char *ptr = lpString;

	int iw = 0, ir = length;
	while(ir > 0)
	{
		iw = fwrite(ptr, 1, ir, stream);
		ir -= iw;
		ptr += iw;
	}

	return length;
}

//
// SetConstraints(FILE* ppdfile, long lHeight_mm)
//
int SetConstraints(FILE* ppdfile, const char* LableID, long lHeight_mm)
{
	char lpString[_BUF_SIZE_];
	long lLow = (long)((lHeight_mm + 1) / 2.0);
	lLow = (lLow < _MIN_FEED_VALUE_) ?  _MIN_FEED_VALUE_ : lLow;

	for( ;lLow <= _MAX_FEED_VALUE_; lLow++)
	{
		sprintf(lpString, _CONSTRAINTS_FORMAT_, lLow, LableID);
		fwrite_line_string(lpString, strlen(lpString), ppdfile);
	}

	return 0;
}
//
//	return	-1: error;
//			1: Not found lable name
//			0: OK
//
int RemoveLable(TParam param)
{
	
	FILE* oldfile, *newfile;
	char lpTempFile[_BUF_SIZE_];
	char lpBuf[_BUF_SIZE_];
	char Label_ID[100];
	int ir;
	char exec[_BUF_SIZE_];
	char cmd[_BUF_SIZE_];
	sprintf(cmd, _CUPS_TOOL_NAME_, param.PrinterName);
	sprintf(exec,"%s   -P %s -d \"%s\" %s %d",
			cmd,
			param.InputPrinterName,
			param.LabelName,
                     _CMD_SHOW_INFO_,
			1);
	if(system(exec) != 0)
	{
		return -2;
	}


	// update brql550func
	sprintf(param.FileName, _LPR_FUNC_FORMAT_, param.PrinterName, param.PrinterName);
       if(Lookup_Lable(param.FileName, param.LabelName, Label_ID) == 0)
       {
//		printf("Not found '%s'\n", param.LabelName);
		return 1;
	}


	oldfile = fopen(param.FileName, "r");
	if(oldfile == NULL)
	{
		return -1;
	}

	sprintf(lpTempFile, "%s.$$$", param.FileName);
	newfile = fopen(lpTempFile, "w");
	if(newfile == NULL)
	{
		fclose(oldfile);
		return -1;
	}

	while((ir = fread_line_string(lpBuf, oldfile)) > 0)
	{

		if(strstr(lpBuf, Label_ID) != NULL)
		{
			continue;
		}
		fwrite_line_string(lpBuf, ir, newfile);
	}

       fclose(oldfile);
       fclose(newfile);
       remove(param.FileName);
       rename(lpTempFile, param.FileName);
	chmod(param.FileName, 00666);

	// update paperinfql550pt1
	sprintf(param.FileName, _LPR_PAPER_INF_FORMAT_, param.PrinterName, param.PrinterName);
    if(Lookup_Lable(param.FileName, param.LabelName, Label_ID) == 0)
    {
//		printf("Not found '%s'\n", param.LabelName);
		return 1;
	}


	oldfile = fopen(param.FileName, "r");
	if(oldfile == NULL)
	{
		return -1;
	}

	sprintf(lpTempFile, "%s.$$$", param.FileName);
	newfile = fopen(lpTempFile, "w");
	if(newfile == NULL)
	{
		fclose(oldfile);
		return -1;
	}


	while((ir = fread_line_string(lpBuf, oldfile)) > 0)
	{

		if(strstr(lpBuf, Label_ID) != NULL)
		{
			continue;
		}
		fwrite_line_string(lpBuf, ir, newfile);
	}

       fclose(oldfile);
       fclose(newfile);
       remove(param.FileName);
       rename(lpTempFile, param.FileName);
	chmod(param.FileName, 00666);

	// update brql550rc
	sprintf(param.FileName, _LPR_RC_FORMAT_, param.PrinterName, param.PrinterName);
    oldfile = fopen(param.FileName, "r");
	if(oldfile == NULL)
	{
		return -1;
	}

	sprintf(lpTempFile, "%s.$$$", param.FileName);
	newfile = fopen(lpTempFile, "w");
	if(newfile == NULL)
	{
		fclose(oldfile);
		return -1;
	}


	while((ir = fread_line_string(lpBuf, oldfile)) > 0)
	{
//		printf("s=%s", lpBuf);
		if(strstr(lpBuf, Label_ID) == NULL)
		{
			fwrite_line_string(lpBuf, ir, newfile);
			continue;
		}
		// fwrite_line_string("MediaSize=29x42\n", strlen("MediaSize=29x42\n"), newfile);
		fwrite_line_string("MediaSize=29x90\n", strlen("MediaSize=29x90\n"), newfile);
	}

       fclose(oldfile);
       fclose(newfile);
       remove(param.FileName);
       rename(lpTempFile, param.FileName);
	chmod(param.FileName, 00666);

/************************************************************/
// Added by Zhang Tianxia 2013.05.24 for QL-Base Driver
/************************************************************/
    // 5. Update imagingArea file.
    sprintf(param.FileName, _IMAGING_AREA_FORMAT_, param.PrinterName);
    oldfile = fopen(param.FileName, "r");
    if(oldfile == NULL)
    {
        return -1;
    }

    sprintf(lpTempFile, "%s.$$$", param.FileName);
    newfile = fopen(lpTempFile, "w");
    if(newfile == NULL)
    {
        fclose(oldfile);
        return -1;
    }

    while((ir = fread_line_string(lpBuf, oldfile)) > 0)
    {
        if(strstr(lpBuf, Label_ID) != NULL)
        {
            continue;
        }

        fwrite_line_string(lpBuf, ir, newfile);        
    }

    fclose(oldfile);
    fclose(newfile);
    remove(param.FileName);
    rename(lpTempFile, param.FileName);
    chmod(param.FileName, 00666);

	return 0;
}

//
// AddLable(TParam param)
//
int AddLable(TParam param)
{
	char lpTemFile[_BUF_SIZE_];
	
	FILE* oldfile, *newfile;
	char lpTempFile[_BUF_SIZE_];
	char lpString[_BUF_SIZE_];
	char lpBuf[_BUF_SIZE_];

	char exec[_BUF_SIZE_];
	char cmd [_BUF_SIZE_];
	char Label_ID[100];
	int ir;

	struct timeval tv;
	struct timezone tz;
	gettimeofday(&tv, &tz);
	sprintf(Label_ID, "%s%02X%02X%03X%01X%04X",
				_LABLE_ID_HEAD_,
				strlen(param.LabelName),
				param.lW_mm,
				(param.lH_mm & 0x0FFF),
				(tv.tv_sec & 0x0F),
				(tv.tv_usec & 0xFFFF));

	
	sprintf(cmd, _CUPS_TOOL_NAME_, param.PrinterName);
	sprintf(exec,"%s   -P %s -n \"%s\" -w %d -h %d %s %s %s %d",
			cmd,
			param.InputPrinterName,
			param.LabelName,
			param.lW_mm,
			param.lH_mm,
			_CMD_LABEL_ID_,
			Label_ID,
                     _CMD_SHOW_INFO_,
			1
			);
	if( system(exec) != 0 )
	{
        	return -2;
	}
	

	// Write to brql550func
	sprintf(param.FileName, _LPR_FUNC_FORMAT_, param.PrinterName, param.PrinterName);
	oldfile = fopen(param.FileName, "r");
	if(oldfile == NULL)
	{
		return -1;
	}

	sprintf(lpTempFile, "%s.$$$", param.FileName);
	newfile = fopen(lpTempFile, "w");
	if(newfile == NULL)
	{
		fclose(oldfile);
		return -1;
	}

	while((ir = fread_line_string(lpString, oldfile)) > 0)
	{
		// found [CustomTape]
		fwrite_line_string(lpString, ir, newfile);
		if(strstr ( lpString, _FUNC_ITEM_ ) != NULL)
		{
			sprintf(lpBuf,
				"%s/%s\n",
				Label_ID,
				param.LabelName);
			fwrite_line_string(lpBuf, strlen(lpBuf), newfile);
		}
	}

       fclose(oldfile);
       fclose(newfile);
	remove(param.FileName);
       rename(lpTempFile, param.FileName);
	chmod(param.FileName, 00666);

	// Write to paperinfql550pt1
	sprintf(param.FileName, _LPR_PAPER_INF_FORMAT_, param.PrinterName, param.PrinterName);
	
	oldfile = fopen(param.FileName, "r");
	if(oldfile == NULL)
	{
		return -1;
	}

	sprintf(lpTempFile, "%s.$$$", param.FileName);
	newfile = fopen(lpTempFile, "w");
	if(newfile == NULL)
	{
		fclose(oldfile);
		return -1;
	}

	while((ir = fread_line_string(lpString, oldfile)) > 0)
	{
		// found [CustomTape]
		fwrite_line_string(lpString, ir, newfile);
	}

//ql570 54 mm paper - satyam
	if(param.lW_mm == 54)
	{
	sprintf(lpBuf, "%s/%s:\t%d\t%d\n",
				Label_ID,
				param.LabelName,
				590,
				(long)(((double)(param.lH_mm - 6) / _MM_TO_INCH_) * 300.0));
	}
	else
        {
        sprintf(lpBuf, "%s/%s:\t%d\t%d\n",
                                Label_ID,
                                param.LabelName,
                                (long)(((double)(param.lW_mm - 3) / _MM_TO_INCH_) * 300.0),
                                (long)(((double)(param.lH_mm - 6) / _MM_TO_INCH_) * 300.0));
        }


	
	fwrite_line_string(lpBuf, strlen(lpBuf), newfile);

       fclose(oldfile);
       fclose(newfile);
	remove(param.FileName);
       rename(lpTempFile, param.FileName);
	chmod(param.FileName, 00666);
/************************************************************/
// Added  2013.05.24 for QL-Base Driver
/************************************************************/
    // 7. Update imagingArea file.
    sprintf(param.FileName, _IMAGING_AREA_FORMAT_, param.PrinterName);
    oldfile = fopen(param.FileName, "r");
    if(oldfile == NULL)
    {
        return -1;
    }

    sprintf(lpTempFile, "%s.$$$", param.FileName);
    newfile = fopen(lpTempFile, "w");
    if(newfile == NULL)
    {
        fclose(oldfile);
        return -1;
    }
                                
    while((ir = fread_line_string(lpBuf, oldfile)) > 0)
    {
        fwrite_line_string(lpBuf, ir, newfile);
    }

	if(param.lW_mm == 54)
	{
    sprintf(lpBuf,
            _IMAGING_INFO_FORMAT_,
            Label_ID,
            5.76, 8.4,
            ((double)param.lW_mm / _MM_TO_INCH_) * 72.0 - 5.76,
            ((double)param.lH_mm / _MM_TO_INCH_) * 72.0 - 8.4);
	}else{
    sprintf(lpBuf,
            _IMAGING_INFO_FORMAT_,
            Label_ID,
            4.32, 8.4,
            ((double)param.lW_mm / _MM_TO_INCH_) * 72.0 - 4.32,
            ((double)param.lH_mm / _MM_TO_INCH_) * 72.0 - 8.4);
	}
    fwrite_line_string(lpBuf, strlen(lpBuf), newfile);

    fclose(oldfile);
    fclose(newfile);
    remove(param.FileName);
    rename(lpTempFile, param.FileName);
    chmod(param.FileName, 00666);

/************************************************************/
// Added 2013.05.24 for QL-Base Driver end.
/************************************************************/

	return 0;
}

//
// main( int argc, char** argv)
//
int main( int argc, char** argv)
{
	int IsOK = 1;
	int iflag[_CMD_COUNT_] = {0};
	TParam param;
    int i;

	memset(iflag, 0, _CMD_COUNT_ * sizeof(int));
	memset(&param, 0, sizeof(TParam));

	if(argc % 2 == 0)
	{
		IsOK = 0;
	}

		if( strstr( argv[0], "500") )
		{
			strcpy( param.PrinterName, "ql500" );
		}
		else if( strstr( argv[0], "550") )
		{
			strcpy( param.PrinterName, "ql550" );
		}
		else if( strstr( argv[0], "570") )
        {
            strcpy( param.PrinterName, "ql570" );
        }
		else if( strstr( argv[0], "650") )
		{
			strcpy( param.PrinterName, "ql650td" );
		}
		else if( strstr( argv[0], "800") )
		{
			strcpy( param.PrinterName, "ql800" );
		}
		else if( strstr( argv[0], "810") )
		{
			strcpy( param.PrinterName, "ql810w" );
		}
		else if( strstr( argv[0], "820") )
		{
			strcpy( param.PrinterName, "ql820nwb" );
		}
		else
		{
			fprintf( stdout, "%s is invalid.\n\n", argv[0] );
			return 0;
		}




	for(i = 1; (i + 1) < argc && IsOK == 1; i += 2)
	{
//		printf("argv[%d] = %s, argv[%d] = %s\n", i, argv[i], i+1, argv[i+1]);
		if( strncmp( argv[i], _CMD_PRINTER_, strlen(_CMD_PRINTER_)) == 0)
		{
			if( strlen(argv[i + 1]) > _BUF_SIZE_  || strlen(argv[i + 1]) <= 0 )
			{
				IsOK = 0;
				break;
			}
//               	sprintf(param.FileName, _PPD_CUPS_FORMAT_, argv[i + 1]);
			memcpy(param.InputPrinterName, argv[i + 1], strlen(argv[i + 1]));
                	iflag[_P_ID] = 1;
		}
		else if( strncmp( argv[i], _CMD_ADD_LABEL_, strlen(_CMD_ADD_LABEL_)) == 0)
		{
			if( strlen(argv[i + 1]) > _LABEL_MAX_  || strlen(argv[i + 1]) <= 0 )
			{
				IsOK = 0;
				break;
			}
               	memcpy(param.LabelName, argv[i + 1], strlen(argv[i + 1]));

			iflag[_n_ID] = 1;
//			param.IsAdd = 1;
		}
		else if( strncmp( argv[i], _CMD_DEL_LABEL_, strlen(_CMD_DEL_LABEL_)) == 0)
		{
			if( strlen(argv[i + 1]) > _LABEL_MAX_  || strlen(argv[i + 1]) <= 0 )
			{
				IsOK = 0;
				break;
			}
               	memcpy(param.LabelName, argv[i + 1], strlen(argv[i + 1]));

			iflag[_d_ID] = 1;
		}
		else if( strncmp( argv[i], _CMD_WIDTH_, strlen(_CMD_WIDTH_)) == 0)
		{
			if( strlen(argv[i + 1]) > _LABEL_MAX_  || strlen(argv[i + 1]) <= 0 )
			{
				IsOK = 0;
				break;
			}
			if( (param.lW_mm = atol(argv[i + 1])) <= 0 )
			{
				IsOK = 0;
				break;
			}
			iflag[_w_ID] = 1;
		}
		else if( strncmp( argv[i], _CMD_HEIGHT_, strlen(_CMD_HEIGHT_)) == 0)
		{
			if( strlen(argv[i + 1]) > _LABEL_MAX_  || strlen(argv[i + 1]) <= 0 )
			{
				IsOK = 0;
				break;
			}
			if( (param.lH_mm = atol(argv[i + 1])) <= 0 )
			{
				IsOK = 0;
				break;
			}
			iflag[_h_ID] = 1;
		}

		else
		{
			IsOK = 0;
			break;
		}
	}


//       printf("-P (%d), -n (%d), -d (%d), -w (%d), -h(%d)\n", iflag[0], iflag[1], iflag[2], iflag[3], iflag[4] );
//       printf("-P (%s), -n (%s), -d (%s), -w (%d), -h(%d)\n", param.FileName, param.LabelName, param.LabelName, param.lW_mm, param.lH_mm);
#ifdef _UI_
       if( !IsOK || iflag[_P_ID] == 0 || (iflag[_n_ID] == 1 && iflag[_d_ID] == 1) || (iflag[_n_ID] == 1 && (!iflag[_w_ID] || !iflag[_h_ID])))
#else
       if( !IsOK || iflag[_P_ID] == 0 || (iflag[_n_ID] == 1 && iflag[_d_ID] == 1) || (iflag[_n_ID] == 1 && (!iflag[_w_ID] || !iflag[_h_ID])) || ((iflag[_n_ID] | iflag[_d_ID]) == 0))
#endif
       {
		IsOK = 0;
	}


	if( IsOK == 0 )
	{
		DisplayHelp(param);
		return 0;
	}

// 	printf("pid = %d\n", getpid());
//	sleep(300);


#ifdef _UI_
	if( iflag[_n_ID] == 0 && iflag[_d_ID] == 0)
	{
              int iR;
		if((iR = List_Lable(param.FileName)) > 0)
		{
			printf("Please check \"%s.list\"\n", param.FileName);
		}
		else
		{
			if( iR < 0)
			{
				printf("%s\n", strerror(errno));
			}
		}
			
		return 0;
	}
#endif
//	char exec[_BUF_SIZE_];
	if( iflag[_d_ID] == 1)
	{
/*		sprintf(exec,
				"%s   -P %s -d %s",
				_CUPS_TOOL_NAME_,
				param.LabelName,
				param.PrinterName);
*/

		int iR = RemoveLable(param);
		if( iR == -1 )
		{
			printf("%s\n", strerror(errno));
			return -1;
		}
		else if( iR == -2 )
		{
               	return -1;
		}

		if( iR == 1)
		{
			printf("Not found '%s'\n", param.LabelName);
		}

		return 0;
	}

	if( iflag[_n_ID] == 1)
	{
		int iR = RemoveLable(param);
		if( iR == -2 )
		{
			return -1;
		}
		else if ( iR == -1 )
		{
			printf("%s\n", strerror(errno));
			return -1;
		}

		if(AddLable(param) == -1)
		{
//			printf("%s\n", strerror(errno));
			return -1;
		}
		return 0;
	}
	

	// update cups ppd
//	printf("%s(%d)\n", exec, strlen(exec));
//    	system(exec);

	return 0;
}
