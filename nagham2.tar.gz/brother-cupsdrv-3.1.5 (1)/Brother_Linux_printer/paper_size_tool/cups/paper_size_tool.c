/*
	paper_size_tool.c
	created  2005.11

*/
#include <sys/time.h>
#include <errno.h>
#include "define.h"

//#define _UI_
#define _VERSION_		"v 0.1"

#define _BUF_SIZE_		1024
#define _MM_TO_INCH_	25.43859649
#define _LABEL_BUF_MAX_ 	33
//#define _LABEL_BUF_MAX_         36    //satyam added QL570
#define _LABEL_MAX_ 	(_LABEL_BUF_MAX_ - 1)
#define _MAX_FEED_VALUE_ 	30
#define _MIN_FEED_VALUE_ 	3

#define _CMD_COUNT_		8
#define _CMD_PRINTER_		"-P"
#define _CMD_ADD_LABEL_	"-n"
#define _CMD_DEL_LABEL_	"-d"
#define _CMD_WIDTH_			"-w"
#define _CMD_HEIGHT_		"-h"
#define _CMD_FEED_			"-f"
#define _CMD_LABEL_ID_		"-specid"
#define _CMD_SHOW_INFO_		"-show"

#define _PPD_SRC_				"/usr/share/cups/model/brptouchql550_cups.ppd"
#define _PPD_CUPS_FORMAT_		"/etc/cups/ppd/%s.ppd"

#define _DEFAULT_PAGESIZE_				"*DefaultPageSize:"
#define _DEFAULT_PAGEREGION_			"*DefaultPageRegion:"
#define _DEFAULT_IMAGEAREA_			"*DefaultImageableArea:"
#define _DEFAULT_PAPERDIMENSION_		"*DefaultPaperDimension:"

#define _CLOSEUI_PAGESIZE_			"*CloseUI: *PageSize"
#define _CLOSEUI_PAGEREGION_		"*CloseUI: *PageRegion"
#define _IMAGEABLEAREA_			"*ImageableArea"
#define _PAPERDIMENSION_			"*PaperDimension"
#define _PAGESIZE_FORMAT_			"*PageSize %s/%s:\t\"          \"\n"
#define _PAGEREGION_FORMAT_		"*PageRegion %s/%s:\t	\"          \"\n"
#define _IMAGEABLEAREA_FORMAT_	"*ImageableArea %s/%s:\t\"%.2f %.2f %.2f %.2f\"\n"
#define _PAPERDIMENSION_FORMAT_	"*PaperDimension %s/%s:\t\"%.2f %.2f\"\n"
#define _CONSTRAINTS_FORMAT_		"*UIConstraints:\t*BrMargin %d\t*PageSize %s\n"
#define _LABLE_ID_HEAD_				"BrL"
#define _PAGESIZE_HEAD_			"*PageSize"

#define _CONST_TAPE_COUNT_	12

enum
{
	_P_ID = 0,
	_n_ID,
	_d_ID,
	_w_ID,
	_h_ID,
	_f_ID,
};

typedef struct
{
//	int	IsAdd;		// 1 - add a new label / 0 - remove one label
	char PPDFileName[_BUF_SIZE_];
	char LabelName[_LABEL_BUF_MAX_];
	char LabelID[_LABEL_BUF_MAX_];		// only for LPRng driver
	long lW_mm;
	long lH_mm;
}TParam;

int	g_show = 1;
size_t fread_line_string(char *ptr, FILE *stream);
size_t fwrite_line_string(const char *lpString, size_t length, FILE *stream);
int SetConstraints(FILE* ppdfile, const char* LableID, long lHeight_mm);
void DisplayHelp()
{
	if(g_show == 0)
		return;

	printf("===========================\n");
	printf(" CUPS Paper Size Tool (%s)\tCopyright by 2005\n", _VERSION_);
	printf(" Usage: brpapertoolcups -P Printer Name [-n add a Lable Format Name (<=%d bytes) -w Media Width(unit:mm) -h Media Height(unit:mm)]/[-d delete Lable Format Name]\n", _LABEL_MAX_);
	printf(" For example:\n");
	printf(" 1. Add a new Label Format with \"New Label Format\" name and 29mm width and 70mm length:\n");
	printf("\t\"brpapertoolcups -P ql550 -n New\\ Label\\ Format -w 29 -h 70\" [enter]\n\n");
	printf(" 2. Remove the Label Format with \"New Label Format\" name:\n");
	printf("\t\"brpapertoolcups -P ql550 -d New\\ Label\\ Format\" [enter]\n\n");
#ifdef _UI_
	printf(" 3. List all label name:\n");
	printf("\t\"brpapertoolcups -P ql550\" [enter]\n");
	printf("\t\All information is in ql550.list\n\n");
#endif
	printf("===========================\n");
}
int List_Lable(const char* ppdfilename)
{
	int iLableCount = 0;
	FILE* ppdfile = fopen(ppdfilename, "r");
	FILE* listppdfile;
	char lpString[_BUF_SIZE_], lpBuf[_BUF_SIZE_];

	if(ppdfile == NULL)
	{
		return -1;
	}

	sprintf(lpBuf, "%s.list", ppdfilename);
	listppdfile = fopen(lpBuf, "w");
	if(lpBuf == NULL)
	{
		fclose(ppdfile);
		return -1;
	}


	while(fread_line_string(lpString, ppdfile) > 0)
	{
		if( strncmp(_PAGESIZE_HEAD_, lpString, strlen(_PAGESIZE_HEAD_)) == 0 )
		{
			char *ptr = strstr(lpString, _LABLE_ID_HEAD_);
			if(ptr != NULL)
			{
				// get lable name length
				char lp[100] = {0};
				int iStrLen;
				memcpy(lp, ptr + strlen(_LABLE_ID_HEAD_), 2);
				lp[2] = 0;
				sscanf(lp, "%X", &iStrLen);
//				printf("Length = %d\n", iStrLen);

				// get lable name string
				memcpy(lp, ptr + 16, iStrLen);
				lp[iStrLen] = 0;

//				printf("%s", lp);
				sprintf(lpBuf, "%s\n", lp);
				fwrite_line_string(lpBuf, strlen(lpBuf), listppdfile);

				// get width
				memcpy(lp, ptr + strlen(_LABLE_ID_HEAD_) + 2, 2);
				lp[2] = 0;
				sscanf(lp, "%X", &iStrLen);
//				printf(" [%d, ", iStrLen);
                            sprintf(lpBuf, "%d\n", iStrLen);
				fwrite_line_string(lpBuf, strlen(lpBuf), listppdfile);

				// get height
				memcpy(lp, ptr + strlen(_LABLE_ID_HEAD_) + 4, 3);
				lp[3] = 0;
				sscanf(lp, "%X", &iStrLen);
//				printf("%d]\n", iStrLen);
                            sprintf(lpBuf, "%d\n", iStrLen);
				fwrite_line_string(lpBuf, strlen(lpBuf), listppdfile);

				iLableCount++;
			}
		}
	}

	fclose(ppdfile);
	chmod(ppdfilename, 00666);
	fclose(listppdfile);
	return iLableCount;
}


int Lookup_Lable(const char* ppdfilename, const char* Lable_Name, char* Lable_ID)
{
	char lpString[_BUF_SIZE_];

	FILE* ppdfile = fopen(ppdfilename, "r");
	if(ppdfile == NULL)
	{
		return -1;
	}

	while(fread_line_string(lpString, ppdfile) > 0)
	{
		if( strncmp(_PAGESIZE_HEAD_, lpString, strlen(_PAGESIZE_HEAD_)) == 0 )
		{
			char *ptr = strstr(lpString, _LABLE_ID_HEAD_);
			if(ptr != NULL)
			{
				// get lable name length
				char lp[100] = {0};
				int iStrLen;
				memcpy(lp, ptr + strlen(_LABLE_ID_HEAD_), 2);
				lp[2] = 0;
				sscanf(lp, "%X", &iStrLen);
//				printf("Length = %d\n", iStrLen);

				// get lable name string
				memcpy(lp, ptr + 16, iStrLen);
				lp[iStrLen] = 0;

				if(strcmp(lp, Lable_Name) == 0 )
				{
					// get lable name ID
					memcpy(Lable_ID, ptr, 15);
					Lable_ID[15] = 0;
					fclose(ppdfile);
					return 1;
				}
			}
		}
	}

	fclose(ppdfile);
	return 0;
}
//
// fread_line_string(char *ptr, FILE *stream)
//
size_t fread_line_string(char *ptr, FILE *stream)
{
	size_t count = 0;
	while(fread(ptr + count, 1, 1, stream) > 0)
	{
		if(*(ptr + count) == '\n')
		{
			count++;
			break;
		}
		count++;
	}
	ptr[count] = 0;
	return count;
}

//
// fwrite_line_string(char *lpString, size_t length, FILE *stream)
//
size_t fwrite_line_string(const char *lpString, size_t length, FILE *stream)
{
	const char *ptr = lpString;

	int iw = 0, ir = length;
	while(ir > 0)
	{
		iw = fwrite(ptr, 1, ir, stream);
		ir -= iw;
		ptr += iw;
	}

	return length;
}

//
// SetConstraints(FILE* ppdfile, long lHeight_mm)
//
int SetConstraints(FILE* ppdfile, const char* LableID, long lHeight_mm)
{
	char lpString[_BUF_SIZE_];
	long lLow = (long)((lHeight_mm + 1) / 2.0);
	lLow = (lLow < _MIN_FEED_VALUE_) ?  _MIN_FEED_VALUE_ : lLow;

	for( ;lLow <= _MAX_FEED_VALUE_; lLow++)
	{
		sprintf(lpString, _CONSTRAINTS_FORMAT_, lLow, LableID);
		fwrite_line_string(lpString, strlen(lpString), ppdfile);
	}

	return 0;
}
//
//	return	-1: error;
//			1: Not found lable name
//			0: OK
//
int RemoveLable(TParam param)
{
	FILE* oldfile, *newfile;
	char lpTempFile[_BUF_SIZE_];
	char lpBuf[_BUF_SIZE_];
	char Label_ID[100];
	int ir;

       if(Lookup_Lable(param.PPDFileName, param.LabelName, Label_ID) == 0)
       {
//		printf("Not found '%s'\n", param.LabelName);
		return 1;
	}


	oldfile = fopen(param.PPDFileName, "r");
	if(oldfile == NULL)
	{
		return -1;
	}

	sprintf(lpTempFile, "%s.$$$", param.PPDFileName);
	newfile = fopen(lpTempFile, "w");
	if(newfile == NULL)
	{
		fclose(oldfile);
		return -1;
	}

//	int iImageAreaWrited = 0, iPaperDimensionWrited = 0;
	while((ir = fread_line_string(lpBuf, oldfile)) > 0)
	{

		if(strstr(lpBuf, Label_ID) != NULL)
		{
			if(strstr(lpBuf, _DEFAULT_PAGESIZE_) != NULL)
			{
				sprintf(lpBuf, "%s\t29x90\n", _DEFAULT_PAGESIZE_);
				fwrite_line_string(lpBuf, strlen(lpBuf), newfile);
			}
			else if(strstr(lpBuf, _DEFAULT_PAGEREGION_) != NULL)
			{
				sprintf(lpBuf, "%s\t29x90\n", _DEFAULT_PAGEREGION_);
				fwrite_line_string(lpBuf, strlen(lpBuf), newfile);
			}
			else if(strstr(lpBuf, _DEFAULT_IMAGEAREA_) != NULL)
			{
				sprintf(lpBuf, "%s\t29x90\n", _DEFAULT_IMAGEAREA_);
				fwrite_line_string(lpBuf, strlen(lpBuf), newfile);
			}
			else if(strstr(lpBuf, _DEFAULT_PAPERDIMENSION_) != NULL)
			{
				sprintf(lpBuf, "%s\t29x90\n", _DEFAULT_PAPERDIMENSION_);
				fwrite_line_string(lpBuf, strlen(lpBuf), newfile);
			}
			continue;
		}
		fwrite_line_string(lpBuf, ir, newfile);
	}

       fclose(oldfile);
       fclose(newfile);
       remove(param.PPDFileName);
       rename(lpTempFile, param.PPDFileName);
	chmod(param.PPDFileName, 00666);

	return 0;
}

//
// AddLable(TParam param)
//
int AddLable(TParam param)
{
	FILE* oldfile, *newfile;
	char lpTempFile[_BUF_SIZE_];
	char lpString[_BUF_SIZE_];
	char lpBuf[_BUF_SIZE_];
	char Label_ID[100];
	int ir;
	
	int line_count = 0;
	int iImageAreaWrited = 0, iPaperDimensionWrited = 0;

	if(strlen(param.LabelID) == 0)
	{
		struct timeval tv;
		struct timezone tz;
		gettimeofday(&tv, &tz);
		sprintf(Label_ID, "%s%02X%02X%03X%01X%04X",
				_LABLE_ID_HEAD_,
				strlen(param.LabelName),
				param.lW_mm,
				(param.lH_mm & 0x0FFF),
				(tv.tv_sec & 0x0F),
				(tv.tv_usec & 0xFFFF));
	}
	else
	{
		sprintf(Label_ID, "%s", param.LabelID);
	}

//	printf("Label_ID=%s\n", Label_ID);

	oldfile = fopen(param.PPDFileName, "r");
	if(oldfile == NULL)
	{
		return -1;
	}

	sprintf(lpTempFile, "%s.$$$", param.PPDFileName);
	newfile = fopen(lpTempFile, "w");
	if(newfile == NULL)
	{
		fclose(oldfile);
		return -1;
	}

	while((ir = fread_line_string(lpString, oldfile)) > 0)
	{
		if(strncmp ( _CLOSEUI_PAGESIZE_, lpString, strlen(_CLOSEUI_PAGESIZE_)) == 0)
		{
//				printf("(%s) Found line %d\n", _CLOSEUI_PAGESIZE_, line_count);
			sprintf(lpBuf,
				_PAGESIZE_FORMAT_,
				Label_ID,
				param.LabelName,
				((double)param.lW_mm / _MM_TO_INCH_) * 72.0,
				((double)param.lH_mm / _MM_TO_INCH_) * 72.0);
			fwrite_line_string(lpBuf, strlen(lpBuf), newfile);
//			printf("(%s)\n", lpBuf);
		}
		else if(strncmp ( _CLOSEUI_PAGEREGION_, lpString, strlen(_CLOSEUI_PAGEREGION_)) == 0)
		{
//				printf("(%s) Found line %d\n", _CLOSEUI_PAGEREGION_, line_count);
			sprintf(lpBuf,
				_PAGEREGION_FORMAT_,
				Label_ID,
				param.LabelName,
				((double)param.lW_mm / _MM_TO_INCH_) * 72.0,
				((double)param.lH_mm / _MM_TO_INCH_) * 72.0);
			fwrite_line_string(lpBuf, strlen(lpBuf), newfile);
		}
		else if( ( iImageAreaWrited == 0 ) && strncmp ( _IMAGEABLEAREA_, lpString, strlen(_IMAGEABLEAREA_)) == 0)
		{
			iImageAreaWrited = 1;
			if(param.lW_mm == 54)
			{
			sprintf(lpBuf,
					_IMAGEABLEAREA_FORMAT_,
					Label_ID,
					param.LabelName,
				    5.76, 8.4,
				    ((double)param.lW_mm / _MM_TO_INCH_) * 72.0 - 5.76,
				    ((double)param.lH_mm / _MM_TO_INCH_) * 72.0 - 8.4);
			}else{
			sprintf(lpBuf,
				_IMAGEABLEAREA_FORMAT_,
				Label_ID,
				param.LabelName,
				4.32, 8.4,
				((double)param.lW_mm / _MM_TO_INCH_) * 72.0 - 4.32,
				((double)param.lH_mm / _MM_TO_INCH_) * 72.0 - 8.4);
			}
			fwrite_line_string(lpBuf, strlen(lpBuf), newfile);
		}
		else if( ( iPaperDimensionWrited == 0) && strncmp ( _PAPERDIMENSION_, lpString, strlen(_PAPERDIMENSION_)) == 0)
		{
			iPaperDimensionWrited = 1;
			sprintf(lpBuf,
				_PAPERDIMENSION_FORMAT_,
				Label_ID,
				param.LabelName,
				((double)param.lW_mm / _MM_TO_INCH_) * 72.0,
				((double)param.lH_mm / _MM_TO_INCH_) * 72.0);
			fwrite_line_string(lpBuf, strlen(lpBuf), newfile);
		}
		fwrite_line_string(lpString, ir, newfile);
		line_count++;
	}

       fclose(oldfile);
//       printf("Label_ID=%s\n", Label_ID);
       SetConstraints(newfile, Label_ID, param.lH_mm);

       fclose(newfile);
	remove(param.PPDFileName);
       rename(lpTempFile, param.PPDFileName);
	chmod(param.PPDFileName, 00666);

	return 0;
}

//
// main( int argc, char** argv)
//
int main( int argc, char** argv)
{
	int IsOK = 1;
	int iflag[_CMD_COUNT_] = {0};
	TParam param;
	int i;

	memset(iflag, 0, _CMD_COUNT_ * sizeof(int));
	memset(&param, 0, sizeof(TParam));

	if(argc % 2 == 0)
	{
		IsOK = 0;
	}

	for(i = 1; (i + 1) < argc && IsOK == 1; i += 2)
	{
//		printf("argv[%d] = %s, argv[%d] = %s\n", i, argv[i], i+1, argv[i+1]);
		if( strncmp( argv[i], _CMD_PRINTER_, strlen(_CMD_PRINTER_)) == 0)
		{
			if( strlen(argv[i + 1]) > _BUF_SIZE_  || strlen(argv[i + 1]) <= 0 )
			{
				IsOK = 0;
				break;
			}
               	sprintf(param.PPDFileName, _PPD_CUPS_FORMAT_, argv[i + 1]);
                	iflag[_P_ID] = 1;
		}
		else if( strncmp( argv[i], _CMD_ADD_LABEL_, strlen(_CMD_ADD_LABEL_)) == 0)
		{
			if( strlen(argv[i + 1]) > _LABEL_MAX_  || strlen(argv[i + 1]) <= 0 )
			{
				IsOK = 0;
				break;
			}
               	memcpy(param.LabelName, argv[i + 1], strlen(argv[i + 1]));

			iflag[_n_ID] = 1;
//			param.IsAdd = 1;
		}
		else if( strncmp( argv[i], _CMD_DEL_LABEL_, strlen(_CMD_DEL_LABEL_)) == 0)
		{
			if( strlen(argv[i + 1]) > _LABEL_MAX_  || strlen(argv[i + 1]) <= 0 )
			{
				IsOK = 0;
				break;
			}
               	memcpy(param.LabelName, argv[i + 1], strlen(argv[i + 1]));

			iflag[_d_ID] = 1;
		}
		else if( strncmp( argv[i], _CMD_WIDTH_, strlen(_CMD_WIDTH_)) == 0)
		{
			if( strlen(argv[i + 1]) > _LABEL_MAX_  || strlen(argv[i + 1]) <= 0 )
			{
				IsOK = 0;
				break;
			}
			if( (param.lW_mm = atol(argv[i + 1])) <= 0 )
			{
				IsOK = 0;
				break;
			}
			iflag[_w_ID] = 1;
		}
		else if( strncmp( argv[i], _CMD_HEIGHT_, strlen(_CMD_HEIGHT_)) == 0)
		{
			if( strlen(argv[i + 1]) > _LABEL_MAX_  || strlen(argv[i + 1]) <= 0 )
			{
				IsOK = 0;
				break;
			}
			if( (param.lH_mm = atol(argv[i + 1])) <= 0 )
			{
				IsOK = 0;
				break;
			}
			iflag[_h_ID] = 1;
		}
		else if( strncmp( argv[i], _CMD_LABEL_ID_, strlen(_CMD_LABEL_ID_)) == 0)
		{
			if( strlen(argv[i + 1]) > _LABEL_MAX_  || strlen(argv[i + 1]) <= 0 )
			{
				IsOK = 0;
				break;
			}
               	memcpy(param.LabelID, argv[i + 1], strlen(argv[i + 1]));
		}
		else if( strncmp( argv[i], _CMD_SHOW_INFO_, strlen(_CMD_SHOW_INFO_)) == 0)
		{
			if( strlen(argv[i + 1]) > _LABEL_MAX_  || strlen(argv[i + 1]) <= 0 )
			{
				IsOK = 0;
				break;
			}
			g_show = atol(argv[i + 1]);
		}
		else
		{
			IsOK = 0;
			break;
		}
	}


//       printf("-P (%d), -n (%d), -d (%d), -w (%d), -h(%d)\n", iflag[0], iflag[1], iflag[2], iflag[3], iflag[4] );
//       printf("-P (%s), -n (%s), -d (%s), -w (%d), -h(%d)\n", param.PPDFileName, param.LabelName, param.LabelName, param.lW_mm, param.lH_mm);
#ifdef _UI_
       if( !IsOK || iflag[_P_ID] == 0 || (iflag[_n_ID] == 1 && iflag[_d_ID] == 1) || (iflag[_n_ID] == 1 && (!iflag[_w_ID] || !iflag[_h_ID])))
#else
       if( !IsOK || iflag[_P_ID] == 0 || (iflag[_n_ID] == 1 && iflag[_d_ID] == 1) || (iflag[_n_ID] == 1 && (!iflag[_w_ID] || !iflag[_h_ID])) || ((iflag[_n_ID] | iflag[_d_ID]) == 0))
#endif       
       {
		IsOK = 0;
	}


	if( IsOK == 0 )
	{
		DisplayHelp();
		return 0;
	}

// 	printf("pid = %d\n", getpid());
//	sleep(300);


#ifdef _UI_
	if( iflag[_n_ID] == 0 && iflag[_d_ID] == 0)
	{
              int iR;
		if((iR = List_Lable(param.PPDFileName)) > 0)
		{
			if(g_show)
				printf("Please check \"%s.list\"\n", param.PPDFileName);
		}
		else
		{
			if( iR < 0)
			{
				if(g_show)
					printf("%s\n", strerror(errno));
			}
		}
			
		return 0;
	}
#endif
	if( iflag[_d_ID] == 1)
	{
		int iR = RemoveLable(param);
		if( iR == -1 )
		{
			if(g_show)
				printf("%s\n", strerror(errno));
			return 1;
		}

		if( iR == 1)
		{
//			if(g_show)
//				printf("Not found '%s'\n", param.LabelName);
		}

		return 0;
	}

	if( iflag[_n_ID] == 1)
	{
		if(RemoveLable(param) == -1)
		{
			if(g_show)
				printf("%s\n", strerror(errno));
			return 1;
		}

		if(AddLable(param) == -1)
		{                                                         
			if(g_show)
				printf("%s\n", strerror(errno));
			return 1;
		}
		return 0;
	}
	
//	printf("OK!!\n");	
	return 0;
}
