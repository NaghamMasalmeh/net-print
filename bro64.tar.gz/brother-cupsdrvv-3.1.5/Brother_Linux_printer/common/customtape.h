#ifndef _CUSTOM_TAPE_H_
#define _CUSTOM_TAPE_H_

#include <string.h>

#define _LABEL_BUF_MAX_ 	33
#define _LABEL_MAX_ 	(_LABEL_BUF_MAX_ - 1)
#define _LABLE_ID_HEAD_				"BrL"

typedef struct
{
	char tape_name[_LABEL_BUF_MAX_];
	char tape_id[_LABEL_BUF_MAX_];
} TapeItem, *TTapeItem;
typedef struct
{
	TTapeItem tapelist;
	int count;
	int iSelIndex;
}TapeList, *TTapeList;


int add_tape(TTapeList ptapelist, const char* plabelname, const char* plabel_id);
int GetLabel_name_id(const char* lpString, char* lpName, char* lpID);
#endif
