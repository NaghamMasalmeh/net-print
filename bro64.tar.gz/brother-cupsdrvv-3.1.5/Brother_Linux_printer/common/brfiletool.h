/* $Id: brfiletool.h,v 1.2 2005/06/21 11:49:59 cvs Exp $ */

/* 
* Copyright (C) 2003-2013 Brother. Industries, Ltd.
*
* This program is free software; you can redistribute it and/or modify it
* under the terms of the GNU General Public License as published by the Free
* Software Foundation; either version 2 of the License, or (at your option)
* any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
* more details.
*
* You should have received a copy of the GNU General Public License along with
* this program; if not, write to the Free Software Foundation, Inc., 59 Temple
* Place, Suite 330, Boston, MA  02111-1307  USA
*
* In addition, as a special exception, Brother Industries, Ltd. gives
* permission to link the code of this program with certain libraries covered
* by BROTHER PRINTER DRIVER SOFTWARE PUBLIC LICENSE AGREEMENT, and distribute
* linked combinations including the two.  You must obey the GNU General Public
* License in all respects for all of the code used other than the libraries as
* stipulated in the above.  If you modify this file, you may extend this
* exception to your version of the file, but you are not obligated to do so.
* If you do not wish to do so, delete this exception statement from your
* version.
*/

#ifndef __BR_FILE_TOOL_H__
#define __BR_FILE_TOOL_H__

#include "brresource.h"


#define LINE_BUFFER		(1024)
#define A_VALUE_BUF   (128 )


extern	char *	ReadLine( char *pszLine, int nSize, FILE *pFile );
extern	char *	EraseSpace( char *pszLine );
extern	int		ParamSearch( const char *pszLine, char *pszValue );
extern	int		CommandSearch( const char *pszCommand );
extern	int		LoadRcFile( char *pszFilename, BR_RESOURCE_INFO *pRcInfo);
extern	int		SetNumericalParam( int nIndex, char *pszValue, BR_RESOURCE_INFO *pRcInfo, int fValidCheck );
extern	int		SetSelectionParam( int nIndex, char *pszValue, BR_RESOURCE_INFO *pRcInfo, int fValidCheck );
extern	int		SetIndicatedCmdParam( int nIndex, char *pszValue, BR_RESOURCE_INFO *pRcInfo );
extern	short	GetPjpInnerValue( int nIndex, BR_RESOURCE_INFO *pRcInfo );
extern	short	GetParamItemValue( int nIndex, BR_RESOURCE_INFO *pRcInfo , char * pszBuf , int nSize );
extern	BR_PARAM_TYPE	GetParamType( int nIndex, BR_RESOURCE_INFO *pRcInfo );
extern  short IsItemHit(BR_PARAM_TYPE type , char * pszItem , char * pszValues) ;

#ifdef  BR_CONSTRAINT               /* Added by Chenxujin , SteadyBJ , 2004.11.18 */
extern void AddConstraint(char * pszLine , BR_RESOURCE_INFO * pRcInfo );
extern void FreeConstraint( BR_RESOURCE_INFO * pRcInfo ) ;
#endif  /* BR_CONSTRAINT */
#endif
