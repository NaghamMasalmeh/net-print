/*=================================================================================*
*FileName:     	compress.h
*Description:	variable and function declarations for source line data and compression
*Revision:     	1.0									
*Date:         	2003.08.28							
*Author:       	Chenxujin , SteadyBJ 									
*Histroy:      	1.Chenxujin , Create
*==================================================================================*/
#ifndef _COMPRESS_H_
#define	_COMPRESS_H_

#include "pd.h"

#ifdef _cplusplus
extern "C" {
#endif/*_cplusplus*/

extern	MODE9		compData ;
extern	unsigned char *	Planes[ ]  ;

extern	short	CreateCompressBuf( pt_model model , unsigned long lSourceLen , unsigned long lSourceHeight ) ;
extern	void	DestroyCompressBuf() ;

extern	short	CreateLineBuf( unsigned long lBytesPerLine , int iNumPlane ) ;
extern	void	DestroyLineBuf() ;

#ifdef SEND_BAND
extern	short	CreateBandBuf( unsigned long lBytesPerLine, short line );
extern	void	DestroyBandBuf();
#endif
#ifdef _cplusplus
}
#endif/*_cplusplus*/

#endif	/*_COMPRESS_H_*/

