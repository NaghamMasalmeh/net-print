/*=================================================================================*
*FileName:     	halftone.h
*Description:	halftone processing
*Revision:     	1.0									
*Date:         	2003.08.28							
*Author:       	Chenxujin , SteadyBJ 									
*Histroy:      	1.Chenxujin , Create
*==================================================================================*/
#ifndef _HALFTONE_H_
#define _HALFTONE_H_

//#include <cups/cups.h>
//#include <cups/raster.h>
#include "pd.h"

#ifdef _cplusplus
extern "C" {
#endif

#define M300		( 8  )
#define M600		( 16 )
#define M1200		( 32 )
	
#define MWidth		( 32 )

#ifdef Dither1200600
extern void Trans2x2to2x1(unsigned char *bmp,  int widthbytes, int height);
#endif

extern	short SetHalftoneMatrix( ppd_file_t *ppd, cups_page_header_t *header );
extern	short HalftonePlane(unsigned char * source , unsigned long sLen , \
							unsigned char * dest , unsigned long * dLen , \
							int iLine , int iPlane	) ;
extern	short	HalftonePixMap( long  bandHeight, unsigned char *bandBuffer, long pageWidth );

#ifdef _cplusplus
}
#endif

#endif/*_HALFTONE_H_*/

