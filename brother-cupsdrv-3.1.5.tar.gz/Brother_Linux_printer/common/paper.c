/* $Id: paper.c,v 1.3 2005/07/28 13:38:30 cvs Exp $ */

/* 
* Copyright (C) 2003 Brother. Industries, Ltd.
*
* This program is free software; you can redistribute it and/or modify it
* under the terms of the GNU General Public License as published by the Free
* Software Foundation; either version 2 of the License, or (at your option)
* any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
* more details.
*
* You should have received a copy of the GNU General Public License along with
* this program; if not, write to the Free Software Foundation, Inc., 59 Temple
* Place, Suite 330, Boston, MA  02111-1307  USA
*/
/*=================================================================================*
*FileName:     	paper.c
*Description:	function for paper selection
*Revision:     	1.0									
*Date:         	2003.08.28							
*Author:       	Chenxujin , SteadyBJ 									
*Histroy:      	1.Chenxujin , Create
*==================================================================================*/
#include "pd.h"
#include"paper.h"
#include "models.h"

//#include <cups/cups.h>
//#include <cups/raster.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>

typedef struct osxp{
	short	selNum;		
	short	Height;		// 120dpi
	short	Width;		// 120dpi
}OSX_PAPER;


#define PAPER_NUM	12

OSX_PAPER	paperCheckTable[PAPER_NUM] = 
		{
			{DMPAPER_A4,					1403,  991 },	// 0:A4
			{DMPAPER_LETTER,				1320, 1020 },	// 1:Letter
			{DMPAPER_LEGAL,				1680, 1020 },	// 2:Legal
			{DMPAPER_EXECUTIVE,			1260,  870 },	// 3:Executive	<-- 1260, 868 (2002/06/11 M-PCA-6758)
			{DMPAPER_A5,					991,  700 },	// 4:A5											
			{DMPAPER_B5,					1215,  860 },	// 5:JIS B5
			{DMPAPER_ENV_B5,				1181,  831 },	// 6:B5
			{DMPAPER_ENV_10,				1140,  495 },	// 7:Com10
			{DMPAPER_ENV_DL,				1040,  520 },	// 8:DL			<-- 1038, 520 (2002/06/11 M-PCA-6758)
			{DMPAPER_JAPANESE_POSTCARD,	695, 471 },		// 9:Hagaki
			{DMPAPER_JENV_YOU4,			1106, 495 },	// 10:Youkei 4
			{DMPAPER_JENV_CHOU3,			1106, 566 },	// 11:Youkei Max
		};

#ifndef _STDBJ_LINUX_  //zhangshumin, 2005.06.03.
short	checkSendPaper(unsigned char **name, short height, short width, long *offset)
#else
short	checkSendPaper(short height, short width)
#endif
{
	short	i;
	short	ret = DMPAPER_USERP;	//set Legal as default

	for (i=0; i < PAPER_NUM; i++){
		if ((height == paperCheckTable[i].Height) && (width == paperCheckTable[i].Width)){

			ret = paperCheckTable[i].selNum;	/* bigger & nearest size */
			return ret;
		}
	}

	return ret;
}

