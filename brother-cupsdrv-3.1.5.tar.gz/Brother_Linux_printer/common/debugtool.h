/* $Id: debugtool.h,v 1.2 2005/06/21 11:49:59 cvs Exp $ */

/* 
* Copyright (C) 2003 Brother. Industries, Ltd.
*
* This program is free software; you can redistribute it and/or modify it
* under the terms of the GNU General Public License as published by the Free
* Software Foundation; either version 2 of the License, or (at your option)
* any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
* more details.
*
* You should have received a copy of the GNU General Public License along with
* this program; if not, write to the Free Software Foundation, Inc., 59 Temple
* Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef __DEBUG_TOOL_H__
#define __DEBUG_TOOL_H__


#ifdef LOCAL_DEBUG
	#define	DEBUG_LOG_NAME	"debuglog.txt"
#else
	#define	DEBUG_LOG_NAME	"/tmp/brinkjet_lprng_debuglog.txt"
#endif

#if 0
	#define	LOG_ENABLE
#endif



#ifdef LOG_ENABLE
	#define	DEBUGPRINT			Debug_printf
	#define	DEBUGDUMP			Debug_dump
#else
	#define	DEBUGPRINT			Debug_dummy
	#define	DEBUGDUMP(a,b,c)
#endif


extern	int		Debug_dummy( char *, ... );
extern	int		Debug_printf( char *, ... );

#endif
