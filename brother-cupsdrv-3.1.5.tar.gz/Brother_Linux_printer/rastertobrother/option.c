
#include "pd.h"
#include "option.h"

#define _LPRNG_STD_
#define _LPR_

int 			num_options ;
cups_option_t	*options ;
ppd_file_t *	thisPPD = NULL ;

void	SetThisPPD( ppd_file_t * ppd ) ;
void 	ParseOptions( const char * argv5 ) ;
void 	FreeOptions() ;
const char * GetOption( const char * name ) ;
int CheckOptionValue( const char * option , const char * value ) ;

#ifdef _LPRNG_STD_		// 2005.12.12 Liu Bin
#include "brresource.h"

#endif

/*-------------------------------------------------------------------------------------
*Name 		: SetThisPPD
*Description 	: Set PPD file struct pointer for this queue
*Parameters 	:
*	ppd			: PPD file pointer
*Precondition	: N/A
*Operation		: Set ppd
*Postcondition 	: N/A
*Return 		: N/A
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2005.06.17
*--------------------------------------------------------------------------------------*/
void	SetThisPPD( ppd_file_t * ppd )
{
	thisPPD = ppd ;
}

/*-------------------------------------------------------------------------------------
*Name 		: ParseOptions
*Description 	: Parse all options
*Parameters 	:
*	argv5	: argv[ 5 ] of the main parameters
*Precondition	: argv5 != NULL
*Operation 	: Parse all options
*Postcondition 	: Options are parsed
*Return 		: N/A
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/
void 	ParseOptions( const char * argv5 )
{
	num_options 	= 0 ;
	options 		= NULL ;
#ifndef _LPR_
	num_options	= cupsParseOptions( argv5 , num_options , &options ) ;
#endif
}

/*-------------------------------------------------------------------------------------
*Name 		: FreeOptions
*Description 	: Free all options
*Parameters 	: N/A
*Precondition	: Options were parsed
*Operation 	: Free all options
*Postcondition 	: Options are freed
*Return 		: N/A
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/
void 	FreeOptions()
{
#ifndef _LPR_
	cupsFreeOptions( num_options , options ) ;
#endif
	thisPPD = NULL ;
}

/*-------------------------------------------------------------------------------------
*Name 		: GetOption
*Description 	: Get an option
*Parameters 	: N/A
*	name		: option name
*Precondition	: Options were parsed
*Operation 	: Get option value
*Postcondition 	: option value is returned
*Return 		: option value
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/
const char * GetOption( const char * name )
{
	const char * pstrValue = NULL ;

	if( NULL == name ){
		return pstrValue ;
	}

	/* Search in option parameters */
#ifndef _LPR_
	pstrValue = cupsGetOption( name , num_options , options ) ;
#endif

	/* Search in PPD file for default value */
	if( NULL == pstrValue && thisPPD != NULL ){
		ppd_option_t *option = NULL;
#ifndef _LPR_
		option = ppdFindOption( thisPPD , name ) ;
#endif
		if( NULL != option && option->num_choices > 0 ){
			pstrValue = &(option->defchoice[0]);
		}
	}

	return pstrValue ;
}

/*-------------------------------------------------------------------------------------
*Name 		: CheckOptionValue
*Description 	: Check the selected value of a option
*Parameters 	: N/A
*	option		: option name
*	value		: specific value
*Precondition	: Options were parsed
*Operation		: compare the selected value with the specific value
*Postcondition 	: N/A
*Return 		: < 0 , option not supported
				  = 0 , selected value is not the specific value
				  > 0 , selecetd value is the specific value
*History 		: 1.Created , by Chenxujin , SteadyBJ , 2005.05.14
*--------------------------------------------------------------------------------------*/
int CheckOptionValue( const char * option , const char * value )
{
	int iRet = 0 ;
	const char * pstrVal = NULL ;

	if( NULL == option || NULL == value ){
		return 0 ;
	}

	pstrVal = GetOption( option ) ;

	if( NULL == pstrVal ){		/* option not supported */
		return iRet ;
	}

	if( 0 == strcmp(pstrVal , value ) ){
		iRet = 1 ;		/* value is selected */
	}else{
		iRet = 0 ;		/* value is NOT selected */
	}

	return iRet ;
}

#ifndef _LPRNG_STD_
int GetOptionValue( const char * name , char* lpValue)
{
	int i = 0;
	for(i = 0; i < g_rcInfo.nParamNum; i++)
	{
/*		if( strncmp(, lpString, strlen(_PAGESIZE_HEAD_)) == 0 )
		{
			char *ptr = strstr(lpString, _LABLE_ID_HEAD_);
			if(ptr != NULL)
			{
				// get lable name length
				char lp[100] = {0};
				memcpy(lp, ptr + strlen(_LABLE_ID_HEAD_), 2);
				lp[2] = 0;
				int iStrLen;
				sscanf(lp, "%X", &iStrLen);
//				printf("Length = %d\n", iStrLen);

				// get lable name string
				memcpy(lp, ptr + 16, iStrLen);
				lp[iStrLen] = 0;

//				printf("%s", lp);
				sprintf(lpBuf, "%s\n", lp);
				fwrite_line_string(lpBuf, strlen(lpBuf), listppdfile);

				// get width
				memcpy(lp, ptr + strlen(_LABLE_ID_HEAD_) + 2, 2);
				lp[2] = 0;
				sscanf(lp, "%X", &iStrLen);
//				printf(" [%d, ", iStrLen);
                            sprintf(lpBuf, "%d\n", iStrLen);
				fwrite_line_string(lpBuf, strlen(lpBuf), listppdfile);

				// get height
				memcpy(lp, ptr + strlen(_LABLE_ID_HEAD_) + 4, 3);
				lp[3] = 0;
				sscanf(lp, "%X", &iStrLen);
//				printf("%d]\n", iStrLen);
                            sprintf(lpBuf, "%d\n", iStrLen);
				fwrite_line_string(lpBuf, strlen(lpBuf), listppdfile);

				iLableCount++;
			}
		}
*/
	}


}
#endif
