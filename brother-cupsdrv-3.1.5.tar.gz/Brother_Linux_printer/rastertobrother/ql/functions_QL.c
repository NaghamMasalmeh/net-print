/*=================================================================================*
*FileName:     	model_1030. c
*Description:	model functions for 1030
*Revision:     	1.0									
*Date:         	2003.08.28							
*Author:       	Chenxujin , SteadyBJ 									
*Histroy:      	1.Chenxujin , Create
*==================================================================================*/

#define _LPR_
#ifndef _LPR_
//#include <cups/cups.h>
//#include <cups/raster.h>
#endif

#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <unistd.h> 
#include <string.h>


#include"../pd.h"
#include"functions_QL.h"
#include "../paper.h"
#include "../brcommon.h"
//#include "compress.h"
#include "../send.h"
//#include "../halftone.h"
#include "../Models.h"
//#include "../option.h"
#include "command.h"
#include "../Message.h"
#include "../coloreffect.h"
#include "../dither.h"


#include "define.h"
extern TJobData g_jobdata;
#ifdef _LPR_
short	MBeginJob_QL(	LPPTPARAM sParam );
short	MBeginPage_QL(	int iPage ) ;
#else
short	MBeginJob_QL(	cups_page_header_t * header , LPPTPARAM sParam );
short	MBeginPage_QL(	cups_page_header_t *		header , int iPage ) ;
#endif
short	MEndJob_QL(	) ;
short	MEndPage_QL( short sLastPage ) ;
short	MSendBand_QL( LPPTPARAM sParam ) ;
short	MSendData_QL( send_buffer * send_buf					) ;					
void	CompressM9_QL( /*MODE9 * compData , cups_page_header_t *	header */ ) ;
void	CompressALineTIFF( unsigned char * buf , long * plen );
/*
*Function table functions
*/
extern	MFUNTABLE	fun_table ;

short	SetFunctionTable() ;
short	ValidateFunctionTable() ;
void ResetFunctionTable() ;


#define _LINUX_STD_

#if	1	// Modified by SteadyBJ, Liu Bin, 2006.09.18
	// Necessary to move 35 dots in printing 12 dia
#define	DOTS_35	(35)
#endif

/*-------------------------------------------------------------------------------------
*Name 		: MBeginJob_1030
*Description 	: Initialize the printer for a new job
*Parameters 	: 
*	header	: page header
*Precondition	: header != NULL
*Operation 	: Set initialization commands to the printer
*Postcondition 	: the printer is initialized.
*Return 	:
*		0 	: Succeeded ; otherwise , Failed.
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
				2. Modified , by Liu Bin SteadyBJ, 2005.11.15
*--------------------------------------------------------------------------------------*/
#ifdef _LPR_
short	MBeginJob_QL(	LPPTPARAM sParam )
#else
short	MBeginJob_QL(	cups_page_header_t * header , LPPTPARAM sParam )
#endif
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	short	sRet = 1 ;
	int		iVal ;
	char   fileName[500]="";

#ifdef _LINUX_STD_
	FILE* fp_page_header ;

	// if g_jobdata.pInitfile is NULL, it necessary to return 0;	2005.11.15 Liu Bin
	if(g_jobdata.pInitfile == NULL)
	{
		return 0;
	}
#endif
//modify
#ifdef NO_QL800
  	sprintf(fileName,_PAPER_NAMEBADGE_,sParam->pszNamePrinter);
#endif //

// 	Debug_printf("******************tape id found  %s *********************** \n",sParam->pTape->ID);

/* Begin Job commands */
#ifdef _LINUX_STD_
	if(g_jobdata.pInitfile != NULL)
	{
#endif	
//#S1
		//if( CheckModel( USE_MODESWITCH_PREC ) ){
/*Send 400bytes of blank data--QL800NW*/
#ifdef _LINUX_STD_
		if(fwrite(kQLCmdBlank, sizeof(kQLCmdBlank), 1, g_jobdata.pInitfile) < 1){
#else
		if(fwrite(kQLCmdBlank, sizeof(kQLCmdBlank), 1, stdout) < 1){
#endif
			fprintf(stderr, "ERROR: Send command failed.\n");
			return sRet; 
		}	
/*......Send 400bytes of blank data--QL800NW*/
		//}

#ifdef	NO_QL800
		//name badge coding
		FILE * fp_namebadg;
//		  Debug_printf("******************tape id found  %s *********************** \n",sParam->pTape->ID);
		if( strcmp(sParam->pTape->ID, "60x86") == 0)
		{
//		   Debug_printf("******************file not found  %s *********************** \n",_PAPER_NAMEBADGE_);
//		  if((fp_namebadg = fopen(_PAPER_NAMEBADGE_,"rb"))==NULL){
		  if((fp_namebadg = fopen(fileName,"rb"))==NULL){
			Debug_printf("******************Error file not found*********************** \n");
		  }else{
			char buff[500]="";
			unsigned int ReadLen = 499;
			ReadLen=fread(buff,sizeof(char),ReadLen,fp_namebadg);
//			Debug_printf("******************File size %d ***********************\n",ReadLen);
			fclose(fp_namebadg);
			if( fwrite( buff , ReadLen , 1 , g_jobdata.pInitfile ) < 1 ){
				Debug_printf("******************File size %d ***********************\n",ReadLen);
				fprintf(stderr , "ERROR: Send command failed.\n" ) ;
				return sRet ;
			}
		  }
		}
#endif	//NO_QL800

		/* Initialize */
#ifdef _LINUX_STD_
		if( fwrite( kQLCmdInitialize , sizeof(kQLCmdInitialize) , 1 , g_jobdata.pInitfile ) < 1 ){
#else	
		if( fwrite( kQLCmdInitialize , sizeof(kQLCmdInitialize) , 1 , stdout ) < 1 ){
#endif
			fprintf(stderr , "ERROR: Send command failed.\n" ) ;
			return sRet ;
		}
#ifdef _LINUX_STD_
	}
#endif		
	
		// Command mode switch 
		if( CheckModel( USE_MODESWITCH_PREC ) ){
#ifdef _LINUX_STD_
			if( fwrite( kQLCmdSwitchDefault , sizeof(kQLCmdSwitchDefault) , 1 , g_jobdata.pInitfile ) < 1 ){
#else		
			if( fwrite( kQLCmdSwitchDefault , sizeof(kQLCmdSwitchDefault) , 1 , stdout ) < 1 ){
#endif
				fprintf(stderr , "ERROR: Send command failed.\n" ) ;
				return sRet ;
			}
		}
#if 1
//QL-800 add command 
		/* status Initialize */
#ifdef _LINUX_STD_
		if( fwrite( kQLCmdstatus , sizeof(kQLCmdstatus) , 1 , g_jobdata.pInitfile ) < 1 ){
#else	
		if( fwrite( kQLCmdstatus , sizeof(kQLCmdstatus) , 1 , stdout ) < 1 ){
#endif
			fprintf(stderr , "ERROR: Send command failed.\n" ) ;
			return sRet ;
		}

#endif //0

	/* Print information command */
	ResetCmdPrintInfo( kQLCmdPrintInfo ) ;

#ifdef _LINUX_STD_	// 2005.12.19
/*	Contiuous tape
		PT_KIND	    ON
		PT_WIDTH  ON
		PT_LENGTH OFF
	Die_cut tape (except 12mm Dia)
		PT_KIND	    OFF
		PT_WIDTH  ON
		PT_LENGTH OFF
	12mm Dia
		PT_KIND	    ON
		PT_WIDTH  ON
		PT_LENGTH ON
*/
	SetCmdPrintInfoPaperType( kQLCmdPrintInfo , (sParam->pTape->ubTapeType) );	/* Kind */
	if( sParam->pTape->ubTapeType == PT_CONTINUOUS)
	{
		SetCmdPrintInfoFlag( kQLCmdPrintInfo , (PI_RECOVER|PI_KIND|PI_WIDTH) ); // 0x86
	}
	else if( strcmp(sParam->pTape->ID, "12Dia") == 0)
	{
		SetCmdPrintInfoFlag( kQLCmdPrintInfo , (PI_RECOVER | PI_KIND | PI_WIDTH | PI_LENGTH) ); // 0x8E
	}
	else
	{
		SetCmdPrintInfoFlag( kQLCmdPrintInfo , (PI_RECOVER | PI_WIDTH) );	// 0x84
	}

#else
	SetCmdPrintInfoFlag( kQLCmdPrintInfo , (PI_RECOVER|PI_KIND|PI_WIDTH) );
#endif	
	
	SetCmdPrintInfoPaperWidth( kQLCmdPrintInfo , (sParam->pTape->ubWidthMM) );
	
	if( sParam->pTape->ubTapeType == DIE_CUT_LABEL ){
//		SetCmdPrintInfoFlag( kQLCmdPrintInfo , (PI_LENGTH) );		// removed by liu bin 2006.1.27
		SetCmdPrintInfoPaperLength( kQLCmdPrintInfo , (sParam->pTape->ubLengthMM) );
	}
	
	/* Print Priority */
	if( sParam->sPriority ){
		SetCmdPrintInfoFlag( kQLCmdPrintInfo , (PI_QUALITY) );
	}

	/* Raster Number */
#ifdef _MY_DEBUG_
	fprintf(stderr, "ERROR: sParam->sDestHeight = %d\n", sParam->sDestHeight);
#endif

#if	1	// Modified by SteadyBJ, Liu Bin, 2006.09.18
	// Necessary to move 35 dots in printing 12 dia
//	fprintf( stderr, "ERROR:1-Tape=%s, Printer=%s\n", sParam->pTape->ID, sParam->PTName);
	if(    (strcmp(sParam->pTape->ID, "12Dia") == 0)
//	 	&& ( strcmp(sParam->PTName, "ql500") == 0 || strcmp(sParam->PTName, "ql550") == 0 )
	)
	{
		SetCmdPrintInfoRasterNumber( kQLCmdPrintInfo , (sParam->sDestHeight + DOTS_35) );
//		fprintf( stderr, "ERROR:Set 35 dots\n");
	}
	else
	{
		SetCmdPrintInfoRasterNumber( kQLCmdPrintInfo , sParam->sDestHeight );
	}
#else
	SetCmdPrintInfoRasterNumber( kQLCmdPrintInfo , sParam->sDestHeight );
#endif	
#ifdef _LINUX_STD_
	if( g_jobdata.page_temp.iPageCount > 0)	
	{
		SetCmdPrintInfoPage( kQLCmdPrintInfo , 1 );	/* Other Page is 1 */
	}
	else
	{
		SetCmdPrintInfoPage( kQLCmdPrintInfo , 0 );	/* First Page is 0 */
	}
#else
	SetCmdPrintInfoPage( kQLCmdPrintInfo , 0 );					/* First Page */
#endif	

#ifdef _LINUX_STD_
	//
	// To store page header information to the temporary file _TEMP_FILE_HEADER_
	// Added by liu bin 2006.3.17
	//

	fp_page_header = fopen(_TEMP_FILE_HEADER_, "wb");
	if( fp_page_header == NULL)
	{
		fprintf(stderr , "ERROR: Send command failed.\n" ) ;
		return sRet;
	}

	if( fwrite( kQLCmdPrintInfo , sizeof(kQLCmdPrintInfo) , 1 , fp_page_header ) < 1 )
	{
		fclose(fp_page_header);
		fprintf(stderr , "ERROR: Send command failed.\n" ) ;
		return sRet;
	}

	if( fwrite( kQLCmdPrintInfo , sizeof(kQLCmdPrintInfo) , 1 , g_jobdata.page_temp.pfile ) < 1 ){
#else
	if( fwrite( kQLCmdPrintInfo , sizeof(kQLCmdPrintInfo) , 1 , stdout ) < 1 ){
#endif
		fclose(fp_page_header);
		remove(_TEMP_FILE_HEADER_);
		fprintf(stderr , "ERROR: Send command failed.\n" ) ;
		return sRet ;
	}

	/* Set each mode */
//	if( sParam->sAutoCut ){
	if(sParam->CutLabel){
#ifdef _LINUX_STD_
		if( fwrite( kQLCmdAutocut_On , sizeof(kQLCmdAutocut_On) , 1 , g_jobdata.page_temp.pfile  ) < 1 ){
#else
		if( fwrite( kQLCmdAutocut_On , sizeof(kQLCmdAutocut_On) , 1 , stdout ) < 1 ){
#endif
			fclose(fp_page_header);
			remove(_TEMP_FILE_HEADER_);
			fprintf(stderr , "ERROR: Send command failed.\n" ) ;
			return sRet ;
		}

		if( fwrite( kQLCmdAutocut_On , sizeof(kQLCmdAutocut_On) , 1 , fp_page_header ) < 1 )
		{
			fclose(fp_page_header);
			remove(_TEMP_FILE_HEADER_);
			fprintf(stderr , "ERROR: Send command failed.\n" ) ;
			return sRet;
		}


	}else{
#ifdef _LINUX_STD_
		if( fwrite( kQLCmdAutocut_Off , sizeof(kQLCmdAutocut_Off),  1 , g_jobdata.page_temp.pfile  ) < 1 ){
#else
		if( fwrite( kQLCmdAutocut_Off , sizeof(kQLCmdAutocut_Off) , 1 , stdout ) < 1 ){
#endif
			fclose(fp_page_header);
			remove(_TEMP_FILE_HEADER_);
			fprintf(stderr , "ERROR: Send command failed.\n" ) ;
			return sRet ;
		}


		if( fwrite( kQLCmdAutocut_Off , sizeof(kQLCmdAutocut_Off) , 1 , fp_page_header ) < 1 )
		{
			fclose(fp_page_header);
			remove(_TEMP_FILE_HEADER_);
			fprintf(stderr , "ERROR: Send command failed.\n" ) ;
			return sRet;
		}

	}


 //Satyam added cut at end for  QL570
        /* Set Cut at the specific the label */
        if( sParam->sCutAtEnd == 1 )
        {
                if( fwrite( kQLCmdCutAtEnd_ON, sizeof(kQLCmdCutAtEnd_ON) , 1 , g_jobdata.page_temp.pfile ) < 1 )
                {
                        fclose(fp_page_header);
                        remove(_TEMP_FILE_HEADER_);
                        fprintf(stderr , "ERROR: Send command failed.\n" ) ;
                        return sRet;
                }
        }
        else
        {
                if( fwrite( kQLCmdCutAtEnd_OFF , sizeof(kQLCmdCutAtEnd_OFF) , 1 , g_jobdata.page_temp.pfile ) < 1 )
                {
                        fclose(fp_page_header);
                        remove(_TEMP_FILE_HEADER_);
                        fprintf(stderr , "ERROR: Send command failed.\n" ) ;
                        return sRet;
                }
        }
//Satyam added for QL570 - Cut Label
	// Set cut at the specific labels
	SetCmdCutLabel(sParam->CutLabel);


//Added to check cutlabel using autocut	

#ifdef _LINUX_STD_
//if(sParam->CutLabel  == 0)
{
  if( fwrite( kQLCmdCutLabel, sizeof(kQLCmdCutLabel) , 1 , g_jobdata.page_temp.pfile ) < 1 )
        {
                fclose(fp_page_header);
                remove(_TEMP_FILE_HEADER_);
                fprintf(stderr , "ERROR: Send command failed.\n" ) ;
                return sRet;
        }
}

//else
//{ 
/*
 if( fwrite( kQLCmdCutLabel, sizeof(kQLCmdCutLabel) , 1 , g_jobdata.page_temp.pfile ) < 1 )
        {
                fclose(fp_page_header);
                remove(_TEMP_FILE_HEADER_);
                fprintf(stderr , "ERROR: Send command failed.\n" ) ;
                return sRet;
        }

*/

//for(kQLCmdCutLabel[3]==1;kQLCmdCutLabel[3]<=30;kQLCmdCutLabel[3]++)
//{
                if( fwrite( kQLCmdAutocut_On , sizeof(kQLCmdAutocut_On) , 1 , g_jobdata.page_temp.pfile  ) < 1 ){
#else
                if( fwrite( kQLCmdAutocut_On , sizeof(kQLCmdAutocut_On) , 1 , stdout ) < 1 ){
#endif
                        fclose(fp_page_header);
                        remove(_TEMP_FILE_HEADER_);
                        fprintf(stderr , "ERROR: Send command failed.\n" ) ;
                        return sRet ;
                }
                                                                                                                             
                if( fwrite( kQLCmdAutocut_On , sizeof(kQLCmdAutocut_On) , 1 , fp_page_header ) < 1 )
                {
                        fclose(fp_page_header);
                        remove(_TEMP_FILE_HEADER_);
                        fprintf(stderr , "ERROR: Send command failed.\n" ) ;
                        return sRet;
                }
//}
/*
//Till here cutlabel using autocut

	if( fwrite( kQLCmdCutLabel, sizeof(kQLCmdCutLabel) , 1 , g_jobdata.page_temp.pfile ) < 1 )
	{
		fclose(fp_page_header);
		remove(_TEMP_FILE_HEADER_);
		fprintf(stderr , "ERROR: Send command failed.\n" ) ;
		return sRet;
	}
*/
//}
	/* Set Margins */

	if( sParam->pTape->ubTapeType == CONTINUOUS_TAPE ){
//#ifdef _LINUX_STD_
//		// To fix Feed value 2005.12.5
//		iVal = 0;
//#else		
		iVal = sParam->sTapeMargin ;
//#endif
	}else{
		iVal = 0 ;/*sParam->pTape->usHeightOffset ;*/
	}

//	Debug_printf("1Margin size = %d \n",sParam->sTapeMargin);
	
//	Debug_printf("Margin size = %d \n",iVal);

	
	SetCmdMargin( kQLCmdSetMargin , iVal );
#ifdef _MY_DEBUG_
	fprintf(stderr , "ERROR: n1 = 0x%02x, n2 = 0x%02x, iVal = 0x%x\n",kQLCmdSetMargin[3], kQLCmdSetMargin[4], iVal) ;
#endif	
#ifdef _LINUX_STD_
	if( fwrite( kQLCmdSetMargin , sizeof(kQLCmdSetMargin) , 1 , fp_page_header ) < 1 )
	{
		fclose(fp_page_header);
		remove(_TEMP_FILE_HEADER_);
		fprintf(stderr , "ERROR: Send command failed.\n" ) ;
		return sRet;
	}

	if( fwrite( kQLCmdSetMargin , sizeof(kQLCmdSetMargin) , 1 , g_jobdata.page_temp.pfile  ) < 1 ){
#else
	if( fwrite( kQLCmdSetMargin , sizeof(kQLCmdSetMargin) , 1 , stdout ) < 1 ){
#endif
		fclose(fp_page_header);
		remove(_TEMP_FILE_HEADER_);
		fprintf(stderr , "ERROR: Send command failed.\n" ) ;
		return sRet ;
	}

/* MSAT Added for High Speed Print--QL720NW--29Sep2011...  */

#ifdef _LINUX_STD_
		if( fwrite( kQLCmdHighSpeedPrint , sizeof(kQLCmdHighSpeedPrint) , 1 , fp_page_header ) < 1 )
		{
			fclose(fp_page_header);
			remove(_TEMP_FILE_HEADER_);
			fprintf(stderr , "ERROR: Send command failed.\n" ) ;
			return sRet;
		}

		if( fwrite( kQLCmdHighSpeedPrint , sizeof(kQLCmdHighSpeedPrint) , 1 , g_jobdata.page_temp.pfile  ) < 1 ){
#else
		if( fwrite( kQLCmdHighSpeedPrint , sizeof(kQLCmdHighSpeedPrint) , 1 , stdout ) < 1 ){
#endif
			fclose(fp_page_header);
			remove(_TEMP_FILE_HEADER_);
			fprintf(stderr , "ERROR: Send command failed.\n" ) ;
			return sRet ;
		}
	
/* ...MSAT Added for High Speed Print--QL720NW--29Sep2011 */



	/* Set Compression */
	if( sParam->compress ){
//#S1

#ifdef _LINUX_STD_
		if( fwrite( kQLCmdCompression_TIFF , sizeof(kQLCmdCompression_TIFF), 1 , fp_page_header ) < 1 )
		{
			fclose(fp_page_header);
			remove(_TEMP_FILE_HEADER_);
			fprintf(stderr , "ERROR: Send command failed.\n" ) ;
			return sRet;
		}

		if( fwrite( kQLCmdCompression_TIFF , sizeof(kQLCmdCompression_TIFF) , 1 , g_jobdata.page_temp.pfile  ) < 1 ){
#else
		if( fwrite( kQLCmdCompression_TIFF , sizeof(kQLCmdCompression_TIFF) , 1 , stdout ) < 1 ){
#endif
			fclose(fp_page_header);
			remove(_TEMP_FILE_HEADER_);
			fprintf(stderr , "ERROR: Send command failed.\n" ) ;
			return sRet ;
		}
	}else{

#ifdef _LINUX_STD_
		if( fwrite( kQLCmdCompression_Non , sizeof(kQLCmdCompression_Non) , 1 , fp_page_header ) < 1 )
		{
			fclose(fp_page_header);
			remove(_TEMP_FILE_HEADER_);
			fprintf(stderr , "ERROR: Send command failed.\n" ) ;
			return sRet;
		}

		if( fwrite( kQLCmdCompression_Non , sizeof(kQLCmdCompression_Non) , 1 , g_jobdata.page_temp.pfile  ) < 1 ){
#else
		if( fwrite( kQLCmdCompression_Non , sizeof(kQLCmdCompression_Non) , 1 , stdout ) < 1 ){
#endif
			fclose(fp_page_header);
			remove(_TEMP_FILE_HEADER_);
			fprintf(stderr , "ERROR: Send command failed.\n" ) ;
			return sRet ;
		}
	}



	fclose(fp_page_header);


	return 0 ;
}

/*-------------------------------------------------------------------------------------
*Name 		: MEndJob_1030
*Description 	: End a job
*Parameters 	: N/A
*Precondition	: The printer is initialized
*Operation 	: Reset the printer
*Postcondition 	: The printer finishs a job
*Return 	:
*		0 	: Succeeded ; otherwise , Failed.
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/
short	MEndJob_QL(	)
{
	return 0 ;
}

/*-------------------------------------------------------------------------------------
*Name 		: MBeginPage_1030
*Description 	: Initialize the printer for a new page
*Parameters 	:
*	header	: page header
*Precondition	: header != NULL
*Operation 	: Set initialization commands to the printer for new page
*Postcondition 	: the printer is ready to receive data.
*Return 	:
*		0 	: Succeeded ; otherwise , Failed.
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/
#ifdef _LPR_
short	MBeginPage_QL(	int iPage )
#else
short	MBeginPage_QL(	cups_page_header_t *	header , int iPage )
#endif
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	return 0 ;
}

/*-------------------------------------------------------------------------------------
*Name 		: MEndPage_1030
*Description 	: End a page
*Parameters 	: N/A
*Precondition	: print data is sent.
*Operation 	: Set FEED commands to the printer to feed page
*Postcondition 	: A page is fed.
*Return 	:
*		0 	: Succeeded ; otherwise , Failed.
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/
short	MEndPage_QL( short sLastPage )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
#ifndef _LINUX_STD_
	// set each print command 0x0C
	if( 1 ){
#else		
	if( sLastPage ){
#endif		
#ifdef _LINUX_STD_
		fwrite(kQLCmdPrintFeeding,sizeof(kQLCmdPrintFeeding),1, g_jobdata.page_temp.pfile) ;
#else
		fwrite(kQLCmdPrintFeeding,sizeof(kQLCmdPrintFeeding),1,stdout) ;
#endif

	}else{
#ifdef _LINUX_STD_
		fwrite(kQLCmdPrint,sizeof(kQLCmdPrint) , 1 , g_jobdata.page_temp.pfile  ) ;
#else
		fwrite(kQLCmdPrint,sizeof(kQLCmdPrint),1,stdout) ;
#endif
	}
	return 0 ;
}

/*-------------------------------------------------------------------------------------
*Name 		: MSendLine_1030
*Description 	: Send one line data
*Parameters 	:
*	header	: page header
*	iPage		: page index
*	iLine		: line index
*	source	: one line source data to be sent.
*Precondition	: header != NULL&&source!=0
*Operation 	: Haltone and compress the data , then send it.
*Postcondition 	: data is sent to the printer
*Return 	:
*		0 	: Succeeded ; otherwise , Failed.
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/

unsigned char DitherMatrix[4][4]={
	{0*16+8,2*16+8,8*16+8,14*16+8},
	{6*16+8,4*16+8,10*16+8,12*16+8},
	{9*16+8,15*16+8,1*16+8,3*16+8},
	{11*16+8,13*16+8,7*16+8,5*16+8}
};

extern unsigned char aBitMask[8] ;

short	MSendBand_QL( LPPTPARAM sParam )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	int x0 , y0 , dx , dy , i , h ;
	int skipLine ;
	long len ;
	short	resolution = 0 , send ;

	unsigned char * pSource , chTmp ;
	unsigned char	dest[ kMaxRasterBytes + 3 + 1 ]  , * pdest3 ;
	unsigned char	temp[3][kMaxRasterBytes] , byte ;

	static unsigned char * pReverseBuf = NULL , * p = NULL ;

	/* Mirror printing with landscape cases */
	if( sParam->sMirrorPrinting && (sParam->orientation == 2 || sParam->orientation == 4 ) ){
		if( sParam->bandNum == 0 ){
			//Allocate buffer to store data
			pReverseBuf = (unsigned char *)malloc( sParam->sDestWidth * sParam->sDestHeight ) ;

			if( NULL == pReverseBuf ){
				fprintf(stderr , "ERROR: Allocate memory failed!\n" ) ;
				return 1 ;
			}

			p = pReverseBuf + ( (long)sParam->sDestHeight - 1 ) * sParam->sDestWidth ;
		}

		x0 = sParam->pTape->unPinsRightMargin ;
		y0 = sParam->bandline ;

		pSource  = sParam->pBandData ;
		skipLine = sParam->sSourceWidthBytes ;

		//Copy data to buffer
		for(dy = 0 ; dy < (sParam->bandHeight) && (y0 + dy < sParam->sDestHeight) ; dy++ ){
			memcpy( p , pSource , sParam->sDestWidth ) ;

			p -= sParam->sDestWidth ;
			pSource += skipLine ;
		}


		if( sParam->bandNum == sParam->bandTotal - 1 ){
			//Initialize values and goto to the beginnig of halftone process
			x0 = sParam->pTape->unPinsRightMargin ;
			y0 = 0 ;
			h = sParam->sDestHeight ;

			pSource  = pReverseBuf ;
			skipLine = sParam->sDestWidth ;
		}else{
			return 0 ;
		}
	}else{
		x0 = sParam->pTape->unPinsRightMargin ;
		y0 = sParam->bandline ;
		h = sParam->bandHeight ;

		pSource  = sParam->pBandData ;
		skipLine = sParam->sSourceWidthBytes ;
	}

	resolution = 0 ;
	memset(&(temp[0][0]) , 0 , sizeof(temp) ) ;

	len = sParam->pTape->unRasterBytes + 3 ;
	memset( dest , 0 , kMaxRasterBytes + 3 ) ;
	dest[0] = '\x67' ;
	dest[1] = '\x00' ;
	dest[2] = sParam->pTape->unRasterBytes ;		// only for non compress
	pdest3 = &(dest[3]) ;

#if	1	// Added by SteadyBJ, Liu Bin, 2006.09.18
		// Necessary to move 35 dots in printing 12 dia
//	fprintf( stderr, "ERROR:Tape=%s, Printer=%s\n", sParam->pTape->ID, sParam->PTName);
	if(    (strcmp(sParam->pTape->ID, "12Dia") == 0)
//	 	&& ( strcmp(sParam->PTName, "ql500") == 0 || strcmp(sParam->PTName, "ql550") == 0 )
	)
	{
		int ii = 0;
		memset(pdest3, 0, sParam->pTape->unRasterBytes);
		for( ii = 0; ii < DOTS_35; ii++)
		{
			SaveDumb(&len , dest ) ;
		}
//		fprintf( stderr, "ERROR:Send 35 blanks(len=%d)\n", len);
	}
#endif	// 1

#ifndef _QL500_650TD_  //Satyam
//#ifndef	_QL570_	// Satyam added for QL570 
	//unsigned char ucBYTECount = kMaxRasterBytes_QL1050;	// 162
	unsigned char ucBYTECount = kMaxRasterBytes;	// 162
	for(dy = 0 ; dy < (h) && (y0 + dy < sParam->sDestHeight) ; dy++ ){

		/* Mirror Printing */
		if( sParam->sMirrorPrinting && (sParam->orientation == 1 || sParam->orientation == 3) ){
			for( dx = 0 ; dx < sParam->sDestWidth/2 ; dx++ ){
				chTmp = pSource[ dx ] ;
				pSource[ dx ] = pSource[ sParam->sDestWidth - dx - 1 ] ;
				pSource[ sParam->sDestWidth - dx - 1 ] = chTmp ;
			}

		}

		effectGray(pSource , sParam->sDestWidth , sParam->sBrightness, sParam->sContrast );

		ditherGray( pSource , pdest3 , \
					y0 + dy , x0 , \
					sParam->sDestWidth , \
					sParam->sHalftonePattern , resolution \
				   );

		if( sParam->sHalftonePattern == HALFTONE_BINARY && resolution ){
			/* Resolution processe here */
			send = 1 ;
			if( y0 + dy == 0 ){
				memcpy( temp[0], pdest3 , ucBYTECount ) ;
				send = 1 ;
			}else if( y0 + dy == 1 ){
				memcpy( temp[1], pdest3 , ucBYTECount ) ;
				send = 0 ;
			}else{
				memcpy( temp[2], pdest3 , ucBYTECount ) ;
				for( i = 0 ; i < ucBYTECount ; i++ ){
					byte = temp[0][i] & temp[1][i] & temp[2][i] ;

					if( byte ){
						temp[1][i] &= (~byte) ;
					}

					pdest3[i] = temp[1][i] ;
				}
				memcpy( temp[0] , temp[1] , ucBYTECount ) ;
				memcpy( temp[1] , temp[2] , ucBYTECount ) ;

				send = 1 ;
			}

			/* If the Last line */
			if( y0 + dy == sParam->sDestHeight - 1 ){
				if( y0 + dy == 0 ){
					send = 1 ;
				}else if( y0 + dy == 1 ){
					send = 1 ;
				}else{		/* send two lines at the last line */
					if( sParam->compress ){
						CompressALineTIFF( dest , &len ) ;
					}

					SaveDumb(&len , dest ) ;
					len = sParam->pTape->unRasterBytes + 3 ;
					memcpy( pdest3 , temp[2] , ucBYTECount ) ;
					send = 1 ;
				}
			}

			/* Save data */
			if( send ){
				if( sParam->compress ){
					CompressALineTIFF( dest , &len ) ;
				}

				SaveDumb(&len , dest ) ;
				len = sParam->pTape->unRasterBytes + 3 ;
			}

		}else{
			/* Save data */
			if( sParam->compress ){
				CompressALineTIFF( dest , &len ) ;
			}
			SaveDumb(&len , dest ) ;
			len = sParam->pTape->unRasterBytes + 3 ;
		}

		/* Reset dest buffer */
		memset( pdest3 , 0 , ucBYTECount ) ;

		pSource += skipLine ;
	}
#else	// _QL570_  added till here

	for(dy = 0 ; dy < (h) && (y0 + dy < sParam->sDestHeight) ; dy++ ){

		/* Mirror Printing */
		if( sParam->sMirrorPrinting && (sParam->orientation == 1 || sParam->orientation == 3) ){
			for( dx = 0 ; dx < sParam->sDestWidth/2 ; dx++ ){
				chTmp = pSource[ dx ] ;
				pSource[ dx ] = pSource[ sParam->sDestWidth - dx - 1 ] ;
				pSource[ sParam->sDestWidth - dx - 1 ] = chTmp ;
			}

		}

		effectGray(pSource , sParam->sDestWidth , sParam->sBrightness, sParam->sContrast );

		ditherGray( pSource , pdest3 , \
					y0 + dy , x0 , \
					sParam->sDestWidth , \
					sParam->sHalftonePattern , resolution \
				   );

		if( sParam->sHalftonePattern == HALFTONE_BINARY && resolution ){
			/* Resolution processe here */
			send = 1 ;
			if( y0 + dy == 0 ){
				memcpy( temp[0], pdest3 , kMaxRasterBytes ) ;
				send = 1 ;
			}else if( y0 + dy == 1 ){
				memcpy( temp[1], pdest3 , kMaxRasterBytes ) ;
				send = 0 ;
			}else{
				memcpy( temp[2], pdest3 , kMaxRasterBytes ) ;
				for( i = 0 ; i < kMaxRasterBytes ; i++ ){
					byte = temp[0][i] & temp[1][i] & temp[2][i] ;

					if( byte ){
						temp[1][i] &= (~byte) ;
					}

					pdest3[i] = temp[1][i] ;
				}
				memcpy( temp[0] , temp[1] , kMaxRasterBytes ) ;
				memcpy( temp[1] , temp[2] , kMaxRasterBytes ) ;

				send = 1 ;
			}

			/* If the Last line */
			if( y0 + dy == sParam->sDestHeight - 1 ){
				if( y0 + dy == 0 ){
					send = 1 ;
				}else if( y0 + dy == 1 ){
					send = 1 ;
				}else{		/* send two lines at the last line */
					if( sParam->compress ){
						CompressALineTIFF( dest , &len ) ;
					}

					SaveDumb(&len , dest ) ;
					len = sParam->pTape->unRasterBytes + 3 ;
					memcpy( pdest3 , temp[2] , kMaxRasterBytes ) ;
					send = 1 ;
				}
			}

			/* Save data */
			if( send ){
				if( sParam->compress ){
					CompressALineTIFF( dest , &len ) ;
				}

				SaveDumb(&len , dest ) ;
				len = sParam->pTape->unRasterBytes + 3 ;
			}

		}else{
			/* Save data */
			if( sParam->compress ){
				CompressALineTIFF( dest , &len ) ;
			}
			SaveDumb(&len , dest ) ;
			len = sParam->pTape->unRasterBytes + 3 ;
		}

		/* Reset dest buffer */
		memset( pdest3 , 0 , kMaxRasterBytes ) ;

		pSource += skipLine ;
	}

#endif	// _QL570_ for #if_570
	if( pReverseBuf ){
		free( pReverseBuf ) ;
		pReverseBuf = NULL ;
		p = NULL ;
	}

	return 0 ;
}

/*-------------------------------------------------------------------------------------
*Name 		: CompressM9_1030
*Description 	: Compress one line data
*Parameters 	:
*	compData	: compress data object.
*	header	: page header
*Precondition	: header != NULL&&compData!=0
*Operation 	: Compress data
*Postcondition 	: data is compressed
*Return 	:
*		0 	: Succeeded ; otherwise , Failed.
*[NOTE]		: This function is copied from esc1030.c
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/
void	CompressM9_QL(/*MODE9 *compData , cups_page_header_t * header*/ )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	return ;
}

/*-------------------------------------------------------------------------------------
*Name 		: MSendData_1030
*Description 	: Send data in Send buffer
*Parameters 	:
*	send_buf	: send buffer object pointer
*Precondition	: send_buf != NULL
*Operation 	: send data
*Postcondition 	: data in send buffer is sent to the printer and the send buffer is reset
*Return 	:
*		0 	: Succeeded ; otherwise , Failed.
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/
short	MSendData_QL( send_buffer * send_buf )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	if( send_buf->lBufByteCnt ){
#ifdef _LINUX_STD_
		if( fwrite( send_buf->buffer , send_buf->lBufByteCnt , 1 , g_jobdata.page_temp.pfile  ) < 1 ){
#else
		if( fwrite( send_buf->buffer , send_buf->lBufByteCnt , 1 , stdout ) < 1 ){
#endif
			return 1 ;
		}
	}
	send_buf->lBufByteCnt = 0 ;
	
	return 0 ;
}

void	CompressALineTIFF( unsigned char * buf , long * plen )
{
	fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	unsigned char	temp[ kMaxRasterBytes * 2 + 1 ] ;
	unsigned char	tempbuf[ kMaxRasterBytes * 2 + 1 ] ;  //Satyam added for QL570
	unsigned char * p , *p1 , * pT;
	unsigned char	i , countTotal , count ;
#ifdef	_QL570_   //Satyam added for QL570
 	int LoopTimes = 2;
	int ii = 0;
	int iTotal = 0;
#endif

	if( NULL == buf || NULL == plen ){
		return ;
	}
	
	if( (*plen) < 4 || (*plen) > 127 ){
		return ;
	}
	
	countTotal = 0 ;
	count = 0 ;
	pT = temp ;

#ifdef	_QL570_	// Satyam added for QL570
	memcpy(tempbuf, buf, *plen);
	for( ii = 0; ii < 2; ii++)
	{
		if( ii == 0 )
		{
			iTotal = kMaxRasterBytes / 2;
		}
		else
		{
			iTotal = kMaxRasterBytes - kMaxRasterBytes / 2;
			memcpy(tempbuf + 3, buf + 3 + kMaxRasterBytes / 2, iTotal);
		}

		for(p = tempbuf+3; p < tempbuf + 3 + iTotal ; /*p++*/ )
		{
			if( p == tempbuf + 3 + iTotal - 1 )
			{
				*(pT++) = 0 ;
				*(pT++) = *(p) ;
				countTotal += 2 ;
				break;
			}
			count = 0;
			for( p1 = p+1 ; p1 < tempbuf + 3 + iTotal ; p1++ )
			{
				if( *p1 == *(p1-1) )
				{		//Repeat
					if( p == (p1-1) )
					{
						count-- ;	//
					}
	
					count-- ;
					if( count < 0x80 )	// No Repeat case
					{
						break ;	//Break the loop 2
					}
				}
				else
				{	//No Repeat
					if( count >= 0x80 )
					{		//Repeat case
						break ;		//Break the loop 2
					}
					else
					{	//No Repeat case
						count++ ;
					}
				}
			}	//Loop 2
			
			if( count >= 0x80 )
			{	//repeat
				count++;
				*(pT++) = count ;
				*(pT++) = *(p) ;
				countTotal += 2 ;										
				p = p1;
			}
			else
			{
				count++;
				*(pT++) = count - 1 ;
				countTotal++ ;
				
				for( i = 0 ; i < count ; i++ )
				{
					*(pT++) = *(p++) ;						
				}
				countTotal += count ;
			}
		}//Loop 1
	}

#else
//Satyam added till here for QL570
	for( p = buf+3 ; p < buf + (*plen) - 1 ; /*p++*/ )
	{
		count = 0;
		for( p1 = p+1 ; p1 < buf + (*plen) ; p1++ )
		{
			if( *p1 == *(p1-1) )
			{		//Repeat
				if( p == (p1-1) )
				{
					count-- ;	//
				}

				count-- ;
				if( count < 0x80 )	// No Repeat case
				{
					break ;	//Break the loop 2
				}
			}
			else
			{	//No Repeat
				if( count >= 0x80 )
				{		//Repeat case
					break ;		//Break the loop 2
				}
				else
				{	//No Repeat case
					count++ ;
				}
			}
		}	//Loop 2
		
		if( count > 0x80 )
		{	//repeat
			count++;
			*(pT++) = count ;
			*(pT++) = *(p) ;
			countTotal += 2 ;										
			p = p1;
		}
		else
		{
			count++;
			*(pT++) = count - 1 ;
			countTotal++ ;
			
			for( i = 0 ; i < count ; i++ )
			{
				*(pT++) = *(p++) ;						
			}
			countTotal += count ;
		}
	}//Loop 1
		
#endif  //Satyam #if_ql570 End

	buf[2] = countTotal ;
	for( i = 0 ; i < countTotal ; i++ ){
		buf[3+i] = temp[i] ;
	}
	
	*(plen) = countTotal + 3 ;
		
	return ;
}

/*-------------------------------------------------------------------------------------
*Name 		: SetFunctionTable
*Description 	: Set functions depending on printer model
*Parameters 	: N/A
*Precondition	: model_series is initialized 
*Operation 	: Set the model function table.
*Postcondition 	: fun_table is set.
*Return 	:
*		0 	: Succeeded ; otherwise , Failed.
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/
short	SetFunctionTable()
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	short	sRet = 0 ;
	switch( model_series ){
#ifdef _QL500_650TD_
	case MODEL_QL_500:
	case MODEL_QL_550:
	case MODEL_QL_650TD:
	case MODEL_QL_570:
	case MODEL_QL_720NW:

#else
	case MODEL_QL :
#endif
		fun_table.lpfnMBeginJob 	= MBeginJob_QL 	;
		fun_table.lpfnMEndJob		= MEndJob_QL 	;
		fun_table.lpfnMBeginPage	= MBeginPage_QL	;
		fun_table.lpfnMEndPage		= MEndPage_QL	;
		fun_table.lpfnMSendBand		= MSendBand_QL	;
		fun_table.lpfnMSendData		= MSendData_QL	;
		
		sRet = 0 ;
		break ;
	default :
		sRet = 1 ;
		break ;
	} ;
	
	return sRet ;
}

short	ValidateFunctionTable()
{
	return 0 ;
}

/*-------------------------------------------------------------------------------------
*Name 		: ResetFunctionTable
*Description 	: reset fun_table
*Parameters 	: N/A
*Precondition	: N/A
*Operation 	: reset fun_table.
*Postcondition 	: fun_table is reset.
*Return 		: N/A
*History 		: 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*--------------------------------------------------------------------------------------*/
void ResetFunctionTable()
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	fun_table.lpfnMBeginJob 	= NULL 	;
	fun_table.lpfnMEndJob	= NULL 	;
	fun_table.lpfnMBeginPage	= NULL	;
	fun_table.lpfnMEndPage	= NULL	;
	fun_table.lpfnMSendBand	= NULL	;
	fun_table.lpfnMSendData	= NULL	;
}
