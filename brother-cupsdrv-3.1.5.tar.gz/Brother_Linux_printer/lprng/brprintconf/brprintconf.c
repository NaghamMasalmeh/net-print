/* $Id: brprintconf.c,v 1.9 2005/07/28 03:28:44 cvs Exp $ */
/*
* Copyright (C) 2004-2013 Brother. Industries, Ltd.
*
* This program is free software; you can redistribute it and/or modify it
* under the terms of the GNU General Public License as published by the Free
* Software Foundation; either version 2 of the License, or (at your option)
* any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
* more details.
*
* You should have received a copy of the GNU General Public License along with
* this program; if not, write to the Free Software Foundation, Inc., 59 Temple
* Place, Suite 330, Boston, MA  02111-1307  USA
*
* In addition, as a special exception, Brother Industries, Ltd. gives
* permission to link the code of this program with certain libraries covered
* by BROTHER PRINTER DRIVER SOFTWARE PUBLIC LICENSE AGREEMENT, and distribute
* linked combinations including the two.  You must obey the GNU General Public
* License in all respects for all of the code used other than the libraries as
* stipulated in the above.  If you modify this file, you may extend this
* exception to your version of the file, but you are not obligated to do so.
* If you do not wish to do so, delete this exception statement from your
* version.
*/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

#ifndef _PTOUCH_UP1_ // Added by SteadyBJ, Zhang Tianxia 2013.05.13 for Update QL-Base
#define _PTOUCH_UP1_
#endif  // _PTOUCH_UP1_

#include "brresource.h"
#include "brprintconf.h"
#include "brfiletool.h"
#include "brerror.h"
#include "debugtool.h"



#define _DEF_NAME_				// added by Liu Bin 2006.3.13

#ifdef _DEF_NAME_
static	int		BrCaption( char *szMyName, FILE *fp , char * pszInputPrinterName , char * pszPrinterMode , int bNoPrinterName );
#else
static	int		BrCaption( char *szMyName, FILE *fp , char * pszPrinterName , int bNoPrinterName);
#endif
static	int		GetPrinterName( char *argv[], BR_RESOURCE_INFO *pRcInfo );
static	int		LoadFuncFile( char *pszFilename, BR_RESOURCE_INFO *pRcInfo );
static	int		GetSelectItem( int nIndex, char *pszValue, BR_RESOURCE_INFO *pRcInfo );
static	int		ValidateRcItem( char *pszItem, BR_PARAM_INFO *pParam );
static	int		EntrySelectRange( int nIndex, char *pszValue, BR_RESOURCE_INFO *pRcInfo );
static	int		ApplyCommandParameters( int argc, char *argv[], BR_RESOURCE_INFO *pRcInfo );
static	int		SaveRcFile( char *szFilename, BR_RESOURCE_INFO *pRcInfo );
static	void	PutParamRcForm( FILE *fp, int nIndex, BR_RESOURCE_INFO *pRcInfo );
#ifdef  BR_CONSTRAINT               /* Added by Chenxujin , SteadyBJ , 2004.11.17 */
static int CheckConstraintItem( char *pszConstraint, BR_RESOURCE_INFO *pRcInfo );
static int CheckConstraints( BR_RESOURCE_INFO *pRcInfo );
#endif


#ifdef _CUSTOM_TAPE_
TapeList	g_tapelist;
#endif



/*-------------------------------------------------------------------------------------
*Name           : main
*Parameters     : 
*       argv[1] : -P Ç€Ê€Æ€Ï€Ê€ï¿œ
*       argv[2] : ×¥ï¿œÌŸ
*       Îžå¡¢2Ä€Î°Ã¥È€Ç¡ï¿œcommand ï¿œï¿œÑ¥ï¿œ×€Îœ
*Return         : 
*             0 : 5ïœªÎ»
*        ï¿œ : é¡ŒÎ»
*--------------------------------------------------------------------------------------*/
int
main( int argc, char *argv[] )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	char lpCustomTape[512];
	int		nResult = 0;
	char	szFilename[LINE_BUFFER+1];
	char	szBackupName[LINE_BUFFER+1];
#ifdef _PTOUCH_UP1_ // Added by SteadyBJ, Zhang Tianxia 2013.05.13 for Update QL-Base
    char szRcfile[LINE_BUFFER+1] = {0};
    FILE* fp = NULL;
    int nIndex = 0;
    char *szP = NULL;
#endif // _PTOUCH_UP1_

//	fprintf(stderr, "pid = %d\n", getpid());
//	sleep(1000);

#ifdef _DEF_NAME_
	if(	NULL == strstr( argv[0], "500") &&
		NULL == strstr( argv[0], "550") &&
		NULL == strstr( argv[0], "570") &&
		NULL == strstr( argv[0], "650") &&
		NULL == strstr( argv[0], "800") &&
		NULL == strstr( argv[0], "810") &&
		NULL == strstr( argv[0], "820") )
	{
		fprintf( stdout, "%s is invalid.\n\n", argv[0] );
		return 0;
	}

#endif

	/* Ñ¥ï¿œeÃ¥ */
	if( argc == 1 ){
		/* Parameter not found */
		return BrCaption( argv[0], stdout , NULL, NULL,TRUE);
	}

  if( argc >= 3 ){

    /* ×¥ï¿œÌŸï¿œï¿œ*/
    if( (nResult = GetPrinterName( argv, &g_rcInfo )) != 0 ){
      /* error */
      return nResult;
    }

    /* funcÕ¥ï¿œí¡Œï¿œ*/
    sprintf( szFilename, BR_FUNCLIST_PATH, g_rcInfo.szPrinterName, g_rcInfo.szPrinterName );
    nResult = LoadFuncFile( szFilename, &g_rcInfo );
    if( nResult != 0 ){
      /* error */
#ifdef  BR_CONSTRAINT               /* Added by Chenxujin , SteadyBJ , 2004.11.17 */
        FreeConstraint( &g_rcInfo ) ;
#endif
        return nResult;
    }

        // 5. Load rc file.
        // Get rc file path with print name. eg. td2xxx.
        sprintf( szFilename, BR_RCFILE_PATH, g_rcInfo.szPrinterName, g_rcInfo.szPrinterName );
#ifdef _PTOUCH_UP1_ // Added by SteadyBJ, Zhang Tianxia 2013.05.13 for Update QL-Base
        for(nIndex = 1; nIndex < argc - 1; nIndex += 2 )
        {
            if( 0 == strcmp(argv[nIndex], BR_CONF_CMD_QL_RC_NAME))
            {                                         
                memset(szFilename, 0, LINE_BUFFER + 1);
                sprintf(szFilename, "%s", argv[nIndex + 1]);
            }
        }
#endif // _PTOUCH_UP1_

//	char lpCustomTape[512];
    nResult = LoadRcFile( szFilename, &g_rcInfo );

        // 6. For customer paper
#ifdef _CUSTOM_TAPE_
	g_tapelist.iSelIndex = -1;
	if( -1 == g_rcInfo.aParams[BR_PARAM_ID_QL_MediaSize].nIndex )
	{
		int iFound = 0;
		int i;
		for( i = 0; i < g_tapelist.count; i ++)
		{
			if( strcmp (g_rcInfo.tapeid, g_tapelist.tapelist[i].tape_id) == 0 )
			{
				g_tapelist.iSelIndex = i;
				iFound = 1;
				break;
			}
		}
		if(0 == iFound)
		{
			g_rcInfo.aParams[BR_PARAM_ID_QL_MediaSize].nIndex = 10;		// 29mm tape
		}
	}
#endif
    if( nResult != 0 ){
      /* error */
#ifdef  BR_CONSTRAINT               /* Added by Chenxujin , SteadyBJ , 2004.11.17 */
        FreeConstraint( &g_rcInfo ) ;
#endif
        return nResult;
    }

    /* List the machine functionlist */
    if( argc == 3 ){
#ifdef _DEF_NAME_
      nResult = BrCaption(argv[0], stdout , argv[2], g_rcInfo.szPrinterName , FALSE) ;
#else
      nResult = BrCaption(argv[0], stdout , g_rcInfo.szPrinterName , FALSE) ;
#endif

#ifdef  BR_CONSTRAINT               /* Added by Chenxujin , SteadyBJ , 2004.11.17 */
      FreeConstraint( &g_rcInfo ) ;
#endif
      return nResult ;
    }
  }
	if(argc < 5){
		/* Invalid Parameter */
#ifdef  BR_CONSTRAINT               /* Added by Chenxujin , SteadyBJ , 2004.11.17 */
    	FreeConstraint( &g_rcInfo ) ;
#endif
		return BrError( BR_ERROR_OPTION, NULL );
	}
	if( ((argc - 1) % 2) != 0 ){
#ifdef  BR_CONSTRAINT               /* Added by Chenxujin , SteadyBJ , 2004.11.17 */
    	FreeConstraint( &g_rcInfo ) ;
#endif
		/* Invalid Parameter */
		return BrError( BR_ERROR_OPTION, NULL );
	}

    // 10. Record current using-rc file path.
#if 0
//#ifdef _PTOUCH_UP1_ // Added by SteadyBJ, Li Yong, 2013-01-21
    sprintf(szRcfile, BR_RECORD_RC_PATH, g_rcInfo.szPrinterName);
    remove(szRcfile);
    if ((fp = fopen(szRcfile, "w+")) == NULL)
    {
        BrError( BR_ERROR_FILEOPEN, szRcfile );
    }
    fprintf(fp, "%s", szFilename);
    fclose(fp);
    chmod( szRcfile, 0777 );
#endif // _PTOUCH_UP1_

    // 11. Apply CMD param.
    nResult = ApplyCommandParameters( argc, argv, &g_rcInfo );
    if( nResult != 0 ){
        /* error */
#ifdef  BR_CONSTRAINT               /* Added by Chenxujin , SteadyBJ , 2004.11.17 */
        FreeConstraint( &g_rcInfo ) ;
#endif
		return nResult;
	}

#ifdef  BR_CONSTRAINT               /* Added by Chenxujin , SteadyBJ , 2004.11.17 */
  nResult =CheckConstraints( &g_rcInfo ) ;
	if( nResult != 0 ){
		/* error */
        FreeConstraint( &g_rcInfo ) ;
		return nResult;
	}
#endif

	/* ê¥œÕ¥ï¿œÐ¥Ã¥Ã¥ï¿œ*/
	sprintf( szBackupName, "%s.old", szFilename );
	nResult = rename( szFilename, szBackupName );
	if( nResult != 0 ){
#ifdef  BR_CONSTRAINT               /* Added by Chenxujin , SteadyBJ , 2004.11.17 */
        FreeConstraint( &g_rcInfo ) ;
#endif
		return BrError( BR_ERROR_FILEOPEN, szBackupName );
	}

	/* ê¥œÕ¥ï¿œÐ€ */
	nResult = SaveRcFile( szFilename, &g_rcInfo );

	/* Ð¥Ã¥Ã¥×¥Õ¥ï¿œï¿œï¿œ */
	if( nResult == 0 ){
		remove( szBackupName );
	}
	else{
		/* Ð€ï¿œÏ¥Ð¥Ã¥Ã¥×€ï¿œá€¹ */
		rename( szBackupName, szFilename );
	}

#ifdef  BR_CONSTRAINT               /* Added by Chenxujin , SteadyBJ , 2004.11.17 */
    FreeConstraint( &g_rcInfo ) ;
#endif
	return nResult;
}

/*-------------------------------------------------------------------------------------
*Name           : BrCaption
*Parameters     : 
*      szMyName : Â¹Ô¥Õ¥ï¿œ
*            fp : ï¿œï¿œï¿œ
*	pszPrinterMode: ql500, ql550, ql570, ql650td
*Return         : 
*             0 : 5ïœªÎ»
*--------------------------------------------------------------------------------------*/
int
BrCaption( char *szMyName, FILE *fp , char * pszInputPrinterName , char * pszPrinterMode , int bNoPrinterName )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	int		i, j;
	char	work[LINE_BUFFER+1];
  char szDefault[]="[printer name]";
  char * pszPrinter = NULL ;

#ifdef _DEF_NAME_
	pszPrinter = pszInputPrinterName;
#else
  pszPrinter = pszPrinterName ;
#endif
  if( pszPrinter == NULL ){
    pszPrinter = szDefault ;
  }

#ifdef _DEF_NAME_
	sprintf( work, BR_FUNCLIST_PATH, pszPrinterMode, pszPrinterMode );
//	fprintf( fp, "function list : %s\n", work );
	sprintf( work, BR_RCFILE_PATH, pszPrinterMode, pszPrinter );
//	fprintf( fp, "resource file : %s\n", work );
#else
	sprintf( work, BR_FUNCLIST_PATH, pszPrinter, pszPrinter );
//	fprintf( fp, "function list : %s\n", work );
	sprintf( work, BR_RCFILE_PATH, pszPrinter, pszPrinter );
//	fprintf( fp, "resource file : %s\n", work );
#endif

//	fprintf( fp, "\n" );

#ifdef _DEF_NAME_
	if( pszInputPrinterName == NULL ){
#else
  if( pszPrinterName == NULL ){
#endif
    fprintf( fp, "Usage:\n" );
    }
    else
    {
    fprintf( fp , "Usage on %s:\n" , pszPrinter ) ;
  }

	fprintf( fp, "%s -P %s <[option command] [setting]>...\n\n", szMyName , pszPrinter );

	if( TRUE == bNoPrinterName)
		return 0;	// terminates
///* //Satyam changed for QL570
#ifdef _LINUX_STD_
        for( i = BR_PARAM_ID_QL_CutAtEnd; i < g_rcInfo.nParamNum; i++ ){

//	for( i = BR_PARAM_ID_QL_AutoCut; i < g_rcInfo.nParamNum; i++ ){
#else
	for( i = 0; i < g_rcInfo.nParamNum; i++ ){
#endif
		if( g_rcInfo.aParams[i].szCmd == NULL ){
			continue;
		}
		fprintf( fp, " %-6s : %s\n", g_rcInfo.aParams[i].szCmd, g_rcInfo.aParams[i].szKey );

		if( g_rcInfo.aParams[i].nItemNum == 0 ){
//			fprintf( fp, "   (%d ~ %d) :", g_rcInfo.aParams[i].nMin, g_rcInfo.aParams[i].nMax );
			fprintf( fp, "   numerical value\n" );
		}
		else for( j = 0; j < g_rcInfo.aParams[i].nItemNum; j++ ){
			fprintf( fp, "   %-9s : %s\n", g_rcInfo.aParams[i].paCmdItemList[j], g_rcInfo.aParams[i].paRcItemList[j] );
		}
	}
//*/
#ifdef  BR_CONSTRAINT               // Added by Chenxujin , SteadyBJ , 2004.11.17 /
  for( i = 0 ; i < g_rcInfo.constraint.nCount ; i++ ){
     if( i == 0 ){
      fprintf( fp, "Constraint(%d):\n",g_rcInfo.constraint.nCount );
     }
     fprintf(fp,"C%02d: %s\n",i , g_rcInfo.constraint.paConstraintList[i]) ;
  }
#endif/* BR_CONSTRAINT */


#ifdef _CUSTOM_TAPE_
	for( i = 0; i < g_tapelist.count; i ++)
	{
		fprintf(fp, "   %-9s : %s\n", g_tapelist.tapelist[i].tape_name, g_tapelist.tapelist[i].tape_name);
	}
#endif // _CUSTOM_TAPE_

    // 6. Print -rcfile CMD usage.
#ifdef _PTOUCH_UP1_ // Added by SteadyBJ, Zhang Tianxia 2013.05.13 for Update QL-Base
    fprintf(fp," %-6s \n", BR_CONF_CMD_QL_RC_NAME);
    fprintf(fp,"   %-9s\n", "The rc file full path");
#endif // _PTOUCH_UP1_ 

	return 0;
}
                                                                                                              

/*-------------------------------------------------------------------------------------
*Name           : GetPrinterName
*Description    : Þ¥É¥é¥€ï¿œ×¥ï¿œÌŸï¿œï¿œï¿œ$ï¿œ
*Parameters     : 
*        argv[] : Þ¥É¥é¥€ï¿œï¿œ
*       pRcInfo : ×¥ï¿œÌŸï¿œï¿œÊ¥×¥ï¿œï¿œ
*Return         : 
*             0 : 5ïœªÎ»
*        ï¿œ : é¡ŒÎ»
*--------------------------------------------------------------------------------------*/
int
GetPrinterName( char *argv[], BR_RESOURCE_INFO *pRcInfo )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	int		nResult = 0;
	char	szError[LINE_BUFFER+1];

	/* argv[1]"-P"eÃ¥ */
	if( strcmp( argv[1], BR_CONF_PRINTER_NAME ) == 0 ){
		/* argv[2]Ï¥×¥ï¿œÌŸ */
#ifdef _DEF_NAME_
		if( strstr( argv[0], "500") )
		{
			strcpy( pRcInfo->szPrinterName, "ql500" );
		}
		else if( strstr( argv[0], "550") )
		{
			strcpy( pRcInfo->szPrinterName, "ql550" );
		}
		else if( strstr( argv[0], "650") )
		{
			strcpy( pRcInfo->szPrinterName, "ql650td" );
		}
		//added for QL570
		 else if( strstr( argv[0], "570") )
        {
             strcpy( pRcInfo->szPrinterName, "ql570" );
         }
		//added for QL720NW
		 else if( strstr( argv[0], "800") )
         {
              strcpy( pRcInfo->szPrinterName, "ql800" );
         }
		 else if( strstr( argv[0], "810") )
         {
              strcpy( pRcInfo->szPrinterName, "ql810w" );
         }
		 else if( strstr( argv[0], "820") )
         {
              strcpy( pRcInfo->szPrinterName, "ql820nwb" );
         }

#else
		strcpy( pRcInfo->szPrinterName, argv[2] );
#endif
	}
	else{
		sprintf( szError, "%s %s", argv[1], argv[2] );
		nResult = BrError( BR_ERROR_OPTION, szError );
	}

	return nResult;
}


/*-------------------------------------------------------------------------------------
*Name           : LoadFuncFile
*Description    : funcÕ¥ï¿œï¿œï¿œê¥œï¿œË¥í¡ŒÉ€ï¿œ
*Parameters     : 
*   pszFilename : Õ¥ï¿œ
*       pRcInfo : ×¥ï¿œê¥œï¿œ
*Return         : 
*             0 : 5ïœªÎ»
*        ï¿œ : é¡ŒÎ»
*--------------------------------------------------------------------------------------*/
int
LoadFuncFile( char *pszFilename, BR_RESOURCE_INFO *pRcInfo )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	FILE	*fp;
	int		nResult;
	int		nIndex;
	int		nRet;
	char	szLine[LINE_BUFFER+1];
	char	szValue[LINE_BUFFER+1];
	int		fValidSection = 0;

	if( (fp = fopen( pszFilename, "r" )) == NULL ){
		return BrError( BR_ERROR_FILEOPEN, pszFilename );
	}
	fseek( fp, 0, SEEK_SET );
DEBUGPRINT("LoadFuncFile: file(%s)\n",pszFilename);

	nResult = 0;

	while( ReadLine( szLine, LINE_BUFFER, fp ) != NULL ){
#ifdef _CUSTOM_TAPE_
		char *lpStr = strstr(szLine, _LABLE_ID_HEAD_);
		if(lpStr != NULL)
         	{
			TapeItem item;
			if(1 == GetLabel_name_id(lpStr, item.tape_name, item.tape_id))
			{
				add_tape(&g_tapelist, item.tape_name, item.tape_id);
			}
		}
#endif

		EraseSpace( szLine );
		DEBUGPRINT("get line (%s)\n",szLine);

		switch( szLine[0] ){
		case '\0' :	/* ï¿œ*/
			break;
		case '#' :	/* ï¿œÈ¹ï¿œ*/
			break;
		case '[' :	/* ï¿œÆ¬ */
			fValidSection = 0;
		default:
			if( fValidSection == 0 ){
				if( strcmp(szLine, BR_SECT_SELECTION_ITEM) == 0 ){
					/* SelectionItemï¿œï¿œ*/
					nResult = 0;
					fValidSection = 1;
DEBUGPRINT("Section OK :%s\n",szLine);
				}
#ifdef  BR_CONSTRAINT               /* Added by Chenxujin , SteadyBJ , 2004.11.17 */
                		else if( strcmp(szLine, BR_SECT_CONSTRAINT) == 0 ){    
						nResult = 0;
						fValidSection = 2;
						DEBUGPRINT("Constraint Section OK :%s\n",szLine);
				}
#endif/* BR_CONSTRAINT */
			}
			else{
#ifdef  BR_CONSTRAINT               /* Added by Chenxujin , SteadyBJ , 2004.11.17 */
                if( fValidSection == 2 ){/* Deal with the constraint items */
                    nRet = CheckConstraintItem( szLine , pRcInfo ) ;
                    if( nRet == 0 &&pRcInfo->constraint.nCount < MAX_CONSTRAINT_NUM ){
                        AddConstraint(szLine , pRcInfo );
                }else{
                    DEBUGPRINT("Invalid Constraint: %s\n",szLine);
                }
                continue ;/* Read Next line */
            }
#endif/* BR_CONSTRAINT */
        /* SelectionItemï¿œï¿œ */
        nIndex = ParamSearch( szLine, szValue );
        switch(GetParamType(nIndex , pRcInfo)){
          case PARAM_TYPE_STRING :;
            nRet = GetSelectItem( nIndex, szValue, pRcInfo );
            break ;
          case PARAM_TYPE_NUMERICAL :;
            nRet = EntrySelectRange( nIndex, szValue, pRcInfo );
            break ;
          case PARAM_TYPE_LANGUAGE :;
            break ;
          default :;
            break ;  
        } ;
			}
		}
	}

	fclose( fp );
	return nResult;
}

#ifdef  BR_CONSTRAINT               /* Added by Chenxujin , SteadyBJ , 2004.11.17 */
/*-------------------------------------------------------------------------------------
*Name           : CheckConstraintItem
*Description    : Check a constraint item
*Parameters     :
* pszConstraint : the constraint string
*       pRcInfo : the resource information struct
*Return         :
*             0 : valid constraint item
*       nonzero : Invalid constraint item
*--------------------------------------------------------------------------------------*/
int
CheckConstraintItem( char *pszConstraint, BR_RESOURCE_INFO *pRcInfo )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
    char szC[ LINE_BUFFER+1 ] ;
  	char	szValue[LINE_BUFFER+1];
    char *pszKey[2] , *pszValue[2] ;
    int nIndex , i ;
    int nResult = 0 ;

    memcpy(szC , pszConstraint , strlen(pszConstraint)+1) ;
    pszKey[0]   = szC ;
    pszValue[0] = szValue ;
    pszKey[1] = strchr( szC , '*') ;
    if( pszKey[1] == NULL ){
      return -1 ;
    }

    *(pszKey[1]) = '\0' ;
    pszKey[1]++ ;
    pszValue[1] = &( szValue[pszKey[1]-pszKey[0]]) ;

    for( i = 0 ; i < 2 ; i++ ){
				nIndex = ParamSearch( pszKey[i], pszValue[i] );
        
        switch(GetParamType(nIndex , pRcInfo)){
          case PARAM_TYPE_LANGUAGE :;          
          case PARAM_TYPE_STRING :;
            nResult = GetSelectItem( nIndex, pszValue[i], pRcInfo );
            break ;
          case PARAM_TYPE_NUMERICAL :;
            nResult = EntrySelectRange( nIndex, pszValue[i], pRcInfo );
            break ;
          default :;
            nResult = -1 ;
            break ;
        } ;
        
      if( nResult != 0 ){
        break ;
      }
    }

    return nResult ;  
}
#endif/* BR_CONSTRAINT */


/*-------------------------------------------------------------------------------------
*Name           : GetSelectItem
*Description    : {,,...}ÎœËµÒ€ì€¿Æ¥Æ¥ï¿œï¿œï¿œï¿œï¿œï¿œï¿œ
*Parameters     : 
*        nIndex : Ñ¥ï¿œIDï¿œnum BR_PARAMETERSï¿œ
*      pszValue : ï¿œï¿œÊžï¿œ
*       pRcInfo : ×¥ï¿œê¥œï¿œ
*Return         : 
*             0 : 5ïœªÎ»
*            -1 : é¡ŒÎ»Êœé¡Œï¿œÍ­ï¿œÜ€Ê€Ã€ï¿œ
*--------------------------------------------------------------------------------------*/
int
GetSelectItem( int nIndex, char *pszValue, BR_RESOURCE_INFO *pRcInfo )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	int		nResult = -1;
	int		fLoop;
	int		nLen;
	char	szBuf[LINE_BUFFER+1];
	char	*pszWk;
	BR_PARAM_INFO	*pParam;
	
	if( pszValue[0] != '{' ){
		/* é¡Œ */
		return nResult;
	}
	pszValue++;

	pParam = &(pRcInfo->aParams[nIndex]);

	fLoop = 1;
	while( fLoop ){
		/* Þ¶ï¿œÚ€ï¿œ*/
		pszWk = strchr( pszValue, ',' );
		if( pszWk == NULL ){
			/* Þ¹ï¿œÜ¶ï¿œÚ€ìž«Ä€ï¿œÃŒï¿œ*/
			pszWk = strchr( pszValue, '}' );
			if( pszWk == NULL ){
				/* ÃŒÊ€é¡Œ */
				nResult = -1;
				break;
			}
			else{
				/* ÃŒÐ¡Æ¥ï¿œï¿œÂ¹Ôžï¿œ×œÎ»ï¿œï¿œ */
				fLoop = 0;
			}
		}

		/* szBufË¥Æ¥ï¿œï¿œ(pszWkÏ¥Æ¥àœªÃŒØ€Æ€ï¿œ */
		nLen = (int)(pszWk - pszValue);
		strncpy( szBuf, pszValue, nLen );
		szBuf[nLen] = '\0';

		/* Î¹ï¿œï¿œï¿œØ€ */
		pszValue += nLen+1;

		/* Æ¥ï¿œï¿œÏ¿ï¿œ*/
		if( ValidateRcItem( szBuf, pParam ) == 1 ){
			nResult = 0;
		}
	}
	
	return nResult;
}


/*-------------------------------------------------------------------------------------
*Name           : ValidateRcItem
*Description    : ï¿œï¿œï¿œÎ¥Æ¥ï¿œÆ¥dÍ­Æ¥ï¿œï¿œï¿œï¿œ
*Parameters     : 
*       pszItem : Æ¥ï¿œï¿œ
*        pParam : Ñ¥ï¿œê¥œï¿œ
*Return         : 
*             1 : Í­ï¿œÏ¿OK
*             0 : ê¥œï¿œï¿œË»ï¿œê¥¢Æ¥à€¬Ä€ï¿œÃ€
*--------------------------------------------------------------------------------------*/
int
ValidateRcItem( char *pszItem, BR_PARAM_INFO *pParam )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	int		nResult = 0;
	int		nItemIdx;

	/* Ñ¥ï¿œï¿œï¿œï¿œÆ¥ï¿œÍ­Þ¡ï¿œ*/
	for( nItemIdx = 0; nItemIdx < pParam->nItemNum; nItemIdx++ ){
#ifdef _LINUX_STD_
		if( strcmp( pszItem, pParam->paCmdItemList[nItemIdx] ) == 0 ){
#else
		if( strcmp( pszItem, pParam->paRcItemList[nItemIdx] ) == 0 ){
#endif
			/* ï¿œÝ¥Æ¥àž¡Ð¡5ïœªÎ»ï¿œÏ¿ */
			pParam->aValid[nItemIdx] = 1;
			nResult = 1;
			break;
		}
	}

	return nResult;
}


/*-------------------------------------------------------------------------------------
*Name           : EntrySelectRange
*Description    : {"~"}ÎœËµÒ€ì€¿ï¿œÏ»ï¿œï¿œï¿œï¿œï¿œÍ€ï¿œÏ¿ï¿œ
*Parameters     : 
*        nIndex : Ñ¥ï¿œIDï¿œnum BR_PARAMETERSï¿œ
*       pszItem : Æ¥ï¿œï¿œ
*       pRcInfo : ×¥ï¿œê¥œï¿œ
*Return         : 
*             0 : 5ïœªÎ»
*            -1 : é¡ŒÎ»Êœé¡Œï¿œï¿œé¡Œï¿œ
*--------------------------------------------------------------------------------------*/
int
EntrySelectRange( int nIndex, char *pszItem, BR_RESOURCE_INFO *pRcInfo )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	int		nResult = 0;
	int		nLen1;
	int		nLen2;
	int		num1, num2;
	char	*pszWk1 = NULL;
	char	*pszWk2 = NULL;
	char	szBuf1[LINE_BUFFER+1];
	char	szBuf2[LINE_BUFFER+1];
	BR_PARAM_INFO	*pParam;

	/* ï¿œÝ¥Ñ¥ï¿œÎŸï¿œØ¥ */
	pParam = &(pRcInfo->aParams[nIndex]);

DEBUGPRINT("EntrySelectRange: index(%d) param(%s)\n",nIndex,pszItem);

	if( pszItem == NULL ){
		/* ï¿œï¿œé¡Œ */
		return -1;
DEBUGPRINT("EntrySelectRange error: param NULL\n");
	}
	if( pszItem[0] != '{' ){
		/* é¡Œ */
		return -1;
DEBUGPRINT("EntrySelectRange error: format error '{'\n");
	}
	pszItem++;

	if( pszItem != NULL ) pszWk1 = strchr( pszItem, '~' );
	if( pszWk1 != NULL ) pszWk2 = strchr( pszWk1, '"' );

	if( pszItem[0] != '"' || pszWk1 == NULL || pszWk2 ==NULL ){
		/* "~"ÎœË³ï¿œÊ€é¡Œ */
		nResult = -1;
DEBUGPRINT("EntrySelectRange error: ([0]=%c) (~=%d) (\"=%d)\n",pszItem[0],pszWk1,pszWk2);
	}
	else{
		/* Ä€Î¹ï¿œÜ€ï¿œï¿œ */
		nLen1 = pszWk1 - pszItem-1;
		nLen2 = pszWk2 - pszWk1-1;
		strncpy( szBuf1, pszItem+1, nLen1 );
		strncpy( szBuf2, pszWk1+1, nLen2 );
		szBuf1[nLen1] = '\0';
		szBuf2[nLen2] = '\0';

		num1 = atoi(szBuf1);
		num2 = atoi(szBuf2);

DEBUGPRINT("EntrySelectRange: Min(%s) Max(%s)\n",szBuf1,szBuf2);
		/* ï¿œï¿œ*/
		pParam->nMin = MIN(num1, num2);
		/* ï¿œï¿œ */
		pParam->nMax = MAX(num1, num2);
	}

	return nResult;
}


/*-------------------------------------------------------------------------------------
*Name           : ApplyCommandParameters
*Description    : Þ¥É°ÎŒï¿œï¿œ
*Parameters     : 
*          argc : Ä¿
*          argv : ï¿œï¿œ
*       pRcInfo : ×¥ï¿œê¥œï¿œ
*Return         : 
*             0 : 5ïœªÎ»
*        ï¿œ : é¡ŒÎ»
--------------------------------------------------------------------------------------*/
int
ApplyCommandParameters( int argc, char *argv[], BR_RESOURCE_INFO *pRcInfo )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	char	szError[LINE_BUFFER+1];
	int		nResult = 0;
	int		nIndex;
	int		nCnt;
	int		nRet;

	/*----------------------------------------------------------------*/
	/* argv[1] = -P , argv[2] = ×¥ï¿œÌŸ                            */
	/* Îžå¡¢Ä¥Ã¥È€Ç¥Þ¥ï¿œï¿œï¿œï¿œï¿œÍ€È€ï¿œï¿œÊ€ï¿œ*/
	/*----------------------------------------------------------------*/

    // 1. Apply param from 3rd param. brprintconfpt1_td2020 -P TD-2020 -media 30x30...
	for( nCnt = 3; nCnt < argc; nCnt += 2 ){
#ifdef _PTOUCH_UP1_ // Added by SteadyBJ, Zhang Tianxia 2013.05.13 for Update QL-Base
        // 1.1 Ignore -rcfile command.
        if(0 == strcmp(argv[nCnt], BR_CONF_CMD_QL_RC_NAME))
        {
            nCnt += 2;
            continue;
        }
#endif // End _PTOUCH_UP1_

        // if nCnt = argc -2, nCnt +=2; then argv[nCnt] = 0x00, so "CommandSearch" will run error.
        // BR_CONF_CMD_QL_RC_NAME should ignore and continue. 
		nIndex = CommandSearch( argv[nCnt] );
		switch( nIndex ){
#ifndef _LINUX_STD_
		case BR_PARAM_ID_MEDIA:
		case BR_PARAM_ID_RESOLUTION:
		case BR_PARAM_ID_MIRROR_PRINT:
		case BR_PARAM_ID_PAPER_TYPE:
		case BR_PARAM_ID_PAPER_SOURCE:
		case BR_PARAM_ID_COLOR_OR_MONO:
		case BR_PARAM_ID_COLOR_MATCH:

    case BR_PARAM_ID_CAPT:
    case BR_PARAM_ID_ImpoveGray:
    case BR_PARAM_ID_EnBlkPrinting:
    case BR_PARAM_ID_TonerSaveMode:
    case BR_PARAM_ID_SleepTime:
    case BR_PARAM_ID_HRC:
    case BR_PARAM_ID_LANDSCAPEADJUSTMENT:		// added by liubin 2005.7.20
#endif

#ifdef _LINUX_STD_
		case BR_PARAM_ID_QL_Compress:	// Satyam added for QL720NW
		case BR_PARAM_ID_QL_Collate:	// 2006.02.23 added by Liu Bin
		//case BR_PARAM_ID_QL_AutoCut:
		case BR_PARAM_ID_QL_CutAtEnd:   //Satyam added for QL570
		case BR_PARAM_ID_QL_Trimtape: /* QL720NW */
		case BR_PARAM_ID_QL_Halftone:
		case BR_PARAM_ID_QL_MirrorPrinting:
		case BR_PARAM_ID_QL_Quality:
		case BR_PARAM_ID_QL_Resolution:
		case BR_PARAM_ID_QL_MediaSize:
#endif
			/* j??????ÃŒ??ï¿¥?ï¿¥???Ãªï¿¥??????????Ãªâ¬1???*/
			nRet = SetIndicatedCmdParam( nIndex, argv[nCnt+1], pRcInfo );
#ifdef _CUSTOM_TAPE_
			if(nIndex == BR_PARAM_ID_QL_MediaSize)
			{
				if( -1 == nRet )
				{
					int i;
					for( i = 0; i < g_tapelist.count; i ++)
					{
						if( strcmp(g_tapelist.tapelist[i].tape_name, argv[nCnt+1]) == 0)
						{
							g_tapelist.iSelIndex = i;
							nRet = 0;
							break;
						}
					}
				}
				else
				{
					g_tapelist.iSelIndex = -1;
				}
				
			}
#endif
			break;
		case BR_PARAM_ID_COPIES:
#ifndef _LINUX_STD_
		case BR_PARAM_ID_BRIGHTNESS:
		case BR_PARAM_ID_CONTRAST:
		case BR_PARAM_ID_RED_KEY:
		case BR_PARAM_ID_GREEN_KEY:
		case BR_PARAM_ID_BLUE_KEY:
    case BR_PARAM_ID_Saturation:
#endif
#ifdef _LINUX_STD_
		case BR_PARAM_ID_QL_CutLabel:		//Satyam added for QL570
       	case BR_PARAM_ID_QL_Brightness:
       	case BR_PARAM_ID_QL_Contrast:
       	case BR_PARAM_ID_QL_Feed:
#endif
			/* ÄŸï¿œï¿œÎ¥Ñ¥ï¿œê¥œï¿œï¿œï¿œê€¹ï¿œ*/
			nRet = SetNumericalParam( nIndex, argv[nCnt+1], pRcInfo, 1 );
			break;

		case BR_PARAM_ID_LANGUAGE:
			/* 8ï¿œÞ¥É»ï¿œï¿œ */
		default:
			/* ÌµÞ¥ï¿œ*/
			nRet = -1;
			break;
		}
DEBUGPRINT("ApplyCommandParameters: index(%d) nRet(%d)\n", nIndex, nRet);

		if( nRet == 0 ){
			/* 5ï¿œ*/
		}
		else{
			/* é¡Œ */
			switch( nRet ){
			case -1: nResult = BR_ERROR_OPTION;		break;	/* ×¥ï¿œé¡Œ */
			case -2: nResult = BR_ERROR_PROHIBITEM;	break;	/* ï¿œï¿œï¿œÄ¥Æ¥à€¬jï¿œì€¿ */
			case -3: nResult = BR_ERROR_OORITEM;	break;	/* ï¿œï¿œï¿œï¿œÏ€ËŒÞ€Ã€Æ€Ê€ */
			}
			sprintf( szError, "%s %s", argv[nCnt], argv[nCnt+1] );
			return BrError( nResult, szError );
		}
	}

	return nResult;
}


/*-------------------------------------------------------------------------------------
*Name           : SaveRcFile
*Description    : ê¥œÕ¥ï¿œÐ€
*Parameters     : 
*   pszFilename : ê¥œÕ¥ï¿œÕ¥ï¿œ
*       pRcInfo : ×¥ï¿œê¥œï¿œ
*Return         : 
*             0 : 5ïœªÎ»
*        ï¿œ : é¡ŒÎ»
--------------------------------------------------------------------------------------*/
int
SaveRcFile( char *pszFilename, BR_RESOURCE_INFO *pRcInfo )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	FILE	*fp;
	int		nResult = 0;
	int		nIndex;
//	fprintf(stderr, "ERROR: save to %s \n", pszFilename);
	if( (fp = fopen( pszFilename, "w" )) == NULL ){
		return BrError( BR_ERROR_FILEOPEN, pszFilename );
	}

	/* ×¥ï¿œÌŸï¿œï¿œ*/
	fprintf( fp, "[%s]\n", pRcInfo->szPrinterName );

	for( nIndex = 0; nIndex < pRcInfo->nParamNum; nIndex++ ){
		PutParamRcForm( fp, nIndex, pRcInfo );
	}

	fclose(fp);
	chmod(pszFilename, 00666);

	return nResult;
}


/*-------------------------------------------------------------------------------------
*Name           : PutParamRcForm
*Description    : Æ¥Ñ¥ï¿œÎ¥ê¥œï¿œï¿œ
*Parameters     : 
*            fp : Õ¥ï¿œ
*        nIndex : ï¿œï¿œÖ¹ï¿œ
*       pRcInfo : ×¥ï¿œê¥œï¿œ
*Return         : Ê€
--------------------------------------------------------------------------------------*/
void
PutParamRcForm( FILE *fp, int nIndex, BR_RESOURCE_INFO *pRcInfo )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	BR_PARAM_INFO	*pParam;

	/* ï¿œÝ¥Ñ¥ï¿œÎŸï¿œØ¥ */
	pParam = &(pRcInfo->aParams[nIndex]);

	switch( nIndex ){
#ifndef _LINUX_STD_
  case BR_PARAM_ID_RESOLUTION:
		{
			short	nResoIdx;

			/* Resolutionï¿œhostscriptï¿œï¿œÑ¥ï¿œï¿œËœï¿œÏ€ï¿œ*/
			/* Ghostscriptï¿œÏ¡1200x600/1200x1200dpiï¿œï¿œï¿œ00dpiï¿œÑŽï¿œï¿œï¿œ*/
			nResoIdx = ( (pParam->nIndex > QUALITY_ENH_IDX) ? QUALITY_HIGH_IDX : pParam->nIndex );
			fprintf( fp, "%s=%s\n", BR_PARAM_KEY_REAL_RESO, pParam->paRcItemList[nResoIdx] );
      break;
		}
		break;

  case BR_PARAM_ID_MEDIA:
	case BR_PARAM_ID_MIRROR_PRINT:
	case BR_PARAM_ID_PAPER_TYPE:
	case BR_PARAM_ID_PAPER_SOURCE:
	case BR_PARAM_ID_COLOR_OR_MONO:
	case BR_PARAM_ID_COLOR_MATCH:
	case BR_PARAM_ID_LANGUAGE:

  case BR_PARAM_ID_CAPT:
  case BR_PARAM_ID_ImpoveGray:
  case BR_PARAM_ID_EnBlkPrinting:
  case BR_PARAM_ID_TonerSaveMode:
  case BR_PARAM_ID_SleepTime:
  case BR_PARAM_ID_HRC:
  case BR_PARAM_ID_LANDSCAPEADJUSTMENT:
#endif
#ifdef _LINUX_STD_
		case BR_PARAM_ID_QL_Compress:	//Satyam added for QL720NW  #S1
		case BR_PARAM_ID_QL_Collate:		// 2006.02.23 added by Liu Bin
		//case BR_PARAM_ID_QL_AutoCut:
		case BR_PARAM_ID_QL_CutAtEnd:        //Satyam added for QL570
		case BR_PARAM_ID_QL_Trimtape:  /* QL720NW */
		case BR_PARAM_ID_QL_Halftone:
		case BR_PARAM_ID_QL_MirrorPrinting:
		case BR_PARAM_ID_QL_Quality:
		case BR_PARAM_ID_QL_Resolution:
		case BR_PARAM_ID_QL_MediaSize:
#endif
#ifdef _LINUX_STD_
#ifdef _CUSTOM_TAPE_
		if(nIndex == BR_PARAM_ID_QL_MediaSize && g_tapelist.iSelIndex > -1)
		{
			fprintf( fp, "%s=%s\n", pParam->szKey, g_tapelist.tapelist[g_tapelist.iSelIndex].tape_id );
		}
		else
		{
			fprintf( fp, "%s=%s\n", pParam->szKey, pParam->paCmdItemList[pParam->nIndex] );
		}
#else
		fprintf( fp, "%s=%s\n", pParam->szKey, pParam->paCmdItemList[pParam->nIndex] );
#endif
#else
		fprintf( fp, "%s=%s\n", pParam->szKey, pParam->paRcItemList[pParam->nIndex] );
#endif
		break;
	case BR_PARAM_ID_COPIES:
#ifndef _LINUX_STD_
	case BR_PARAM_ID_BRIGHTNESS:
	case BR_PARAM_ID_CONTRAST:
	case BR_PARAM_ID_RED_KEY:
	case BR_PARAM_ID_GREEN_KEY:
	case BR_PARAM_ID_BLUE_KEY:

	case BR_PARAM_ID_Saturation:
#endif
#ifdef _LINUX_STD_
		case BR_PARAM_ID_QL_CutLabel:    //Satyam added for QL570
       	case BR_PARAM_ID_QL_Brightness:
       	case BR_PARAM_ID_QL_Contrast:
       	case BR_PARAM_ID_QL_Feed:
#endif
		/* ÄŸï¿œï¿œ */
		fprintf( fp, "%s=%d\n", pParam->szKey, pParam->nValue );
		break;
	default:
		/* ÌµÞ¥ï¿œ*/
		break;
	}
}

#ifdef  BR_CONSTRAINT               /* Added by Chenxujin , SteadyBJ , 2004.11.17 */
/*-------------------------------------------------------------------------------------
*Name           : CheckConstraints
*Description    : Check settings with constraints
*Parameters     :
*       pRcInfo : the resource information struct
*Return         :
*             0 : settings passed
*       nonzero : settings not passed.
*--------------------------------------------------------------------------------------*/
int
CheckConstraints( BR_RESOURCE_INFO * pRcInfo )
{
	//fprintf(stderr, "ERROR:In %s file, %s function\n", __FILE__, __FUNCTION__);
	char	szBuf[LINE_BUFFER+1];
  char  szValue[LINE_BUFFER+1];
  char  szPSet[A_VALUE_BUF] , szSSet[A_VALUE_BUF] ;
  int   IndexP , IndexS ;
  char * pszPKey , * pszSKey , * pszPValue , * pszSValue , * psz ;
  BR_PARAM_TYPE typeP , typeS ;
  
  int nResult = 0 ;
  int i , iCount ;

  iCount = 0 ; 
  for( i = 0 ; i < pRcInfo->constraint.nCount ; i++ ){
    memset(szBuf , 0 , LINE_BUFFER+1 ) ;
    memset(szValue , 0 , LINE_BUFFER+1 ) ;

    /* Get a constraint */
    strncpy(szBuf , pRcInfo->constraint.paConstraintList[i] , strlen( pRcInfo->constraint.paConstraintList[i] ) ) ;
    pszPKey = szBuf ;
    pszPValue = szValue ;
    pszSKey = strchr( szBuf , '*' ) ;
    if( pszSKey == NULL ){
      continue ;
    }
    *pszSKey = 0 ;
    pszSKey++ ;

    pszSValue = pszPValue + (pszSKey - pszPKey ) ;

    /* Indicate the Primary and Slave Key Index */
    IndexP = ParamSearch( pszPKey, pszPValue );
    IndexS = ParamSearch( pszSKey, pszSValue );

    psz = strchr( pszPKey , '=') ;
    if( psz == NULL ){
       continue ;
    }
    else
    {
       *psz = 0 ;
       pszPValue = psz+1;
    }

    psz = strchr( pszSKey , '=') ;
    if( psz == NULL ){
       continue ;
    }
    else
    {
       *psz = 0 ;
       pszSValue = psz+1;
    }

    typeP = GetParamType(IndexP , pRcInfo ) ;
    typeS = GetParamType(IndexS , pRcInfo ) ;

    /* Get value of the Primary Parameters */
    if( GetParamItemValue( IndexP , pRcInfo , szPSet , A_VALUE_BUF ) != 0 ){
      continue ;
    }

    /* Check value of the Primary Key */    
    if( IsItemHit(typeP , szPSet , pszPValue ) == 0 ){ /* Primary Parameter value not hit */
      continue ;
    }

    /* Get value of the Slave Parameter */
    if( GetParamItemValue( IndexS , pRcInfo , szSSet , A_VALUE_BUF ) != 0 ){
      continue ;
    }

    /* Check value of the Slave Key */
    if( IsItemHit(typeS , szSSet , pszSValue ) == 0 ){  /* constraint check not pass */
      if( iCount == 0 ){
        fprintf(stderr , "Constraint check Failed!!!\n");        
      }
      fprintf(stderr , "C%02d: %s\n" , i , pRcInfo->constraint.paConstraintList[i] );
      fprintf(stderr , "  vv P1: %s=%s\n" , pszPKey , szPSet );
      fprintf(stderr , "  xx P2: %s=%s\n" , pszSKey , szSSet );
      iCount++;
      
      nResult = -1 ;
      continue ;
    }
  }

  if( iCount > 0 ){
    fprintf(stderr , "Total %d constraint(s) not passed.\n", iCount ) ;
  }

  return nResult ;
}

#endif

