/*=================================================================================*
*FileName:     	model_1030.h
*Description:	model functions for 1030
*Revision:     	1.0									
*Date:         	2003.08.28							
*Author:       	Chenxujin , SteadyBJ 									
*Histroy:      	1.Chenxujin , Create
*==================================================================================*/
#ifndef _MODEL_1030_H_
#define _MODEL_1030_H_

//#include <cups/cups.h>
//#include <cups/raster.h>

#include "../pd.h"
#include "../modelfunctions.h"

#ifdef _cplusplus
extern "C" {
#endif/*_cplusplus*/
#define _LPR_
#ifdef _LPR_
extern	short	MBeginJob_QL( LPPTPARAM sParam );
extern	short	MBeginPage_QL(	int iPage ) ;
#else
extern	short	MBeginJob_QL(	cups_page_header_t * header , LPPTPARAM sParam );
extern	short	MBeginPage_QL(	cups_page_header_t *		header , int iPage ) ;
#endif
extern	short	MEndJob_QL() ;
extern	short	MEndPage_QL( short sLastPage ) ;
extern	short	MSendBand_QL( LPPTPARAM sParam ) ;
extern	short	MSendData_QL( send_buffer * send_buf 					) ;					
extern	void	CompressM9_QL( /* MODE9 * compData , cups_page_header_t *	header*/  ) ;

#ifdef _cplusplus
}
#endif/*_cplusplus*/

#endif/*_MODEL_1030_H_*/
