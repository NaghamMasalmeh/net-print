/* $Id: brerror.c,v 1.3 2005/06/29 07:16:22 cvs Exp $ */

/* 
* Copyright (C) 2003-2013 Brother. Industries, Ltd.
*
* This program is free software; you can redistribute it and/or modify it
* under the terms of the GNU General Public License as published by the Free
* Software Foundation; either version 2 of the License, or (at your option)
* any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
* more details.
*
* You should have received a copy of the GNU General Public License along with
* this program; if not, write to the Free Software Foundation, Inc., 59 Temple
* Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>

#include "brerror.h"

/************************************************************/
// BrError
// Output error info to stderr.
/************************************************************/
int
BrError( int error_cd, char *msg )
{
    switch( error_cd ){
    case BR_ERROR_FILEOPEN:
        if (msg != NULL)
        {
            fprintf( stderr, "Error: %s :cannot open file !!\n",msg );
        }
        else
        {
            fprintf( stderr, "Error: cannot open file !!\n" );
        }
        break;
    case BR_ERROR_OPTION:
        if (msg != NULL)
        {
            fprintf( stderr, "Error: %s :invalid option !!\n",msg );
        }
        else
        {
            fprintf( stderr, "Error: invalid option !!\n");
        }
        break;
    case BR_ERROR_EXCEPTION:
        fprintf( stderr, "Error: exception handling !!\n" );
        break;
    case BR_ERROR_NOSECTION:
        fprintf( stderr, "Error: section not found !!\n" ); /* ̤���� */
        break;
    case BR_ERROR_RCPRNNAME:
        fprintf( stderr, "Error: invalid printer name at rc-file !!\n" );
        break;
    case BR_ERROR_PAPERINF:
        fprintf( stderr, "Error: %s :invalid format found in paperinf !!\n", msg );
        break;
    case BR_ERROR_NOTFOUND:
        fprintf( stderr, "Error: %s: paper info not found in paperinf !!\n", msg );
        break;
    case BR_ERROR_UNKOWNMDL:
        fprintf( stderr, "Error: %s: this model is not supported !!\n", msg );
        break;
    case BR_ERROR_MEMORY:
        fprintf( stderr, "Error: memory allocation failed !!\n" );
        break;
    case BR_ERROR_PRTFAIL:
        fprintf( stderr, "Error: error occurred at print phase !!\n" );
        break;
    case BR_ERROR_PROHIBITEM:
        if (msg != NULL)
        {
            fprintf( stderr, "Error: %s :prohibited item is selected !!\n",msg );
        }
        else
        {
            fprintf( stderr, "Error: prohibited item is selected !!\n" );
        }
        break;
    case BR_ERROR_OORITEM:
        if (msg != NULL)
        {
            fprintf( stderr, "Error: %s :out of setting range !!\n",msg );
        }
        else
        {
            fprintf( stderr, "Error: out of setting range !!\n" );
        }
        break;
    default:
        break;
    }

    return error_cd;
}

