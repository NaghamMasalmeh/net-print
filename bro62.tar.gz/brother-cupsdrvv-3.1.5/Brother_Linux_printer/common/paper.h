/* $Id: paper.h,v 1.4 2005/07/28 13:38:30 cvs Exp $ */

/* 
* Copyright (C) 2003 Brother. Industries, Ltd.
*
* This program is free software; you can redistribute it and/or modify it
* under the terms of the GNU General Public License as published by the Free
* Software Foundation; either version 2 of the License, or (at your option)
* any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
* more details.
*
* You should have received a copy of the GNU General Public License along with
* this program; if not, write to the Free Software Foundation, Inc., 59 Temple
* Place, Suite 330, Boston, MA  02111-1307  USA
*/
/*=================================================================================*
*FileName:     	paper.h
*Description:	function for paper selection
*Revision:     	1.0									
*Date:         	2003.08.28							
*Author:       	Chenxujin , SteadyBJ 									
*Histroy:      	1.Chenxujin , Create
*==================================================================================*/
#ifndef _PAPER_H_
#define _PAPER_H_
//#include <cups/cups.h>
//#include <cups/raster.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>

#include"pd.h"
#include "define.h"	//added by zhangshumin. 2005.06.03

#ifdef _cplusplus
extern "C" {
#endif/*_cplusplus*/

#ifndef _STDBJ_LINUX_ //zhangshumin, 2005.06.03.
extern	short checkSendPaper(unsigned char **name, short height, short width, long *offset) ;
#else
extern	short checkSendPaper(short height, short width) ;
#endif

#ifdef _cplusplus
}
#endif/*_cplusplus*/

#endif/*_PAPER_H_*/
