/* $Id: tempfile.c,v 1.2 2005/06/21 11:49:59 cvs Exp $ */

/*
* Copyright (C) 2003-2004 Brother. Industries, Ltd.
*
* This program is free software; you can redistribute it and/or modify it
* under the terms of the GNU General Public License as published by the Free
* Software Foundation; either version 2 of the License, or (at your option)
* any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
* more details.
*
* You should have received a copy of the GNU General Public License along with
* this program; if not, write to the Free Software Foundation, Inc., 59 Temple
* Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "string.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <unistd.h>

/*-------------------------------------------------------------------------------------
*Name           : myTempFd
*Description    : Create a temporary file.
*Parameters     :
*      filename : buffer to return the created file name.
*           len : length of the buffer
*Return         : file descriptor
*          >= 0 : valid file descriptor
*           < 0 : invalid file descriptor
*--------------------------------------------------------------------------------------*/
int myTempFd(char *filename, int  len)
{
  int		fd;
  int		tries;
  const char	*tmpdir;
  struct timeval curtime;		    /* Current time */
  static char	*buf = NULL;		/* Buffer if you pass in NULL and 0 */

  /*
  * See if a filename was specified...
  */

  if (filename == NULL)
  {
    if (buf == NULL)
      buf = calloc(1024, sizeof(char));

    if (buf == NULL)
      return (-1);

    filename = buf;
    len      = 1024;
  }

 /*
  * See if TMPDIR is defined...
  */

  if ((tmpdir = getenv("TMPDIR")) == NULL)
  {
   /*
    * Put root temp files in restricted temp directory...
    */

     tmpdir = "/tmp";
  }

 /*
  * Make the temporary name using the specified directory...
  */
   tries = 0;
  do
  {
   /*
    * Get the current time of day...
    */

    gettimeofday(&curtime, NULL);

   /*
    * Format a string using the hex time values...
    */

    snprintf(filename, len - 1, "%s/%08lx%05lx", tmpdir,
             (unsigned long)curtime.tv_sec, (unsigned long)curtime.tv_usec);

   /*
    * Open the file in "exclusive" mode, making sure that we don't
    * stomp on an existing file or someone's symlink crack...
    */

    fd = open(filename, O_RDWR | O_CREAT | O_EXCL/* | O_NOFOLLOW*/, 0600);

    if (fd < 0 && errno != EEXIST)
      break;

    tries ++;
  }
  while (fd < 0 && tries < 1000);

 /*
  * Return the file descriptor...
  */

  return (fd);
}

/*-------------------------------------------------------------------------------------
*Name           : myTempFile
*Description    : Create a temporary file.
*Parameters     :
*      filename : buffer to return the created file name.
*           len : length of the buffer
*Return         : file name
*--------------------------------------------------------------------------------------*/
char *  myTempFile(char *filename,  int  len)
{
  int		fd;			/* File descriptor for temp file */
  static char	buf[1024] = "";		/* Buffer if you pass in NULL and 0 */


 /*
  * See if a filename was specified...
  */
  if (filename == NULL)
  {
    filename = buf;
    len      = sizeof(buf);
  }

 /*
  * Create the temporary file...
  */

  if ((fd = myTempFd(filename, len)) < 0)
    return (NULL);

 /*
  * Close the temp file - it'll be reopened later as needed...
  */

  close(fd);

 /*
  * Return the temp filename...
  */
  return (filename);
}

