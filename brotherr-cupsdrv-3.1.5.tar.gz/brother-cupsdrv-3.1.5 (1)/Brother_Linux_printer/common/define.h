#ifndef _DEFINE_H_
#define _DEFINE_H_


#define _PTOUCH_		// added by Liu Bin 2005.12

#define _STDBJ_LINUX_
//#define _MY_DEBUG_

#define _PTOUCH_UP1_	// Added by SteadyBJ, Zhang Tianxia 2013.05.13 for Update QL-Base

#include <stdio.h>
#include "status.h"
#define	kNumBlankData			( 600 )

enum {
	NoErr = 0,
	Err_NoMedia = 0x01L,
	Err_MediaEnd,
	Err_BufFull,
	Err_Cutter,
	Err_MediaChg,
	Err_MediaSize,
	Err_MediaType,
	Err_DataRemain,
	Err_LowPower,
	Err_CoverOpen,
	Err_PrinterType,
	Err_Feed,
	Err_ACAdaptor,
	Err_TimeOut,
	Err_NoMemory,
	Err_NoDisk,
	Err_InvalPort,
	Err_PortBusy,
	Err_SysVer,
	Err_ResFail,
	Err_NoHeap,
	Err_NoBps,
	Err_TapeLen,
	Err_Margin,
	Err_Unknown,
	Err_PrinterBusy,
	Err_CopiesMaxOver,
	Err_CoolingStart,	//02.09.20
	Err_CoolingEnd,		//02.09.20
	Err_HGTape			// 2003.06.16 add for PT-9500

};
#define	Err_MAX		(Err_HGTape)

#define Err_IOErr 	Err_TimeOut
#define	UnknownErr		"Unknown error occurred."

typedef int bool;
typedef unsigned long DWORD;


#define FALSE 0
#define TRUE   1
#define true 1
#define false 0

//#define MEDIA_TYPE_FILE "/usr/local/Brother/PTouch/ql550/src/brmediatypesrc"
#define STATUSINFO		"/var/tmp/Stdshared2005102601"
//#define COMMANDINFO	"/var/tmp/Stdshared2005102602"

#define _CMD_START_COOL_		0x7315	// virsul machine start hot
#define _CMD_END_COOL_			0x7316	// virsul machine end hot

#define _CMD_START_PRINT_		0x7317	// virsul machine start print data
#define _CMD_END_PRINT_		0x7318	// virsul machine end print data
#define _CMD_PRINT_COMPLTED_	0x7319	// virsul machine send printing completd

#define _CMD_START_ERR_  		0x7320	// virsul machine start error
#define _CMD_END_ERR_   		0x7321	// virsul machine end error

#define _CMD_INITIALIZE_ 			0x7322	// initialize machine

#define _CMD_OPEN_DOOR_ 		0x7323	// open door
#define _CMD_CLOSE_DOOR_ 		0x7324	// close door

#define _CMD_POWER_OFF_		0x7325	// power off
#define _CMD_SET_				0x7326	// set buffer size in the machine
#define _CMD_GET_				0x7327	// get buffer size in the machine


//#define COMMAND_FIFO "/tmp/test_pipe"

typedef struct                                                                             	
{                                                                                                                       	
	bool bVisiting;			// TRUE: the data is being visited

	bool bChanged;		// nCMD is updated
	DWORD nCMD;		// the new command
	DWORD nParam;		// the parameter
} CommandInfo;

typedef struct
{
	bool bVisiting;		// TRUE: the data is being visited

	int iPr_count;		// Count the printing status
	int iPrc_count;	// Count the printing completed status
	bool bError;		// an error occurs
	bool bReceiving;	// ready to recive data
//	PrinterStatus printer_status;	// device status information
} StautsInfo;



//#define DEBUGMSG printf
#define _MAX_BUF_ 1024
#define _TEMP_FILE_HEADER_      "/var/tmp/ptouchbak_header"
//#define _TEMP_FILE_             "/var/tmp/ptouchbak_QL720NW_%d" 
#define _TEMP_FILE_             "/var/tmp/ptouchbak_%d_%d" 
#define _TEMP_INIT_FILE_        "/var/tmp/ptouchinitBRQL_%d"

#define _LPR_FUNC_FORMAT_       "/opt/brother/PTouch/%s/inf/br%sfunc"
#define _IMAGING_AREA_FORMAT_   "/opt/brother/PTouch/%s/inf/ImagingArea"    // for ImagingArea
#define _PAPER_DIM_FORMAT_      "/opt/brother/PTouch/%s/inf/PaperDimension" // for PaperDimension

//#define _PAPER_NAMEBADGE_      "/opt/brother/PTouch/ql720nw/inf/pdt3534.bin" // for PaperDimension
#define _PAPER_NAMEBADGE_      "/opt/brother/PTouch/%s/inf/pdt3534.bin" // for PaperDimension

#define _IMAGING_INFO_FORMAT_   "%s:\t%.2f\t%.2f\t%.2f\t%.2f\n"   // for ImagingArea info
#define _IMAGING_INFO_SCANF_    "%s:\t%f\t%f\t%f\t%f\n"           // for ImagingArea info

#define _PAPER_DIM_INFO_FORMAT_ "%s\t:\t%.2f\t%.2f\n"   // for PaperDimension info
#define _PAPER_DIM_INFO_SCANF_  "%s\t:\t%f\t%f\n"       // for PaperDimension info

typedef struct
{
	FILE* pfile;
	char	lpbuf[_MAX_BUF_];
	char	trimbuf[_MAX_BUF_];
	bool	error;
	int iPageCount;
}TTempFile;

typedef struct
{
	TTempFile page_temp;
	FILE* pInitfile;
	char	initfile[_MAX_BUF_];
}
TJobData;


#endif // _DEFINE_H_
