#include <iostream>
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <sys/stat.h>
#include <fcntl.h>
#include <libgen.h>  // For basename()
#include <errno.h>

std::string runCommand(const std::string &command) {
    char buffer[128];
    std::string result;
    FILE *pipe = popen(command.c_str(), "r");
    if (!pipe) {
        std::cerr << "popen() failed!" << std::endl;
        return "";
    }
    while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
        result += buffer;
    }
    pclose(pipe);
    return result;
}

void logprint(int level, const std::string &data) {
    static int LOG_FIRSTTIME = 1;
    const int LOGLEVEL = 7;
    std::string LOGFILE = "/tmp/br_lpdfilter_ink.log";

    if (getenv("LPD_DEBUG") != nullptr) {
        int DEBUG = std::stoi(getenv("LPD_DEBUG"));
        if (DEBUG != 0) {
            std::ofstream logFile;
            if (LOG_FIRSTTIME) {
                logFile.open(LOGFILE, std::ios::out);
                LOG_FIRSTTIME = 0;
            } else {
                logFile.open(LOGFILE, std::ios::app);
            }
            if (level < LOGLEVEL) {
                logFile << data << std::endl;
            }
            logFile.close();
        }
    }
}

int main() {
    std::string FLAG = "";
    std::string offset = "";
    std::string HWMARGINS = "yes";

    char *programName = basename(argv[0]); // Get the name of the program
    std::string PRINTER(programName);
    std::string INPUT_TEMP = "";
    std::string FILE_TYPE = "PostScript";
    std::string BR_PRT_PATH = realpath(programName, nullptr);
    std::string LOG_FIRSTTIME = "1";
    const std::string RCFILE = getenv("BRPRINTERRCFILE") ? getenv("BRPRINTERRCFILE") : "";
    
    if (RCFILE.empty()) {
	std::string RCFILE = BR_PRT_PATH + "/inf/br" + PRINTER + "rc";
    }
    std::string FUNCFILE = BR_PRT_PATH + "/inf/br" + PRINTER + "func";
    std::string PAPERINF = BR_PRT_PATH + "/inf/paperinf" + PRINTER;
    std::string IMAGABLE = BR_PRT_PATH + "/inf/ImagingArea";
    
    FLAG = runCommand("grep 'flags1=' " + FUNCFILE + " | sed s/'flags1='//g");
    if (FLAG.empty()) {
        FLAG = "0000000000000002";
    }
    
    offset = runCommand("grep 'offset=' " + FUNCFILE + " | sed s/'offset='//g");
    
    std::string BRCONV = BR_PRT_PATH + "/lpd/rastertobrpt1";
    std::string BRCONV_OP = "-P " + PRINTER + " -pi " + PAPERINF + " -rc " + RCFILE + " -out cat";
    
    logprint(1, " BRCONV=" + BRCONV + "    PRINTER=" + PRINTER);
    
    if (getenv("PS") != nullptr && std::string(getenv("PS")) == "1") {
        INPUT_TEMP = "";
        FILE_TYPE = "PostScript";
    } else {
        INPUT_TEMP = runCommand("mktemp /tmp/br_input.XXXXXX");
        runCommand("cat > " + INPUT_TEMP);
        FILE_TYPE = runCommand("file " + INPUT_TEMP);
        FILE_TYPE.erase(0, FILE_TYPE.find(":") + 1);
        FILE_TYPE.erase(FILE_TYPE.find_first_of(" "), std::string::npos);
    }
  
    logprint(1, "PRINTER=" + PRINTER);
    logprint(1, "$ENV{PS} = " + std::string(getenv("PS")));
    logprint(1, "$ENV{BRPRINTERRCFILE} = " + std::string(getenv("BRPRINTERRCFILE")));

    std::string papertype;
    std::ifstream fprcfile(RCFILE);
    std::string rcline;
    while (std::getline(fprcfile, rcline)) {
        if (rcline.find("MediaSize") != std::string::npos) {
            papertype = rcline.substr(rcline.find('=') + 1);
            papertype.erase(remove_if(papertype.begin(), papertype.end(), isspace), papertype.end());
        }
    }
    fprcfile.close();

    std::string width = getenv("BRPAPERWIDTH") ? getenv("BRPAPERWIDTH") : "";
    std::string height = getenv("BRPAPERHEIGHT") ? getenv("BRPAPERHEIGHT") : "";
    logprint(1, "$ENV{BRPAPERWIDTH} = " + std::string(getenv("BRPAPERWIDTH")));
    logprint(1, "$ENV{BRPAPERHEIGHT} = " + std::string(getenv("BRPAPERHEIGHT")));
    
    logprint(1, " PAPERINF=" + PAPERINF);

    std::ifstream paperInfFile(PAPERINF);
    std::string line;
    std::string paper;
    while (std::getline(paperInfFile, line)) {
        line.erase(remove_if(line.begin(), line.end(), isspace), line.end());
        if (line.find(papertype) == 0) {
            std::istringstream iss(line);
            iss >> paper >> width >> height;
            break;
        }
    }
    paperInfFile.close();

    int widthInt = std::stoi(width);
    int heightInt = std::stoi(height);
    logprint(1, " TYPE=" + papertype + " w=" + std::to_string(widthInt) + " h=" + std::to_string(heightInt));
  
    std::string size_br = " -ps " + std::to_string(widthInt) + "x" + std::to_string(heightInt);
    std::string size_gs = std::to_string(widthInt) + "x" + std::to_string(heightInt);

    std::string GHOST_SCRIPT = runCommand("which gs");
    std::string OUTPUT_TYPE = "ppmraw";
    std::string GHOST_OPT = "-q -dNOPROMPT -dNOPAUSE -dSAFER -sDEVICE=" + OUTPUT_TYPE + " -sstdout=%stderr -sOutputFile=- - -c quit";

    std::string left, top, right, bottom;
    std::ifstream imagingAreaFile(IMAGABLE);
    while (std::getline(imagingAreaFile, line)) {
        line.erase(remove_if(line.begin(), line.end(), isspace), line.end());
        if (line.find(papertype) == 0) {
            std::istringstream iss(line);
            iss >> paper >> left >> top >> right >> bottom;
            logprint(1, "[" + left + " " + top + " " + right + " " + bottom + "]");
            break;
        }
    }
    imagingAreaFile.close();

    std::string gscommand = (HWMARGINS == "yes") 
        ? "(echo  '<</ImagingBBox [" + left + " " + top + " " + right + " " + bottom + "] /PageOffset [-" + left + " " + top + "]>> setpagedevice'; cat " + INPUT_TEMP + ") | " + GHOST_SCRIPT + " -r" + std::to_string(resolution) + " -g" + size_gs + " " + GHOST_OPT 
        : "cat " + INPUT_TEMP + " | " + GHOST_SCRIPT + " -r" + std::to_string(resolution) + " -g" + size_gs + " " + GHOST_OPT;

    std::string brcommand = BRCONV + " " + BRCONV_OP;

    logprint(1, "**** " + gscommand + " ****");
    logprint(1, "**** " + INPUT_TEMP + " ****");
    logprint(1, "**** debug=" + std::string(getenv("LPD_DEBUG")) + " ****");

    if (std::string(getenv("LPD_DEBUG")) == "1") {
        system((gscommand + " | " + brcommand).c_str());
        logprint(0, gscommand + " | " + brcommand);
    } else {
        std::string TMP_PS1 = "/tmp/br_lpdfilter_ink_gsout_" + std::to_string(getpid()) + ".dat";
        int PRTAREA = getenv("PRTAREA1") ? std::stoi(getenv("PRTAREA1")) : 0;

        if (PRTAREA == 0) {
            runCommand("echo  '<</ImagingBBox [" + left + " " + top + " " + right + " " + bottom + "] /PageOffset [-" + left + " " + top + "]>> setpagedevice' >" + TMP_PS1);
        } else if (PRTAREA == 1) {
            runCommand("echo  '<</PageOffset [0 17]>> setpagedevice' >" + TMP_PS1);
        }

        std::string tmpPS;
        std::string fileType = runCommand("file " + INPUT_TEMP);
        fileType.erase(0, fileType.find(":") + 1);
        fileType.erase(fileType.find_first_of(" "), std::string::npos);

        if (fileType == "PDF\n") {
            tmpPS = "/tmp/tmp_" + std::to_string(getpid()) + ".ps";
            runCommand("/usr/bin/pdf2ps  " + INPUT_TEMP + " " + tmpPS);
            runCommand("cat " + tmpPS + "| sed s/'%%HiResBoundingBox:'/'%HiResBoundingBox:'/g >>" + TMP_PS1);
        } else {
            runCommand("cat " + INPUT_TEMP + " >> " + TMP_PS1);
        }

        brcommand = BRCONV + " -P " + PRINTER + " -pi " + PAPERINF + " -rc " + RCFILE;
        system(("cat " + TMP_PS1 + "| " + GHOST_SCRIPT + " -r" + std::to_string(resolution) + " -g" + size_gs + " " + GHOST_OPT + " | " + brcommand).c_str());
    }

    if (!INPUT_TEMP.empty()) {
        unlink(INPUT_TEMP.c_str());
    }

    return 0;
}
