/* $Id: modelfunction.c,v 1.3 2005/06/29 07:16:22 cvs Exp $ */

/* 
* Copyright (C) 2003 Brother. Industries, Ltd.
*
* This program is free software; you can redistribute it and/or modify it
* under the terms of the GNU General Public License as published by the Free
* Software Foundation; either version 2 of the License, or (at your option)
* any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
* more details.
*
* You should have received a copy of the GNU General Public License along with
* this program; if not, write to the Free Software Foundation, Inc., 59 Temple
* Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdlib.h>

#include "modelfunction.h"
#include "models.h"
#include "model_ink.h"


MFUNTABLE	fun_table = { NULL, NULL, NULL , NULL , NULL , NULL , NULL };


/*-------------------------------------------------------------------------------------
*Name           : SetFunctionTable
*Description    : Set functions depending on printer model
*Parameters     : 
*         model : printer model
*Precondition	: 
*Operation      : Set the model function table.
*Postcondition  : fun_table is set.
*Return         : 
*             0 : Succeeded
*     otherwise : Failed.
*History        : 1.Created , by Chenxjin , SteadyBJ , 2003.09.02
*               : 2004.03.17 �湾 printer model�򥰥����Х�Ǥʤ��������ѹ�
*--------------------------------------------------------------------------------------*/
short	SetFunctionTable( prn_model model )
{
	short	sRet = 0 ;

	switch( model ){
	case MODEL_INK :
	//	fprintf( stderr , "SetFunctionTable() MODEL_INK\n" ) ;
		fun_table.lpfnMInitJob		= MInitJob_INK ;
		fun_table.lpfnMExitJob		= MExitJob_INK ;
		fun_table.lpfnMBeginJob		= MBeginJob_INK ;
		fun_table.lpfnMEndJob		= MEndJob_INK ;
		fun_table.lpfnMBeginPage	= MBeginPage_INK ;
		fun_table.lpfnMEndPage		= MEndPage_INK ;
		fun_table.lpfnMSendBandData = MSendBandData_INK ;

		sRet = 0 ;
		break ;
	default :
		sRet = 1 ;
		break ;
	}

	return sRet ;
}


/*-------------------------------------------------------------------------------------
*Name           : ValidateFunctionTable
*Description    : ???
*Parameters     : N/A
*Return         : ???
*--------------------------------------------------------------------------------------*/
short	ValidateFunctionTable( void )
{
	return 0 ;

	/* ̤�����餷������table�����åȤ���Ƥ뤫�ɤ����Ǥ��֤��Ĥ����ä��Τ����� */
}


/*-------------------------------------------------------------------------------------
*Name           : ResetFunctionTable
*Description    : reset fun_table
*Parameters     : N/A
*Precondition	: N/A
*Operation      : reset fun_table.
*Postcondition  : fun_table is reset.
*Return         : N/A
*History        : 
*--------------------------------------------------------------------------------------*/
void ResetFunctionTable( void )
{
	fun_table.lpfnMInitJob		= NULL ;
	fun_table.lpfnMExitJob		= NULL ;
	fun_table.lpfnMBeginJob 	= NULL ;
	fun_table.lpfnMEndJob		= NULL ;
	fun_table.lpfnMBeginPage	= NULL ;
	fun_table.lpfnMEndPage		= NULL ;
	fun_table.lpfnMSendBandData	= NULL ;
}

